const Se="modulepreload",De=function(e,t){return e[0]==="."?new URL(e,t).href:e},oe={},H=function(t,l,i){if(!l||l.length===0)return t();const _=document.getElementsByTagName("link");return Promise.all(l.map(p=>{if(p=De(p,i),p in oe)return;oe[p]=!0;const h=p.endsWith(".css"),u=h?'[rel="stylesheet"]':"";if(!!i)for(let w=_.length-1;w>=0;w--){const v=_[w];if(v.href===p&&(!h||v.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${p}"]${u}`))return;const o=document.createElement("link");if(o.rel=h?"stylesheet":Se,h||(o.as="script",o.crossOrigin=""),o.href=p,document.head.appendChild(o),h)return new Promise((w,v)=>{o.addEventListener("load",w),o.addEventListener("error",()=>v(new Error(`Unable to preload CSS for ${p}`)))})})).then(()=>t()).catch(p=>{const h=new Event("vite:preloadError",{cancelable:!0});if(h.payload=p,window.dispatchEvent(h),!h.defaultPrevented)throw p})};var Z=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function K(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var fe={exports:{}};(function(e,t){(function(l,i){e.exports=i()})(Z,function(){var l=1e3,i=6e4,_=36e5,p="millisecond",h="second",u="minute",g="hour",o="day",w="week",v="month",C="quarter",S="year",T="date",V="Invalid Date",ke=/^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/,Ee=/\[([^\]]+)]|YYYY|YY|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,Me={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_"),ordinal:function(c){var r=["th","st","nd","rd"],n=c%100;return"["+c+(r[(n-20)%10]||r[n]||r[0])+"]"}},Q=function(c,r,n){var a=String(c);return!a||a.length>=r?c:""+Array(r+1-a.length).join(n)+c},Oe={s:Q,z:function(c){var r=-c.utcOffset(),n=Math.abs(r),a=Math.floor(n/60),s=n%60;return(r<=0?"+":"-")+Q(a,2,"0")+":"+Q(s,2,"0")},m:function c(r,n){if(r.date()<n.date())return-c(n,r);var a=12*(n.year()-r.year())+(n.month()-r.month()),s=r.clone().add(a,v),d=n-s<0,f=r.clone().add(a+(d?-1:1),v);return+(-(a+(n-s)/(d?s-f:f-s))||0)},a:function(c){return c<0?Math.ceil(c)||0:Math.floor(c)},p:function(c){return{M:v,y:S,w,d:o,D:T,h:g,m:u,s:h,ms:p,Q:C}[c]||String(c||"").toLowerCase().replace(/s$/,"")},u:function(c){return c===void 0}},Y="en",A={};A[Y]=Me;var ie="$isDayjsObject",X=function(c){return c instanceof F||!(!c||!c[ie])},z=function c(r,n,a){var s;if(!r)return Y;if(typeof r=="string"){var d=r.toLowerCase();A[d]&&(s=d),n&&(A[d]=n,s=d);var f=r.split("-");if(!s&&f.length>1)return c(f[0])}else{var y=r.name;A[y]=r,s=y}return!a&&s&&(Y=s),s||!a&&Y},b=function(c,r){if(X(c))return c.clone();var n=typeof r=="object"?r:{};return n.date=c,n.args=arguments,new F(n)},m=Oe;m.l=z,m.i=X,m.w=function(c,r){return b(c,{locale:r.$L,utc:r.$u,x:r.$x,$offset:r.$offset})};var F=function(){function c(n){this.$L=z(n.locale,null,!0),this.parse(n),this.$x=this.$x||n.x||{},this[ie]=!0}var r=c.prototype;return r.parse=function(n){this.$d=function(a){var s=a.date,d=a.utc;if(s===null)return new Date(NaN);if(m.u(s))return new Date;if(s instanceof Date)return new Date(s);if(typeof s=="string"&&!/Z$/i.test(s)){var f=s.match(ke);if(f){var y=f[2]-1||0,$=(f[7]||"0").substring(0,3);return d?new Date(Date.UTC(f[1],y,f[3]||1,f[4]||0,f[5]||0,f[6]||0,$)):new Date(f[1],y,f[3]||1,f[4]||0,f[5]||0,f[6]||0,$)}}return new Date(s)}(n),this.init()},r.init=function(){var n=this.$d;this.$y=n.getFullYear(),this.$M=n.getMonth(),this.$D=n.getDate(),this.$W=n.getDay(),this.$H=n.getHours(),this.$m=n.getMinutes(),this.$s=n.getSeconds(),this.$ms=n.getMilliseconds()},r.$utils=function(){return m},r.isValid=function(){return this.$d.toString()!==V},r.isSame=function(n,a){var s=b(n);return this.startOf(a)<=s&&s<=this.endOf(a)},r.isAfter=function(n,a){return b(n)<this.startOf(a)},r.isBefore=function(n,a){return this.endOf(a)<b(n)},r.$g=function(n,a,s){return m.u(n)?this[a]:this.set(s,n)},r.unix=function(){return Math.floor(this.valueOf()/1e3)},r.valueOf=function(){return this.$d.getTime()},r.startOf=function(n,a){var s=this,d=!!m.u(a)||a,f=m.p(n),y=function(P,O){var x=m.w(s.$u?Date.UTC(s.$y,O,P):new Date(s.$y,O,P),s);return d?x:x.endOf(o)},$=function(P,O){return m.w(s.toDate()[P].apply(s.toDate("s"),(d?[0,0,0,0]:[23,59,59,999]).slice(O)),s)},k=this.$W,M=this.$M,D=this.$D,I="set"+(this.$u?"UTC":"");switch(f){case S:return d?y(1,0):y(31,11);case v:return d?y(1,M):y(0,M+1);case w:var R=this.$locale().weekStart||0,W=(k<R?k+7:k)-R;return y(d?D-W:D+(6-W),M);case o:case T:return $(I+"Hours",0);case g:return $(I+"Minutes",1);case u:return $(I+"Seconds",2);case h:return $(I+"Milliseconds",3);default:return this.clone()}},r.endOf=function(n){return this.startOf(n,!1)},r.$set=function(n,a){var s,d=m.p(n),f="set"+(this.$u?"UTC":""),y=(s={},s[o]=f+"Date",s[T]=f+"Date",s[v]=f+"Month",s[S]=f+"FullYear",s[g]=f+"Hours",s[u]=f+"Minutes",s[h]=f+"Seconds",s[p]=f+"Milliseconds",s)[d],$=d===o?this.$D+(a-this.$W):a;if(d===v||d===S){var k=this.clone().set(T,1);k.$d[y]($),k.init(),this.$d=k.set(T,Math.min(this.$D,k.daysInMonth())).$d}else y&&this.$d[y]($);return this.init(),this},r.set=function(n,a){return this.clone().$set(n,a)},r.get=function(n){return this[m.p(n)]()},r.add=function(n,a){var s,d=this;n=Number(n);var f=m.p(a),y=function(M){var D=b(d);return m.w(D.date(D.date()+Math.round(M*n)),d)};if(f===v)return this.set(v,this.$M+n);if(f===S)return this.set(S,this.$y+n);if(f===o)return y(1);if(f===w)return y(7);var $=(s={},s[u]=i,s[g]=_,s[h]=l,s)[f]||1,k=this.$d.getTime()+n*$;return m.w(k,this)},r.subtract=function(n,a){return this.add(-1*n,a)},r.format=function(n){var a=this,s=this.$locale();if(!this.isValid())return s.invalidDate||V;var d=n||"YYYY-MM-DDTHH:mm:ssZ",f=m.z(this),y=this.$H,$=this.$m,k=this.$M,M=s.weekdays,D=s.months,I=s.meridiem,R=function(O,x,U,G){return O&&(O[x]||O(a,d))||U[x].slice(0,G)},W=function(O){return m.s(y%12||12,O,"0")},P=I||function(O,x,U){var G=O<12?"AM":"PM";return U?G.toLowerCase():G};return d.replace(Ee,function(O,x){return x||function(U){switch(U){case"YY":return String(a.$y).slice(-2);case"YYYY":return m.s(a.$y,4,"0");case"M":return k+1;case"MM":return m.s(k+1,2,"0");case"MMM":return R(s.monthsShort,k,D,3);case"MMMM":return R(D,k);case"D":return a.$D;case"DD":return m.s(a.$D,2,"0");case"d":return String(a.$W);case"dd":return R(s.weekdaysMin,a.$W,M,2);case"ddd":return R(s.weekdaysShort,a.$W,M,3);case"dddd":return M[a.$W];case"H":return String(y);case"HH":return m.s(y,2,"0");case"h":return W(1);case"hh":return W(2);case"a":return P(y,$,!0);case"A":return P(y,$,!1);case"m":return String($);case"mm":return m.s($,2,"0");case"s":return String(a.$s);case"ss":return m.s(a.$s,2,"0");case"SSS":return m.s(a.$ms,3,"0");case"Z":return f}return null}(O)||f.replace(":","")})},r.utcOffset=function(){return 15*-Math.round(this.$d.getTimezoneOffset()/15)},r.diff=function(n,a,s){var d,f=this,y=m.p(a),$=b(n),k=($.utcOffset()-this.utcOffset())*i,M=this-$,D=function(){return m.m(f,$)};switch(y){case S:d=D()/12;break;case v:d=D();break;case C:d=D()/3;break;case w:d=(M-k)/6048e5;break;case o:d=(M-k)/864e5;break;case g:d=M/_;break;case u:d=M/i;break;case h:d=M/l;break;default:d=M}return s?d:m.a(d)},r.daysInMonth=function(){return this.endOf(v).$D},r.$locale=function(){return A[this.$L]},r.locale=function(n,a){if(!n)return this.$L;var s=this.clone(),d=z(n,a,!0);return d&&(s.$L=d),s},r.clone=function(){return m.w(this.$d,this)},r.toDate=function(){return new Date(this.valueOf())},r.toJSON=function(){return this.isValid()?this.toISOString():null},r.toISOString=function(){return this.$d.toISOString()},r.toString=function(){return this.$d.toUTCString()},c}(),ae=F.prototype;return b.prototype=ae,[["$ms",p],["$s",h],["$m",u],["$H",g],["$W",o],["$M",v],["$y",S],["$D",T]].forEach(function(c){ae[c[1]]=function(r){return this.$g(r,c[0],c[1])}}),b.extend=function(c,r){return c.$i||(c(r,F,b),c.$i=!0),b},b.locale=z,b.isDayjs=X,b.unix=function(c){return b(1e3*c)},b.en=A[Y],b.Ls=A,b.p={},b})})(fe);var Ce=fe.exports;const J=K(Ce);var pe={exports:{}};(function(e,t){(function(l,i){e.exports=i()})(Z,function(){function l(){return l=Object.assign||function(i){for(var _=1;_<arguments.length;_++){var p=arguments[_];for(var h in p)Object.prototype.hasOwnProperty.call(p,h)&&(i[h]=p[h])}return i},l.apply(this,arguments)}return function(i,_,p){p.updateLocale=function(h,u){var g=p.Ls[h];if(g)return(u?Object.keys(u):[]).forEach(function(o){g[o]&&u[o]&&typeof g[o]=="object"&&typeof u[o]=="object"&&!Array.isArray(g[o])?g[o]=l({},g[o],u[o]):g[o]=u[o]}),g}}})})(pe);var Le=pe.exports;const Te=K(Le);var he={exports:{}};(function(e,t){(function(l,i){e.exports=i()})(Z,function(){return function(l,i){var _=i.prototype,p=_.format;_.format=function(h){var u=this,g=this.$locale();if(!this.isValid())return p.bind(this)(h);var o=this.$utils(),w=(h||"YYYY-MM-DDTHH:mm:ssZ").replace(/\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g,function(v){switch(v){case"Q":return Math.ceil((u.$M+1)/3);case"Do":return g.ordinal(u.$D);case"gggg":return u.weekYear();case"GGGG":return u.isoWeekYear();case"wo":return g.ordinal(u.week(),"W");case"w":case"ww":return o.s(u.week(),v==="w"?1:2,"0");case"W":case"WW":return o.s(u.isoWeek(),v==="W"?1:2,"0");case"k":case"kk":return o.s(String(u.$H===0?24:u.$H),v==="k"?1:2,"0");case"X":return Math.floor(u.$d.getTime()/1e3);case"x":return u.$d.getTime();case"z":return"["+u.offsetName()+"]";case"zzz":return"["+u.offsetName("long")+"]";default:return v}});return p.bind(this)(w)}}})})(he);var xe=he.exports;const Ae=K(xe);var ve={exports:{}};(function(e,t){(function(l,i){e.exports=i()})(Z,function(){var l="day";return function(i,_,p){var h=function(o){return o.add(4-o.isoWeekday(),l)},u=_.prototype;u.isoWeekYear=function(){return h(this).year()},u.isoWeek=function(o){if(!this.$utils().u(o))return this.add(7*(o-this.isoWeek()),l);var w,v,C,S,T=h(this),V=(w=this.isoWeekYear(),v=this.$u,C=(v?p.utc:p)().year(w).startOf("year"),S=4-C.isoWeekday(),C.isoWeekday()>4&&(S+=7),C.add(S,l));return T.diff(V,"week")+1},u.isoWeekday=function(o){return this.$utils().u(o)?this.day()||7:this.day(this.day()%7?o:o-7)};var g=u.startOf;u.startOf=function(o,w){var v=this.$utils(),C=!!v.u(w)||w;return v.p(o)==="isoweek"?C?this.date(this.date()-(this.isoWeekday()-1)).startOf("day"):this.date(this.date()-1-(this.isoWeekday()-1)+7).endOf("day"):g.bind(this)(o,w)}}})})(ve);var Re=ve.exports;const Pe=K(Re);J.extend(Te);J.extend(Ae);J.extend(Pe);const se=864e5,q=e=>Date.parse(`${e.slice(0,10)}T00:00:00Z`),_e=e=>new Date(e).toISOString().slice(0,10),ge=(e,t)=>t>e&&/[ T]00:00(:00)?$/.test(t)?_e(q(t)-se):t.slice(0,10),Ie=(e,t)=>(q(ge(e,t))-q(e))/se+1;function je(e,t){const l=parseInt(e,10),i=l>=0&&l<=6?l:0;J.updateLocale("en",{weekStart:i}),t==null||t.updateLocale("en",{weekStart:i})}const Ne=new TextEncoder,ee=e=>String(e||"").replace(/\\/g,"\\\\").replace(/([,;])/g,"\\$1").replace(/\r?\n/g,"\\n"),Ye=e=>{const t=[];let l="",i=0;for(const _ of e){const p=Ne.encode(_).length;i+p>(t.length?74:75)&&(t.push(l),l="",i=0),l+=_,i+=p}return t.push(l),t.join(`\r
 `)},j=e=>`${String(e).replace(/[-:]/g,"").replace(" ","T").slice(0,15)}Z`;function me(e){return["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Fluent Events//EN","CALSCALE:GREGORIAN","BEGIN:VEVENT",`UID:fluent-event-${e.id}@${window.location.host}`,`DTSTAMP:${j(new Date().toISOString())}`,`DTSTART:${j(e.start_at)}`,`DTEND:${j(e.end_at)}`,`SUMMARY:${ee(e.title)}`,`DESCRIPTION:${ee(e.description)}`,`LOCATION:${ee(e.location)}`,`URL:${e.url}`,"END:VEVENT","END:VCALENDAR"].map(Ye).join(`\r
`)}function ye(e,t){const l=new Blob([e],{type:"text/calendar;charset=utf-8"}),i=document.createElement("a");i.href=URL.createObjectURL(l),i.download=t,i.click(),URL.revokeObjectURL(i.href)}const et=Object.freeze(Object.defineProperty({__proto__:null,DAY_MS:se,applyWeekStart:je,buildIcs:me,daySpan:Ie,downloadIcs:ye,icsStamp:j,lastDay:ge,toDayKey:_e,toUtcDay:q},Symbol.toStringTag,{value:"Module"})),L=()=>window.fluentEventFcomPortal||{};function E(e,...t){let l=(L().i18n||{})[e]||e,i=0;return l.replace(/%(\d+\$)?[sd]/g,(_,p)=>{const h=p?t[parseInt(p,10)-1]:t[i++];return h===void 0?_:h})}async function N(e,t,l,i){const _=window.fluentComAdmin&&window.fluentComAdmin.rest||{},p=i instanceof FormData,h={};L().is_logged_in&&_.nonce&&(h["X-WP-Nonce"]=_.nonce);let u=`${e.replace(/\/$/,"")}/${l}`;const g={method:t,headers:h,credentials:"same-origin"};if(t==="GET"){const v=new URLSearchParams(i||{}).toString();u+=v?(u.includes("?")?"&":"?")+v:""}else p?g.body=i:(h["Content-Type"]="application/json",g.body=JSON.stringify(i||{}));const o=await fetch(u,g),w=await o.json().catch(()=>({}));if(!o.ok)throw w;return w}const te={get:(e,t)=>N(L().rest_url,"GET",e,t),post:(e,t)=>N(L().rest_url,"POST",e,t),patch:(e,t)=>N(L().rest_url,"PATCH",e,t)};async function tt(e){const t=new FormData;return t.append("file",e),(await N(L().wp_rest_url,"POST","media",t)).source_url}const We={get:(e,t)=>N(window.fluentComAdmin.rest.url,"GET",e,t),post:(e,t)=>N(window.fluentComAdmin.rest.url,"POST",e,t)};function le(e){if(e&&typeof e.message=="string")return e.message;const t=e&&(e.errors||e)||{};for(const l of Object.keys(t)){const i=t[l],_=i&&typeof i=="object"?Object.values(i)[0]:"";if(typeof _=="string"&&_)return _}return E("Something went wrong. Please try again.")}const re=e=>window.dayjs(e),ce=e=>window.dayjs.utc(e);function nt(e){const t=Date.now();return e.is_past||t>=ce(e.end_at).valueOf()?"ended":t>=ce(e.start_at).valueOf()?"live":"upcoming"}function Ue(){return window.fluentComAdmin&&window.fluentComAdmin.time_formatter||"h:mm A"}function He(){return window.fluentComAdmin&&window.fluentComAdmin.date_formatter||"MMM D, YYYY"}function we(e){const t=re(e.start_at_site);return`${t.format(He())} · ${t.format(Ue())}`}function $e(e){return re(e.start_at_site).format("MMM")}function be(e){return re(e.start_at_site).format("D")}function st(e,t=new Date){try{return(new Intl.DateTimeFormat("en-US",{timeZone:e,timeZoneName:"shortOffset"}).formatToParts(t).find(i=>i.type==="timeZoneName")||{}).value||""}catch{return""}}function Be(e,t,l){return`https://calendar.google.com/calendar/render?${new URLSearchParams({action:"TEMPLATE",text:e.title,dates:`${j(e.start_at)}/${j(e.end_at)}`,details:t,location:l}).toString()}`}function Ve(e,t,l){const i=me({id:e.id,title:e.title,start_at:e.start_at,end_at:e.end_at,description:t,location:l,url:window.location.href});ye(i,`${e.slug}.ics`)}function ne(e){return["going","checked_in"].includes(e.my_status)}function ze(e){return e.is_past||["rsvp","open"].includes(e.entry_type)}function Fe(e){return e.guest_count===null||e.guest_count===void 0?"":E("%s going",e.guest_count)}function rt(e){document.title=[e,(window.fluentComAdmin||{}).site_title].filter(Boolean).join(" - ")}const B='<svg viewBox="0 0 16 16" width="10" height="10"><path d="M3.5 8.5l3 3 6-7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',ue='<svg viewBox="0 0 16 16" width="10" height="10"><path d="M4.5 4.5l7 7m0-7l-7 7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',de='<svg viewBox="0 0 16 16" width="12" height="12"><path d="M4 6l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',Ge='<svg viewBox="0 0 1024 1024" width="1em" height="1em"><path fill="currentColor" d="M704 768V256H128v512zm64-416 192-96v512l-192-96v128a32 32 0 0 1-32 32H96a32 32 0 0 1-32-32V224a32 32 0 0 1 32-32h640a32 32 0 0 1 32 32zm0 71.552v176.896l128 64V359.552zM192 320h192v64H192z"/></svg>',qe='<svg viewBox="0 0 1024 1024" width="1em" height="1em"><path fill="currentColor" d="M800 416a288 288 0 1 0-576 0c0 118.144 94.528 272.128 288 456.576C705.472 688.128 800 534.144 800 416M512 960C277.312 746.688 160 565.312 160 416a352 352 0 0 1 704 0c0 149.312-117.312 330.688-352 544"/><path fill="currentColor" d="M512 448a64 64 0 1 0 0-128 64 64 0 0 0 0 128m0 64a128 128 0 1 1 0-256 128 128 0 0 1 0 256m345.6 192L960 960H672v-64H352v64H64l102.4-256zm-68.928 0H235.328l-76.8 192h706.944z"/></svg>',Ze='<svg viewBox="0 0 24 24"><path fill="currentColor" d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z"/></svg>',Ke='<svg viewBox="0 0 24 24"><path fill="currentColor" d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-2.117 3.675-.546 9.103 1.519 12.09 1.013 1.454 2.208 3.09 3.792 3.039 1.52-.065 2.09-.987 3.935-.987 1.831 0 2.35.987 3.96.948 1.637-.026 2.676-1.48 3.676-2.948 1.156-1.688 1.636-3.325 1.662-3.415-.039-.013-3.182-1.221-3.22-4.857-.026-3.04 2.48-4.494 2.597-4.559-1.429-2.09-3.623-2.324-4.39-2.376-2-.156-3.675 1.09-4.61 1.09zM15.53 3.83c.843-1.012 1.4-2.427 1.245-3.83-1.207.052-2.662.805-3.532 1.818-.78.896-1.454 2.338-1.273 3.714 1.338.104 2.715-.688 3.559-1.701"/></svg>',Je='<svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M176 416a112 112 0 1 1 0 224 112 112 0 0 1 0-224m336 0a112 112 0 1 1 0 224 112 112 0 0 1 0-224m336 0a112 112 0 1 1 0 224 112 112 0 0 1 0-224"/></svg>',Qe={name:"FluentEventActions",props:{event:{type:Object,required:!0}},emits:["done","error"],data(){const e=L().user||{};return{busy:!1,open:!1,guest:{name:e.name||"",email:e.email||"",website:""},formError:""}},computed:{isLoggedIn(){return!!L().is_logged_in},status(){return ne(this.event)?"going":this.event.my_status==="not_going"?"not_going":""}},beforeUnmount(){this.listen(!1)},methods:{loginUrl(){const e=new URL((window.fluentComAdmin||{}).auth_url||"",window.location.href);return e.searchParams.set("redirect_to",window.location.href),e.href},t:E,toggle(){this.open=!this.open,this.listen(this.open),this.open&&this.$nextTick(()=>this.$refs.name&&this.$refs.name.focus())},close(){this.open=!1,this.listen(!1)},listen(e){const t=e?"addEventListener":"removeEventListener";document[t]("click",this.onOutsideClick),document[t]("keydown",this.onKeydown)},onOutsideClick(e){this.$el.contains(e.target)||this.close()},onKeydown(e){e.key==="Escape"&&(this.close(),this.$refs.trigger&&this.$refs.trigger.focus())},async register(){this.busy=!0,this.formError="";try{const e=this.isLoggedIn?await te.post(`community/events/${this.event.id}/register`,{status:"going",name:this.guest.name}):await te.post(`community/events/${this.event.id}/register-guest`,{...this.guest,nonce:this.event.register_nonce}),t=this.withStatus(e);this.close(),this.$emit("done",t),this.showRegistered(t.event)}catch(e){this.formError=le(e)}finally{this.busy=!1}},async choose(e){if(this.close(),e!==this.status){this.busy=!0,this.$emit("error","");try{const t=this.withStatus(await te.post(`community/events/${this.event.id}/register`,{status:e}));this.$emit("done",t);const{ElNotification:l}=await H(()=>import("./index-a7aebe3e.js"),["./index-a7aebe3e.js","./vue.esm-bundler-9b1be5c2.js","./index-6a623fd8.js"],import.meta.url);l({type:"success",message:t.message})}catch(t){this.$emit("error",le(t))}finally{this.busy=!1}}},withStatus(e){const t=ne(this.event),l=ne({my_status:e.status}),i=this.event.guest_count;return{...e,event:{...this.event,my_status:e.status,online_meeting_url:e.online_meeting_url,guest_count:i==null||t===l?i:i+(l?1:-1)}}},async cancel(){this.close();const{ElMessageBox:e}=await H(()=>import("./index-a7aebe3e.js"),["./index-a7aebe3e.js","./vue.esm-bundler-9b1be5c2.js","./index-6a623fd8.js"],import.meta.url);try{await e.confirm(E("You will lose your spot for %s. You can register again later.",this.event.title),E("Cancel your registration?"),{confirmButtonText:E("Cancel registration"),cancelButtonText:E("Keep it"),confirmButtonClass:"el-button--danger"})}catch{return}this.choose("cancelled")},async showRegistered(e){const[{h:t},{ElMessageBox:l},{Clock:i,MapLocation:_,VideoCamera:p}]=await Promise.all([H(()=>import("./vue.esm-bundler-9b1be5c2.js").then(o=>o.az),[],import.meta.url),H(()=>import("./index-a7aebe3e.js"),["./index-a7aebe3e.js","./vue.esm-bundler-9b1be5c2.js","./index-6a623fd8.js"],import.meta.url),H(()=>import("./index-6a623fd8.js"),["./index-6a623fd8.js","./vue.esm-bundler-9b1be5c2.js"],import.meta.url)]),h=e.venue_type==="online",u=h?/^https?:\/\//i.test(e.online_meeting_url)?e.online_meeting_url:"":[e.venue,e.address].filter(Boolean).join(", "),g=o=>t("span",{class:"fe-registered__icon",innerHTML:o});l.alert(t("div",{class:"fe-registered"},[t("div",{class:"fe-registered__head"},[t("span",{class:"fe-registered__check",innerHTML:B}),t("strong",{class:"fe-registered__title"},E("You're registered"))]),t("div",{class:"fe-registered__event"},[e.cover_url?t("img",{class:"fe-registered__cover",src:e.cover_url,alt:""}):t("span",{class:"fe-registered__chip","aria-hidden":"true"},[t("span",{class:"fe-registered__chip-month"},$e(e)),t("span",{class:"fe-registered__chip-day"},be(e))]),t("div",{class:"fe-registered__details"},[t("span",{class:"fe-registered__event-title"},e.title),t("span",{class:"fe-registered__meta"},[t(i,{class:"fe-registered__meta-icon"}),we(e)]),t("span",{class:"fe-registered__meta"},[t(h?p:_,{class:"fe-registered__meta-icon"}),h?E("Online"):e.venue||E("In Person")])])]),t("span",{class:"fe-registered__label"},E("Add to calendar")),t("div",{class:"fe-registered__calendar"},[t("a",{class:"fe-registered__calendar-link",href:Be(e,"",u),target:"_blank",rel:"noopener noreferrer"},[g(Ze),E("Google Calendar")]),t("button",{type:"button",class:"fe-registered__calendar-link",onClick:()=>Ve(e,"",u)},[g(Ke),E("Apple / Outlook")])])]),"",{customClass:"fe-registered-box",confirmButtonText:E("Done"),confirmButtonClass:"fcom_primary_button",closeOnPressEscape:!0}).catch(()=>{}).finally(()=>this.$refs.trigger&&this.$refs.trigger.focus())}},template:`
        <div class="fe-event-actions">
            <span v-if="event.is_past" class="fe-event-actions__badge">{{ t('Ended') }}</span>

            <template v-else-if="event.entry_type === 'open'">
                <!-- A visitor isn't recognised again after a reload, so only a member's badge opens a menu to cancel. -->
                <div v-if="status === 'going' && isLoggedIn" class="fe-rsvp">
                    <button
                        ref="trigger"
                        type="button"
                        class="fe-rsvp__trigger"
                        aria-haspopup="menu"
                        :aria-expanded="open ? 'true' : 'false'"
                        :disabled="busy"
                        @click.stop="toggle"
                    >
                        <span class="fe-rsvp__icon fe-rsvp__icon--going" aria-hidden="true">${B}</span>
                        <span class="fe-rsvp__label">{{ t('Registered') }}</span>
                        <span class="fe-rsvp__chevron" :class="{ 'fe-rsvp__chevron--open': open }" aria-hidden="true">${de}</span>
                    </button>

                    <div v-if="open" class="el-popover el-popper fcom_menu_below_nav fe-rsvp__pop">
                        <ul class="actions_items" role="menu">
                            <li role="none">
                                <button type="button" role="menuitem" class="fe-rsvp__option fe-rsvp__option--danger" @click.stop="cancel">{{ t('Cancel registration') }}</button>
                            </li>
                        </ul>
                    </div>
                </div>
                <span v-else-if="status === 'going'" class="fe-event-actions__badge">
                    <span class="fe-event-actions__badge-icon" aria-hidden="true">${B}</span>
                    {{ t('Registered') }}
                </span>
                <div v-else class="fe-guest-register">
                    <button
                        ref="trigger"
                        type="button"
                        class="el-button fcom_primary_button"
                        aria-haspopup="dialog"
                        :aria-expanded="open ? 'true' : 'false'"
                        @click.stop="toggle"
                    >{{ t('Register') }}</button>

                    <form
                        v-if="open"
                        class="el-popover el-popper fcom_menu_below_nav fe-guest-register__pop"
                        role="dialog"
                        :aria-label="t('Register')"
                        @submit.prevent="register"
                    >
                        <label class="fe-guest-register__label" :for="'fe-guest-name-' + event.id">{{ t('Name') }}</label>
                        <input ref="name" :id="'fe-guest-name-' + event.id" v-model="guest.name" class="fe-guest-register__input" type="text" autocomplete="name" required>

                        <label class="fe-guest-register__label" :for="'fe-guest-email-' + event.id">{{ t('Email') }}</label>
                        <input :id="'fe-guest-email-' + event.id" v-model="guest.email" class="fe-guest-register__input" type="email" autocomplete="email" required :disabled="isLoggedIn">

                        <input v-if="!isLoggedIn" v-model="guest.website" class="fe-guest-register__trap" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">

                        <p v-if="formError" class="fe-guest-register__error" role="alert">{{ formError }}</p>

                        <button type="submit" class="el-button fcom_primary_button" :disabled="busy">{{ t('Register') }}</button>
                    </form>
                </div>
            </template>

            <a v-else-if="!isLoggedIn" class="el-button fcom_primary_button" :href="loginUrl()" @click="$event.currentTarget.href = loginUrl()">{{ t('Log in to RSVP') }}</a>

            <div v-else class="fe-rsvp">
                <button
                    ref="trigger"
                    type="button"
                    class="fe-rsvp__trigger"
                    aria-haspopup="menu"
                    :aria-expanded="open ? 'true' : 'false'"
                    :disabled="busy"
                    @click.stop="toggle"
                >
                    <span v-if="status === 'going'" class="fe-rsvp__icon fe-rsvp__icon--going" aria-hidden="true">${B}</span>
                    <span v-else-if="status === 'not_going'" class="fe-rsvp__icon fe-rsvp__icon--not-going" aria-hidden="true">${ue}</span>
                    <span class="fe-rsvp__label">{{ status === 'going' ? t('Going') : status === 'not_going' ? t('Not going') : t('Interested?') }}</span>
                    <span class="fe-rsvp__chevron" :class="{ 'fe-rsvp__chevron--open': open }" aria-hidden="true">${de}</span>
                </button>

                <div v-if="open" class="el-popover el-popper fcom_menu_below_nav fe-rsvp__pop">
                    <ul class="actions_items" role="menu">
                        <li role="none">
                            <button type="button" role="menuitemradio" class="fe-rsvp__option" :aria-checked="status === 'going' ? 'true' : 'false'" @click.stop="choose('going')">
                                <span class="fe-rsvp__icon fe-rsvp__icon--going" aria-hidden="true">${B}</span>
                                {{ t('Going') }}
                            </button>
                        </li>
                        <li role="none">
                            <button type="button" role="menuitemradio" class="fe-rsvp__option" :aria-checked="status === 'not_going' ? 'true' : 'false'" @click.stop="choose('not_going')">
                                <span class="fe-rsvp__icon fe-rsvp__icon--not-going" aria-hidden="true">${ue}</span>
                                {{ t('Not going') }}
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    `},Xe={name:"FluentEventMenu",props:{event:{type:Object,required:!0},router:{type:Object,default:null}},data(){return{open:!1}},computed:{editRoute(){return{name:"fe_edit_event",params:{event_slug:this.event.slug}}},adminUrl(){const e=L().admin_url;return e?e+"#/events/"+this.event.id:""},portalRouter(){return this.router||this.$router}},beforeUnmount(){this.listen(!1)},methods:{t:E,toggle(){this.open=!this.open,this.listen(this.open),this.open&&this.$nextTick(()=>{const e=this.$el.querySelector('[role="menuitem"]');e&&e.focus()})},close(){this.open=!1,this.listen(!1)},listen(e){const t=e?"addEventListener":"removeEventListener";document[t]("click",this.onOutsideClick),document[t]("keydown",this.onKeydown)},onOutsideClick(e){this.$el.contains(e.target)||this.close()},onKeydown(e){e.key==="Escape"&&(this.close(),this.$refs.trigger.focus())}},template:`
        <div v-if="event.edit_url" class="fe-event-menu">
            <button
                ref="trigger"
                type="button"
                class="el-button el-button--small is-text fcom_dot_menu"
                aria-haspopup="menu"
                :aria-expanded="open ? 'true' : 'false'"
                :aria-label="t('More actions')"
                @click.stop="toggle"
            >
                <span>
                    <i class="el-icon" aria-hidden="true">
                        ${Je}
                    </i>
                </span>
            </button>

            <div v-if="open" class="el-popover el-popper fcom_menu_below_nav fe-event-menu__pop">
                <ul class="actions_items" role="menu">
                    <li role="none">
                        <!-- .stop: fcom's document click handler would route the link a second time. -->
                        <a role="menuitem" class="fe-event-menu__item" :href="portalRouter.resolve(editRoute).href" @click.stop.prevent="portalRouter.push(editRoute)">{{ t('Edit Event') }}</a>
                    </li>
                    <li v-if="adminUrl" role="none">
                        <a role="menuitem" class="fe-event-menu__item" :href="adminUrl" @click.stop>{{ t('View in FluentEvent') }}</a>
                    </li>
                </ul>
            </div>
        </div>
    `},it={name:"FluentEventCard",components:{EventActions:{...Qe},EventMenu:{...Xe}},props:{feed:{type:Object,required:!0},is_single:{type:Boolean,default:!1},is_child:{type:Boolean,default:!1}},data(){return{event:this.feed.fluent_event||null,loading:!("fluent_event"in this.feed),error:""}},watch:{"feed.fluent_event"(e){this.event=e||null}},mounted(){this.loading&&this.loadEvent()},computed:{startDate(){return we(this.event)},month(){return $e(this.event)},day(){return be(this.event)},countLabel(){return Fe(this.event)},isOnlineEvent(){return this.event.venue_type==="online"},hasActions(){return!this.is_child&&ze(this.event)},unpublishedNote(){return this.event.registration_open!==!1||this.event.is_past?"":this.event.entry_type==="open"?E("Members can register once this post is published."):E("Members can RSVP once this post is published.")},eventRoute(){const e=this.feed.space&&this.feed.space.slug;return this.event.slug?e?{name:"fe_event_view",params:{space:e,event_slug:this.event.slug}}:this.feed.space_id?null:{name:"fe_global_event_view",params:{event_slug:this.event.slug}}:null},hasEventPage(){return!!this.eventRoute&&this.$router.hasRoute(this.eventRoute.name)},portalUrl(){return(window.fluentComAdmin||{}).portal_url||""},portalEventUrl(){const{space:e,event_slug:t}=this.eventRoute.params;return this.portalUrl+(e?`space/${e}/`:"")+`event/${t}`},canOpenEvent(){return this.hasEventPage||!!this.eventRoute&&!!this.portalUrl}},methods:{t:E,openEvent(){this.hasEventPage?this.$router.push(this.eventRoute):this.canOpenEvent&&(window.location.href=this.portalEventUrl)},apply(e){this.event=e.event},async loadEvent(){try{const e=await We.get(`feeds/${this.feed.id}/by-id`);this.event=e.feed.fluent_event||null}catch{this.event=null}finally{this.loading=!1}}},template:`
        <div class="fe-event-card" :class="{ 'fe-event-card--single': is_single, 'fe-event-card--child': is_child }">
            <div v-if="loading" class="fe-event-card__skeleton" role="status" :aria-label="t('Loading event')">
                <span class="fe-event-card__skeleton-cover"></span>
                <span class="fe-event-card__body">
                    <span class="fe-event-card__skeleton-chip"></span>
                    <span class="fe-event-card__skeleton-lines">
                        <span class="fe-event-card__skeleton-line fe-event-card__skeleton-line--title"></span>
                        <span class="fe-event-card__skeleton-line"></span>
                        <span class="fe-event-card__skeleton-line fe-event-card__skeleton-line--short"></span>
                    </span>
                </span>
                <span class="fe-event-card__actions">
                    <span class="fe-event-card__skeleton-line fe-event-card__skeleton-line--count"></span>
                    <span class="fe-event-card__skeleton-button"></span>
                </span>
            </div>
            <p v-else-if="!event" class="fe-event-card__unavailable">{{ t('This event is not available.') }}</p>
            <template v-else>
                <!-- A mouse shortcut to the title link, which stays the keyboard and screen-reader route. -->
                <img
                    v-if="event.cover_url"
                    class="fe-event-card__cover"
                    :class="{ 'fe-event-card__cover--link': canOpenEvent }"
                    :src="event.cover_url"
                    alt=""
                    @click="openEvent"
                />
                <div class="fe-event-card__body">
                    <div class="fe-date-chip" aria-hidden="true">
                        <span class="fe-date-chip__month">{{ month }}</span>
                        <span class="fe-date-chip__day">{{ day }}</span>
                    </div>
                    <div class="fe-event-card__info">
                        <div class="fe-event-card__head">
                            <h3 class="fe-event-card__title" :class="{ 'fe-event-card__title--truncated': !is_single }" :title="is_single ? null : event.title">
                                <router-link
                                    v-if="eventRoute && hasEventPage"
                                    class="fe-event-card__title-link"
                                    :to="eventRoute"
                                >{{ event.title }}</router-link>
                                <a v-else-if="eventRoute && portalUrl" class="fe-event-card__title-link" :href="portalEventUrl">{{ event.title }}</a>
                                <template v-else>{{ event.title }}</template>
                            </h3>
                            <event-menu v-if="!is_child" class="fe-event-card__menu" :event="event"></event-menu>
                        </div>
                        <p class="fe-event-card__meta">{{ startDate }}</p>
                        <p class="fe-event-card__meta fe-event-card__meta--venue">
                            <span v-if="isOnlineEvent" class="fe-event-card__venue-icon" aria-hidden="true">${Ge}</span>
                            <span v-else class="fe-event-card__venue-icon" aria-hidden="true">${qe}</span>
                            {{ isOnlineEvent ? t('Online') : t('In Person') }}
                        </p>
                    </div>
                </div>

                <div v-if="hasActions" class="fe-event-card__actions">
                    <span v-if="countLabel" class="fe-event-card__count">{{ countLabel }}</span>
                    <event-actions :event="event" @done="apply" @error="error = $event"></event-actions>
                </div>

                <p v-if="hasActions && unpublishedNote" class="fe-event-card__note">{{ unpublishedNote }}</p>
                <p v-if="error" class="fe-event-card__error" role="alert">{{ error }}</p>
            </template>
        </div>
    `};export{Ke as A,K as B,Ae as C,se as D,it as E,et as F,Ze as G,H as _,Ue as a,q as b,_e as c,Qe as d,Xe as e,$e as f,be as g,nt as h,Fe as i,we as j,ze as k,ge as l,te as m,le as n,J as o,L as p,He as q,st as r,rt as s,E as t,tt as u,ne as v,Be as w,Ve as x,We as y,Z as z};
