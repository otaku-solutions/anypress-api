import{b as S,h as v,u as j,f as I,t as b,a as D,v as F}from"./todoList-eAxCDaQj-3d75d375.js";import{h as N,l as R}from"./index.es-d8a42d74.js";import{u as h}from"./hooks-790a63b2.js";import{v as V}from"./index-0f4ad20e.js";import{i as H,a as M}from"./index.es-ce12dd0a.js";import"./core-986441f4.js";import"./admin-core-b51a4af0.js";var A=Object.defineProperty,g=Object.getOwnPropertySymbols,K=Object.prototype.hasOwnProperty,W=Object.prototype.propertyIsEnumerable,P=(l,e,n)=>e in l?A(l,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):l[e]=n,q=(l,e)=>{for(var n in e||(e={}))K.call(e,n)&&P(l,n,e[n]);if(g)for(var n of g(e))W.call(e,n)&&P(l,n,e[n]);return l};function U(l,e){return Object.assign(l,{meta:q({package:"@milkdown/components"},e)}),l}const z={imageIcon:()=>"🌌",uploadButton:()=>v`Upload`,confirmButton:()=>v`⏎`,uploadPlaceholderText:"/Paste",onUpload:l=>Promise.resolve(URL.createObjectURL(l))},_=N(z,"inlineImageConfigCtx");U(_,{displayName:"Config<image-inline>",group:"ImageInline"});function G(l,e){const n=customElements.get(l);if(n==null){customElements.define(l,e);return}n!==e&&console.warn(`Custom element ${l} has been defined before.`)}var J=(l,e,n)=>new Promise((d,t)=>{var a=r=>{try{o(n.next(r))}catch(u){t(u)}},s=r=>{try{o(n.throw(r))}catch(u){t(u)}},o=r=>r.done?d(r.value):Promise.resolve(r.value).then(a,s);o((n=n.apply(l,e)).next())});const C=({src:l="",selected:e=!1,alt:n,title:d,setAttr:t,config:a})=>{const s=j(),[o]=h(crypto.randomUUID()),[r,u]=h(!1),[f,p]=h(l.length!==0),[k,B]=h(l),O=i=>{const m=i.target.value;p(m.length!==0),B(m)},x=i=>J(void 0,null,function*(){var c;const m=(c=i.target.files)==null?void 0:c[0];if(!m)return;const $=yield a==null?void 0:a.onUpload(m);$&&(t==null||t("src",$),p(!0))}),y=()=>{var i,c;t==null||t("src",(c=(i=s.current)==null?void 0:i.value)!=null?c:"")},E=i=>{i.key==="Enter"&&y()},L=i=>{i.preventDefault(),i.stopPropagation()},T=i=>{i.stopPropagation(),i.preventDefault()};return v`<host class=${I(e&&"selected",!l&&"empty")}>
    ${l?v`<img class="image-inline" src=${l} alt=${n} title=${d} />`:v`<div class="empty-image-inline">
        <div class="image-icon">
          ${a==null?void 0:a.imageIcon()}
        </div>
        <div class=${I("link-importer",r&&"focus")}>
          <input
            draggable="true"
            ref=${s}
            ondragstart=${L}
            class="link-input-area"
            value=${k}
            oninput=${O}
            onkeydown=${E}
            onfocus=${()=>u(!0)}
            onblur=${()=>u(!1)}
          />
          <div class=${I("placeholder",f&&"hidden")}>
            <input class="hidden" id=${o} type="file" accept="image/*" onchange=${x} />
            <label onpointerdown=${T} class="uploader" for=${o}>
              ${a==null?void 0:a.uploadButton()}
            </label>
            <span class="text" onclick=${()=>{var i;return(i=s.current)==null?void 0:i.focus()}}>
              ${a==null?void 0:a.uploadPlaceholderText}
            </span>
          </div>
        </div>
        <div
          class=${I("confirm",k.length===0&&"hidden")}
          onclick=${()=>y()}
        >
          ${a==null?void 0:a.confirmButton()}
        </div>
      </div>`}
  </host>`};C.props={src:String,alt:String,title:String,selected:Boolean,setAttr:Function,config:Object};const Q=S(C);G("milkdown-image-inline",Q);const w=R(V.node,l=>(e,n,d)=>{const t=document.createElement("milkdown-image-inline"),a=l.get(_.key),s=o=>{t.src=o.attrs.src,t.alt=o.attrs.alt,t.title=o.attrs.title};return s(e),t.selected=!1,t.setAttr=(o,r)=>{const u=d();u!=null&&n.dispatch(n.state.tr.setNodeAttribute(u,o,r))},t.config=a,{dom:t,update:o=>o.type!==e.type?!1:(s(o),!0),stopEvent:o=>!!(t.selected&&o.target instanceof HTMLInputElement),selectNode:()=>{t.selected=!0},deselectNode:()=>{t.selected=!1},destroy:()=>{t.remove()}}});U(w,{displayName:"NodeView<image-inline>",group:"ImageInline"});const X=[_,w],ae=(l,e)=>{l.config(n=>{n.update(_.key,d=>{var t,a,s,o,r,u;return{uploadButton:(t=e==null?void 0:e.inlineUploadButton)!=null?t:()=>"Upload",imageIcon:(a=e==null?void 0:e.inlineImageIcon)!=null?a:()=>b,confirmButton:(s=e==null?void 0:e.inlineConfirmButton)!=null?s:()=>D,uploadPlaceholderText:(o=e==null?void 0:e.inlineUploadPlaceholderText)!=null?o:"or paste link",onUpload:(u=(r=e==null?void 0:e.inlineOnUpload)!=null?r:e==null?void 0:e.onUpload)!=null?u:d.onUpload}}),n.update(H.key,d=>{var t,a,s,o,r,u,f,p;return{uploadButton:(t=e==null?void 0:e.blockUploadButton)!=null?t:()=>"Upload file",imageIcon:(a=e==null?void 0:e.blockImageIcon)!=null?a:()=>b,captionIcon:(s=e==null?void 0:e.blockCaptionIcon)!=null?s:()=>F,confirmButton:(o=e==null?void 0:e.blockConfirmButton)!=null?o:()=>"Confirm",captionPlaceholderText:(r=e==null?void 0:e.blockCaptionPlaceholderText)!=null?r:"Write Image Caption",uploadPlaceholderText:(u=e==null?void 0:e.blockUploadPlaceholderText)!=null?u:"or paste link",onUpload:(p=(f=e==null?void 0:e.blockOnUpload)!=null?f:e==null?void 0:e.onUpload)!=null?p:d.onUpload}})}).use(M).use(X)};export{ae as defineFeature};
