import{d as N}from"./index-Jvxff1vU-312577d3.js";import{b as P,i as W,d as G,h as z,f as k,j as D,k as U,s as V,l as j,m as q}from"./todoList-eAxCDaQj-3d75d375.js";import{G as J,A as K,b as C}from"./index.es-2c4fdb92.js";import{$ as Q,R as X,T as Y,x as Z,B,n as x,t as tt,z as ot,l as et}from"./index-0f4ad20e.js";import{T as A,L as R,j as T}from"./core-986441f4.js";import"./index.es-d8a42d74.js";import"./hooks-790a63b2.js";import"./index-08f1dc80.js";import"./admin-core-b51a4af0.js";const O=({ctx:t,hide:e,show:s,config:o})=>{var v,i,m,h,_,f,w,y,b,$;const I=W();G(()=>{I()},[s]);const u=n=>r=>{r.preventDefault(),t&&n(t),I()},c=n=>{if(!t)return!1;const r=t.get(R),{state:{doc:p,selection:E}}=r;return p.rangeHasMark(E.from,E.to,n)};return z`<host>
    <button
      class=${k("toolbar-item",t&&c(Q.type(t))&&"active")}
      onmousedown=${u(n=>{n.get(T).call(x.key)})}
    >
      ${(i=(v=o==null?void 0:o.boldIcon)==null?void 0:v.call(o))!=null?i:D}
    </button>
    <button
      class=${k("toolbar-item",t&&c(X.type(t))&&"active")}
      onmousedown=${u(n=>{n.get(T).call(tt.key)})}
    >
      ${(h=(m=o==null?void 0:o.italicIcon)==null?void 0:m.call(o))!=null?h:U}
    </button>
    <button
      class=${k("toolbar-item",t&&c(Y.type(t))&&"active")}
      onmousedown=${u(n=>{n.get(T).call(ot.key)})}
    >
      ${(f=(_=o==null?void 0:o.strikethroughIcon)==null?void 0:_.call(o))!=null?f:V}
    </button>
    <div class="divider"></div>
    <button
      class=${k("toolbar-item",t&&c(Z.type(t))&&"active")}
      onmousedown=${u(n=>{n.get(T).call(et.key)})}
    >
      ${(y=(w=o==null?void 0:o.codeIcon)==null?void 0:w.call(o))!=null?y:j}
    </button>
    <button
      class=${k("toolbar-item",t&&c(B.type(t))&&"active")}
      onmousedown=${u(n=>{const r=n.get(R),{selection:p}=r.state;if(c(B.type(n))){n.get(C.key).removeLink(p.from,p.to);return}n.get(C.key).addLink(p.from,p.to),e==null||e()})}
    >
      ${($=(b=o==null?void 0:o.linkIcon)==null?void 0:b.call(o))!=null?$:q}
    </button>
  </host>`};O.props={ctx:Object,hide:Function,show:Boolean,config:Object};const g=P(O);var H=t=>{throw TypeError(t)},M=(t,e,s)=>e.has(t)||H("Cannot "+s),a=(t,e,s)=>(M(t,e,"read from private field"),s?s.call(t):e.get(t)),S=(t,e,s)=>e.has(t)?H("Cannot add the same private member more than once"):e instanceof WeakSet?e.add(t):e.set(t,s),F=(t,e,s,o)=>(M(t,e,"write to private field"),o?o.call(t,s):e.set(t,s),s),d,l;const L=J("CREPE_TOOLBAR");class st{constructor(e,s,o){S(this,d),S(this,l),this.update=(i,m)=>{a(this,d).update(i,m)},this.destroy=()=>{a(this,d).destroy(),a(this,l).remove()},this.hide=()=>{a(this,d).hide()};const v=new g;F(this,l,v),a(this,l).ctx=e,a(this,l).hide=this.hide,a(this,l).config=o,F(this,d,new K({content:a(this,l),debounce:20,offset:10,shouldShow(i){const{doc:m,selection:h}=i.state,{empty:_,from:f,to:w}=h,y=!m.textBetween(f,w).length&&h instanceof A,b=!(h instanceof A),$=i.dom.getRootNode().activeElement,I=v.contains($),u=!i.hasFocus()&&!I,c=!i.editable;return!(u||b||_||y||c)}})),a(this,d).onShow=()=>{a(this,l).show=!0},a(this,d).onHide=()=>{a(this,l).show=!1},this.update(s)}}d=new WeakMap;l=new WeakMap;N("milkdown-toolbar",g);const ht=(t,e)=>{t.config(s=>{s.set(L.key,{view:o=>new st(s,o,e)})}).use(L)};export{ht as defineFeature};
