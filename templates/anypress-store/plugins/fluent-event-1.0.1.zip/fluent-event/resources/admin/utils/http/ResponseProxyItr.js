export default class ResponseProxyItr {

    constructor(response) {
        this.response = response;

        return new Proxy(this, {
            get: function(target, prop) {
                try {
                    if (typeof target[prop] === 'function') {
                        if (prop === Symbol.iterator) {
                            return target[Symbol.iterator].bind(target);
                        }
                        return target[prop].bind(target);
                    }

                    if (prop in target.response) {
                        return target.response[prop];
                    } else if (prop in target.response.responseJSON) {
                        return target.response.responseJSON[prop];
                    } else if (prop === 'errors') {
                        // A validation body is the field => rules map itself; a 404/403/WP_Error body is not.
                        const body = target.response.responseJSON;
                        return Object.values(body).every(rules => rules && typeof rules === 'object') ? body : undefined;
                    }
                } catch (e) {
                    return target.response;
                }
            },
            ownKeys(target) {
                return Object.keys(target.response.responseJSON);
            },
            getOwnPropertyDescriptor(target, prop) {
                return {
                    enumerable: true,
                    configurable: true,
                    value: target[prop]
                };
            }
        });
    }

    /**
     * Get all response data as a plain object.
     * @returns {Object}
     */
    all() {
        return this.response.responseJSON || {};
    }

    *iterator() {
        for (let i in this.response.responseJSON) {
            yield this.response.responseJSON[i];
        }
    }

    [Symbol.iterator]() {
        return this.iterator();
    }
}
