<?php

namespace ShippingForFluentCart\App\Carriers\Shippo;

use FluentCart\Api\StoreSettings;
use FluentCart\App\App;
use FluentCart\App\Helpers\Helper;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\Shipment;
use FluentCart\App\Modules\Shipping\Carriers\Core\AbstractShippingCarrier;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\App\Services\ShipmentService;
use FluentCart\App\Services\Shipments\ShipmentInstance;
use FluentCart\Framework\Support\Arr;
use FluentCart\App\Modules\Shipping\Carriers\Concerns\ProvidesLiveRates;
use FluentCart\App\Modules\Shipping\Carriers\Concerns\ProvidesSetupNotices;
use FluentCart\App\Modules\Shipping\Carriers\Concerns\WebhookOutcomes;

class ShippoCarrier extends AbstractShippingCarrier
{
    use ShippoSettingsPage;
    use ProvidesLiveRates;
    use ProvidesSetupNotices;
    use WebhookOutcomes;

    const SLUG = 'shippo';

    const CHECKOUT_TIMEOUT = 5;

    const LABEL_TIMEOUT = 30;

    // Order meta: core's attempt id (older core: requested rate id) => ['rate' => bought rate id, 'at' => time].
    const UNCONFIRMED_META = '_shippo_unconfirmed_rates';

    // Matches core's ShipmentService::UNCONFIRMED_SETTLE_SECONDS, so Check again and Mark resolved agree.
    const UNCONFIRMED_WINDOW = 5 * MINUTE_IN_SECONDS;

    const SETTINGS_TIMEOUT = 15;

    const WEBHOOK_TIMEOUT = 8;

    const RATE_PAGE_SIZE = 50;

    const MAX_RATE_PAGES = 5;

    const MAX_CARRIER_PAGES = 5;

    const PARCEL_PAGE_SIZE = 100;

    const MAX_PARCEL_PAGES = 10;

    // One parcel can carry several orders' shipments under one tracking number.
    const WEBHOOK_MAX_SHIPMENTS = 50;

    /**
     * fct_meta object_type of the parcel index: one row per parcel tracking number
     * (meta_key) and shipment (object_id), found through the (object_type, meta_key) index.
     */
    const PARCEL_INDEX = 'shippo_parcel';

    /** How long a quote's addresses and parcels are kept to check a later purchase against. */
    const QUOTE_BINDING_TTL = 7 * DAY_IN_SECONDS;

    /**
     * Refused by GET /shipments/{id}/rates/{code}. Every other FluentCart
     * currency was accepted when checked on 2026-10-22; MRO is retired (MRU).
     */
    const UNQUOTABLE_CURRENCIES = ['MRO'];

    /**
     * Labels bought in this request, keyed by transaction_id, until the
     * shipment row exists to hold their details.
     */
    protected static array $pendingLabels = [];

    public function meta(): array
    {
        return [
            'slug'         => self::SLUG,
            'name'         => 'Shippo (Beta)',
            'description'  => __('Multi-carrier shipping — live rates, label generation, and tracking via the Shippo API.', 'shipping-for-fluent-cart'),
            'supports'     => ['rates', 'labels', 'tracking'],
            'webhook_hint' => __('In Shippo, add it under Settings → API → Webhooks for track_updated only, as Test or Live to match your mode.', 'shipping-for-fluent-cart'),
        ];
    }

    public function fields(): array
    {
        // FluentCart that draws status strips gets the card layout; older ones keep this list.
        if ($this->drawsType('status')) {
            return $this->designedFields();
        }

        $labelsOn = ['key' => 'enable_labels', 'value' => 'yes'];

        $fields = [
            $this->section('section_connection', __('Connection', 'shipping-for-fluent-cart')),
            [
                'key'   => 'is_active',
                'type'  => 'toggle',
                'label' => __('Enable Shippo', 'shipping-for-fluent-cart'),
                'hint'  => __('Requires the API token for the selected connection mode.', 'shipping-for-fluent-cart'),
            ],
            [
                'key'     => 'sandbox_mode',
                'type'    => 'mode',
                'label'   => __('Connection Mode', 'shipping-for-fluent-cart'),
                'options' => [
                    [
                        'value'  => 'no',
                        'label'  => __('Live', 'shipping-for-fluent-cart'),
                        'hint'   => __('Uses your Shippo live token. Labels are real and billed.', 'shipping-for-fluent-cart'),
                        'fields' => [
                            [
                                'key'   => 'live_token',
                                'type'  => 'password',
                                'label' => __('Live Token', 'shipping-for-fluent-cart'),
                                'hint'  => __('Starts with shippo_live_.', 'shipping-for-fluent-cart'),
                            ],
                        ],
                    ],
                    [
                        'value'  => 'yes',
                        'label'  => __('Test', 'shipping-for-fluent-cart'),
                        'hint'   => __('Uses your Shippo test token. Labels are free and not shipped.', 'shipping-for-fluent-cart'),
                        'fields' => [
                            [
                                'key'   => 'test_token',
                                'type'  => 'password',
                                'label' => __('Test Token', 'shipping-for-fluent-cart'),
                                'hint'  => __('Starts with shippo_test_.', 'shipping-for-fluent-cart'),
                            ],
                        ],
                    ],
                ],
            ],
            $this->section('section_checkout', __('Checkout Rates', 'shipping-for-fluent-cart')),
            [
                'key'   => 'enable_rates',
                'type'  => 'toggle',
                'label' => __('Show Shippo Rates at Checkout', 'shipping-for-fluent-cart'),
                'hint'  => __('Offer live Shippo rates alongside your zone shipping methods.', 'shipping-for-fluent-cart'),
            ],
            [
                'key'     => 'unit_of_measurement',
                'type'    => 'select',
                'label'   => __('Unit of Measurement', 'shipping-for-fluent-cart'),
                'hint'    => __('For products and boxes without their own units. Used for rates and labels.', 'shipping-for-fluent-cart'),
                'options' => [
                    ['value' => '', 'label' => __('Same as Store Settings', 'shipping-for-fluent-cart')],
                    ['value' => 'metric', 'label' => __('Metric (kg / cm)', 'shipping-for-fluent-cart')],
                    ['value' => 'imperial', 'label' => __('Imperial (lb / in)', 'shipping-for-fluent-cart')],
                ],
            ],
            $this->section('section_labels', __('Labels', 'shipping-for-fluent-cart')),
            [
                'key'   => 'enable_labels',
                'type'  => 'toggle',
                'label' => __('Enable Label Generation', 'shipping-for-fluent-cart'),
                'hint'  => __('Quote and buy labels from the Create shipment form.', 'shipping-for-fluent-cart'),
            ],
            [
                'key'     => 'default_carrier',
                'type'    => 'select',
                'label'   => __('Preferred Carrier', 'shipping-for-fluent-cart'),
                'hint'    => __('Labels preselect this carrier\'s cheapest rate.', 'shipping-for-fluent-cart'),
                'options' => $this->carrierOptions(),
                'show_if' => $labelsOn,
            ],
            [
                'key'         => 'seller_phone',
                'type'        => 'text',
                'label'       => __('Seller Phone', 'shipping-for-fluent-cart'),
                'hint'        => __('Printed on labels. USPS requires it.', 'shipping-for-fluent-cart'),
                'placeholder' => '',
                'width'       => 'half',
                'show_if'     => $labelsOn,
            ],
            [
                'key'         => 'seller_email',
                'type'        => 'text',
                'label'       => __('Seller Email', 'shipping-for-fluent-cart'),
                'hint'        => __('Printed on labels. USPS requires it.', 'shipping-for-fluent-cart'),
                'placeholder' => 'shipping@example.com',
                'width'       => 'half',
                'show_if'     => $labelsOn,
            ],
            $this->section('section_tracking', __('Tracking', 'shipping-for-fluent-cart')),
            ['key' => 'webhook_url', 'type' => 'webhook_url'],
            [
                'key'   => 'rotate_webhook_secret',
                'type'  => 'toggle',
                'label' => __('Rotate Webhook Secret', 'shipping-for-fluent-cart'),
                'hint'  => __('Turn on and save to issue a new webhook URL. The old URL stops working: paste the new one into Shippo.', 'shipping-for-fluent-cart'),
            ],
        ];

        // The carrier list loads with the current mode's token; without one there is nothing to pick.
        $hasToken = $this->tokenFor($this->isSandbox()) !== '';

        return array_values(array_filter($fields, function ($field) use ($hasToken) {
            if ($field['key'] === 'default_carrier' && !$hasToken) {
                return false;
            }
            return !in_array($field['type'], ['section', 'webhook_url'], true) || $this->drawsType($field['type']);
        }));
    }

    /**
     * FluentCart 2.3.0 draws an unknown field type as a text input, so a section
     * heading or the webhook URL's place is declared only when core lists its type
     * in FIELD_TYPES. Without the place, core draws the URL after the form.
     */
    protected function drawsType(string $type): bool
    {
        $types = '\FluentCart\App\Modules\Shipping\Carriers\Core\CarrierManager::FIELD_TYPES';

        return defined($types) && in_array($type, constant($types), true);
    }

    protected function section(string $key, string $label, string $hint = ''): array
    {
        return array_filter(['key' => $key, 'type' => 'section', 'label' => $label, 'hint' => $hint]);
    }

    public function isEnabled(): bool
    {
        return $this->settings->get('is_active') === 'yes' && $this->tokenFor($this->isSandbox()) !== '';
    }

    /**
     * Stored settings only: core calls this on every carriers-list load.
     */
    public function getSetupNotices(): array
    {
        if ($this->settings->get('is_active') !== 'yes') {
            return [];
        }

        $notices = [];
        if ($this->tokenFor($this->isSandbox()) === '') {
            $notices[] = $this->setupNotice('error', $this->isSandbox()
                ? __('Shippo is enabled in Test mode but has no test token, so rates, labels and tracking are off. Add the test token or switch to Live.', 'shipping-for-fluent-cart')
                : __('Shippo is enabled in Live mode but has no live token, so rates, labels and tracking are off. Add the live token or switch to Test.', 'shipping-for-fluent-cart'));
        }

        $usesOrigin = $this->settings->get('enable_rates') === 'yes' || $this->settings->get('enable_labels') === 'yes';
        if ($usesOrigin && ($notice = $this->originSetupNotice('Shippo'))) {
            $notices[] = $notice;
        }

        $base = $this->baseCurrency();
        if ($this->settings->get('enable_rates') === 'yes' && !$this->canQuoteInCurrency($base)) {
            $notices[] = $this->setupNotice('error', sprintf(
                /* translators: %s: store currency code, e.g. MRO */
                __('Shippo cannot quote rates in %s, your store currency, so Shippo rates are not shown at checkout. Labels and tracking still work.', 'shipping-for-fluent-cart'),
                $base
            ));
        }

        return $notices;
    }

    /**
     * Shippo converts its rates into nearly any currency (rates/{code}).
     */
    public function canQuoteInCurrency(string $currency): ?bool
    {
        $currency = strtoupper(trim($currency));

        return (bool) preg_match('/^[A-Z]{3}$/', $currency) && !in_array($currency, self::UNQUOTABLE_CURRENCIES, true);
    }

    public function boot(): void
    {
        add_action('fluent_cart/order_shipment_created', [$this, 'attachLabelDetails'], 10, 1);
        add_action('fluent_cart/shipping/unconfirmed_purchase_resolved', [$this, 'dropResolvedHold'], 10, 3);
    }

    public function isSandbox(): bool
    {
        return $this->settings->get('sandbox_mode') === 'yes';
    }

    public function tokenFor(bool $test): string
    {
        return trim((string) $this->settings->get($test ? 'test_token' : 'live_token'));
    }

    /**
     * @param bool|null $test Token mode; null = the active mode.
     */
    public function client(?bool $test = null): ShippoClient
    {
        return new ShippoClient($this->tokenFor($test === null ? $this->isSandbox() : $test));
    }

    protected function labelsEnabled(): bool
    {
        return $this->isEnabled() && $this->settings->get('enable_labels') === 'yes';
    }

    protected function packaging(): ShippoPackaging
    {
        return new ShippoPackaging($this->usesImperialUnits());
    }

    /* ---------------------------------------------------------------- rates */

    protected function liveRatesCacheItemsKey(array $items): string
    {
        // Mode too: test and live accounts price differently.
        return ($this->isSandbox() ? 't' : 'l') . $this->packaging()->checkoutCacheKey($items);
    }

    protected function fetchLiveRates(array $destination, array $items, string $currency)
    {
        $origin = $this->buildOrigin();
        if (!$origin['country'] || !$origin['postcode']) {
            return [];
        }

        // DHL Express quotes only with both phones and the recipient's name and street.
        // Cores before the checkout contact send no name/address_1/phone.
        $payload = [
            'address_from' => $this->addressFrom(),
            'address_to'   => [
                'name'    => $destination['name'] ?? '',
                'street1' => $destination['address_1'] ?? '',
                'phone'   => $destination['phone'] ?? '',
                'city'    => $destination['city'],
                'state'   => $destination['state'],
                'zip'     => $destination['postcode'],
                'country' => $destination['country'],
            ],
            'parcels'      => $this->packaging()->checkoutParcels($items),
            'async'        => false,
        ];

        $client = $this->client();
        $result = $client->request('POST', '/shipments', $payload, self::CHECKOUT_TIMEOUT);
        if (is_wp_error($result)) {
            return $result;
        }

        if ($this->hasTransientRateMessage($result)) {
            $this->markLiveRatesPartial();
        }

        $rates = [];
        foreach ($this->ratesInCurrency($client, $result, $currency, self::CHECKOUT_TIMEOUT) as $rate) {
            $id = $this->rateId($rate);
            if ($id === '' || !is_numeric(Arr::get($rate, 'amount'))) {
                continue;
            }

            $mapped = [
                'id'               => $id,
                'carrier'          => self::SLUG,
                'title'            => $this->serviceTitle($rate),
                'cost'             => Helper::toCent(Arr::get($rate, 'amount')),
                'currency'         => strtoupper((string) Arr::get($rate, 'currency', '')),
                'states'           => [],
                'description'      => '',
                'estimated_days'   => max(0, (int) Arr::get($rate, 'estimated_days', 0)),
                'provider_rate_id' => sanitize_text_field((string) Arr::get($rate, 'object_id', '')),
            ];

            // One entry per service: keep the cheapest if Shippo repeats one.
            if (!isset($rates[$id]) || $mapped['cost'] < $rates[$id]['cost']) {
                $rates[$id] = $mapped;
            }
        }

        return array_values($rates);
    }

    /**
     * Rates priced in $currency. Shippo prices in the account's currency
     * (`amount`) and the destination's (`amount_local`); when neither is
     * $currency, it re-reads them converted. On failure the native rates come
     * back and the currency guard drops them.
     */
    protected function ratesInCurrency(ShippoClient $client, array $shipment, string $currency, int $timeout): array
    {
        $rates      = array_map(function ($rate) use ($currency) {
            return $this->priceInCurrency($rate, $currency);
        }, array_values(array_filter((array) Arr::get($shipment, 'rates', []), 'is_array')));
        $shipmentId = (string) Arr::get($shipment, 'object_id', '');

        $foreign = array_filter($rates, function ($rate) use ($currency) {
            return strtoupper((string) Arr::get($rate, 'currency', '')) !== $currency;
        });

        if (!$foreign || $shipmentId === '') {
            return $rates;
        }

        $converted = [];
        for ($page = 1; $page <= self::MAX_RATE_PAGES; $page++) {
            $response = $client->request('GET', '/shipments/' . $shipmentId . '/rates/' . $currency, [
                'results' => self::RATE_PAGE_SIZE,
                'page'    => $page,
            ], $timeout);

            if (is_wp_error($response)) {
                $this->markLiveRatesPartial();
                return $converted ?: $rates;
            }

            foreach ((array) Arr::get($response, 'results', []) as $rate) {
                if (is_array($rate)) {
                    $converted[] = $this->priceInCurrency($rate, $currency);
                }
            }

            if (empty($response['next'])) {
                break;
            }
        }

        return $converted ?: $rates;
    }

    /**
     * Moves `amount_local` into `amount` when it is the currency wanted.
     */
    protected function priceInCurrency(array $rate, string $currency): array
    {
        if (strtoupper((string) Arr::get($rate, 'currency', '')) !== $currency
            && strtoupper((string) Arr::get($rate, 'currency_local', '')) === $currency
            && is_numeric(Arr::get($rate, 'amount_local'))) {
            $rate['amount']   = $rate['amount_local'];
            $rate['currency'] = $currency;
        }

        return $rate;
    }

    /**
     * Whether a carrier behind Shippo failed for a passing reason (UPS answers
     * "Too Many Requests", code 10429), so the rate list may be missing services.
     * Lane refusals ("doesn't support", "out of service area") are not passing.
     */
    protected function hasTransientRateMessage(array $shipment): bool
    {
        foreach ((array) Arr::get($shipment, 'messages', []) as $message) {
            $code = (string) Arr::get((array) $message, 'code', '');
            $text = (string) Arr::get((array) $message, 'text', '');

            if (in_array($code, ['429', '10429'], true)
                || preg_match('/too many requests|rate limit|timed out|timeout|try again|temporar|internal (server )?error|service unavailable/i', $text)) {
                return true;
            }
        }

        return false;
    }

    /**
     * String token, never numeric, so it cannot collide with a zone method id.
     */
    protected function rateId(array $rate): string
    {
        $token = strtolower((string) Arr::get($rate, 'servicelevel.token', ''));
        $token = preg_replace('/[^a-z0-9_\-]/', '', $token);

        return $token !== '' ? 'carrier:' . self::SLUG . ':' . $token : '';
    }

    protected function serviceTitle(array $rate): string
    {
        $provider = sanitize_text_field((string) Arr::get($rate, 'provider', ''));
        $service  = sanitize_text_field((string) Arr::get($rate, 'servicelevel.name', ''));

        if ($provider === '') {
            return $service;
        }

        /* translators: %1$s: carrier name e.g. USPS, %2$s: service name e.g. Priority Mail */
        return sprintf(__('%1$s — %2$s', 'shipping-for-fluent-cart'), $provider, $service !== '' ? $service : $provider);
    }

    /* ------------------------------------------------------- quote / label */

    public function getShipmentQuote(ShipmentInstance $instance)
    {
        if (!$this->labelsEnabled()) {
            return new \WP_Error('shippo_labels_disabled', __('Label generation is turned off in Shippo settings.', 'shipping-for-fluent-cart'));
        }

        $addressTo = $this->orderAddressTo($instance->order);
        if (is_wp_error($addressTo)) {
            return $addressTo;
        }

        $packaging   = $this->packaging();
        $lines       = $packaging->dispatchedLines($instance->order, $instance->items);
        $addressFrom = $this->addressFrom();
        $parcels     = $packaging->dispatchParcels($lines);
        $client      = $this->client();
        $payload     = [
            'address_from' => $addressFrom,
            'address_to'   => $addressTo,
            'parcels'      => $parcels,
            'async'        => false,
        ];

        // The label carries customs, and they can change the price, so the quote carries them too.
        if (ShippoPackaging::needsCustoms($addressFrom['country'], $addressTo['country'])) {
            $declaration = $this->declareCustoms($client, $packaging->customsItems($lines, $addressFrom['country'], (string) ($instance->order->currency ?: $this->baseCurrency())));
            if (is_wp_error($declaration)) {
                return $declaration;
            }
            $payload['customs_declaration'] = $declaration;
        }

        $result = $client->request('POST', '/shipments', $payload, self::LABEL_TIMEOUT);

        if (is_wp_error($result)) {
            return $result;
        }

        // A domestic label buys a quoted rate as it is, so the purchase is checked against what was quoted.
        $shipmentId = sanitize_text_field((string) Arr::get($result, 'object_id', ''));
        if ($shipmentId !== '') {
            set_transient($this->quoteBindingKey($shipmentId), $this->quoteFingerprint((int) $instance->order->id, $addressFrom, $addressTo, $parcels), self::QUOTE_BINDING_TTL);
        }

        // Merchant cost: kept in the currency Shippo bills, never converted.
        $rates = [];
        foreach ((array) Arr::get($result, 'rates', []) as $rate) {
            if (!is_array($rate) || !Arr::get($rate, 'object_id') || !is_numeric(Arr::get($rate, 'amount'))) {
                continue;
            }
            $rates[] = [
                'rate_object_id' => sanitize_text_field((string) $rate['object_id']),
                'service_name'   => $this->serviceTitle($rate),
                'cost_cents'     => Helper::toCent($rate['amount']),
                'currency'       => strtoupper((string) Arr::get($rate, 'currency', '')),
                'estimated_days' => max(0, (int) Arr::get($rate, 'estimated_days', 0)),
                '_rate_id'       => $this->rateId($rate),
                '_provider'      => strtolower((string) Arr::get($rate, 'provider', '')),
            ];
        }

        if (!$rates) {
            return new \WP_Error('shippo_no_rates', __('No rates available from Shippo for this shipment.', 'shipping-for-fluent-cart'));
        }

        usort($rates, function ($a, $b) {
            return $a['cost_cents'] <=> $b['cost_cents'];
        });

        $selected = $this->preselectQuoteRate($rates, $instance->order);

        return [
            'rate_object_id' => $selected['rate_object_id'],
            'rates'          => array_map(function ($rate) {
                unset($rate['_rate_id'], $rate['_provider']);
                return $rate;
            }, $rates),
        ];
    }

    /**
     * @return string|\WP_Error The customs declaration's object id.
     */
    protected function declareCustoms(ShippoClient $client, array $items)
    {
        $declaration = $client->request('POST', '/customs/declarations', [
            'contents_type'       => 'MERCHANDISE',
            'non_delivery_option' => 'RETURN',
            'certify'             => true,
            'certify_signer'      => $this->storeName(),
            'eel_pfc'             => 'NOEEI_30_37_a',
            'items'               => $items,
        ], self::LABEL_TIMEOUT);

        return is_wp_error($declaration) ? $declaration : (string) Arr::get($declaration, 'object_id', '');
    }

    /**
     * The service the customer paid for, else the preferred carrier's cheapest,
     * else the cheapest. $rates is sorted cheapest first.
     */
    protected function preselectQuoteRate(array $rates, Order $order): array
    {
        $config   = is_array($order->config) ? $order->config : [];
        $methodId = (string) Arr::get($config, 'shipping_method_id', '');
        $title    = (string) Arr::get($config, 'shipping_method_title', '');
        $carrier  = (string) Arr::get($config, 'shipping_carrier', '');

        // The service token is the identity. Checked over every rate before the
        // title, or a cheaper rate matching the title would win.
        foreach ($rates as $rate) {
            if ($methodId !== '' && $rate['_rate_id'] === $methodId) {
                return $rate;
            }
        }

        // Title only for a Shippo order whose id no longer resolves (older id format).
        if ($title !== '' && in_array($carrier, ['', self::SLUG], true)) {
            foreach ($rates as $rate) {
                if ($rate['service_name'] === $title) {
                    return $rate;
                }
            }
        }

        foreach ($rates as $rate) {
            if ($this->isPreferredCarrier($rate['_provider'])) {
                return $rate;
            }
        }

        return $rates[0];
    }

    public function supportsUnconfirmedRecheck(): bool
    {
        return true;
    }

    /**
     * Core's "Check again" replays the saved request with this flag: look up, never buy.
     * Core has not settled where the flag lives, so every candidate spot is read.
     */
    protected function isLookupOnly(ShipmentInstance $instance): bool
    {
        return !empty($instance->lookup_only)
            || !empty(Arr::get($instance->data, 'lookup_only'))
            || !empty(Arr::get($instance->data, 'meta.lookup_only'))
            || !empty(Arr::get($instance->data, 'args.lookup_only'));
    }

    public function makeShipmentFromShipmentInstance(ShipmentInstance $instance)
    {
        // Before any validation: a paid label must be found even if the order changed since.
        if ($this->isLookupOnly($instance)) {
            return $this->recheckUnconfirmed($instance);
        }

        if (!$this->labelsEnabled()) {
            return null;
        }

        // Shippo would refuse it only after creating a shipment it keeps as errored.
        if (!static::isValidPhone((string) $this->settings->get('seller_phone'))) {
            return new \WP_Error('shippo_seller_phone', static::sellerPhoneMessage());
        }

        $order     = $instance->order;
        $rateId    = sanitize_text_field((string) Arr::get($instance->data, 'selected_rate_id', ''));
        $attemptId = sanitize_text_field((string) Arr::get($instance->data, 'unconfirmed_id', ''));
        $addressTo = $this->orderAddressTo($order);
        if (is_wp_error($addressTo)) {
            return $addressTo;
        }

        $packaging = $this->packaging();
        $lines     = $packaging->dispatchedLines($order, $instance->items);
        if (!$lines) {
            return new \WP_Error('shippo_no_items', __('No shippable items were selected for this label.', 'shipping-for-fluent-cart'));
        }

        $addressFrom = $this->addressFrom();
        $customs     = [];
        if (ShippoPackaging::needsCustoms($addressFrom['country'], $addressTo['country'])) {
            $customs = $packaging->customsItems($lines, $addressFrom['country'], (string) ($order->currency ?: $this->baseCurrency()));
        }

        return $this->buyLabel([
            'address_from' => $addressFrom,
            'address_to'   => $addressTo,
            'parcels'      => $packaging->dispatchParcels($lines),
            'customs'      => $customs,
            'metadata'     => $this->labelMetadata($order),
            'order_id'     => (int) $order->id,
            'order'        => $order,
            'rate_id'      => $rateId,
            'attempt'      => $attemptId,
            'hold_key'     => $attemptId !== '' ? $attemptId : $rateId,
        ]);
    }

    /**
     * Looks up only the replayed attempt's hold and never changes the holds:
     * core drops a hold through the resolved action once it has saved the outcome.
     *
     * @return array|\WP_Error
     */
    protected function recheckUnconfirmed(ShipmentInstance $instance)
    {
        $held = $this->holdsFor($instance->order, sanitize_text_field((string) Arr::get($instance->data, 'unconfirmed_id', '')));
        $found = $this->resumeUnconfirmed($this->client(), ['order' => $instance->order], $held, false);
        if ($found !== null) {
            return $found;
        }

        return new \WP_Error(
            'shippo_label_not_found',
            __('No label was found at Shippo for this order. You can buy a new one.', 'shipping-for-fluent-cart'),
            ['purchase_unconfirmed' => false]
        );
    }

    /**
     * Buys exactly one label set. A purchase whose outcome is unknown (timeout,
     * 5xx) is never retried: the label may exist and a retry would buy it twice.
     *
     * @return array|\WP_Error
     */
    protected function buyLabel(array $request)
    {
        $client = $this->client();
        $rateId = $request['rate_id'];
        $wanted = null;
        $rate   = null;
        $txn    = null;

        if ($request['attempt'] !== '') {
            // Core owns other attempts: they settle through their own Check again or Mark resolved.
            $this->releaseOrphanHolds($request['order'], $request['attempt']);
            if (array_diff_key($this->holds($request['order']), [$request['hold_key'] => true])) {
                return $this->pendingHoldError(true);
            }
        } else {
            $held = $this->resumeUnconfirmed($client, $request, $this->holds($request['order']), true);
            if ($held !== null) {
                return $held;
            }
        }

        if ($rateId !== '') {
            $wanted = $client->request('GET', '/rates/' . $rateId, [], self::LABEL_TIMEOUT);
            if (is_wp_error($wanted)) {
                return ShippoClient::isDefiniteRejection($wanted)
                    ? new \WP_Error('shippo_rate_expired', __('The selected rate is no longer available. Refresh the rates and pick one again.', 'shipping-for-fluent-cart'))
                    : $wanted;
            }
        }

        // The quoted rate has no customs, so it can be bought as-is only domestically, and only
        // while its stored quote matches the current inputs. Without that record (expired, or
        // flushed from the cache) the same service is bought on a fresh shipment below. The
        // check runs before any hold, so a refused label leaves no hold behind.
        $bound = $wanted ? get_transient($this->quoteBindingKey(sanitize_text_field((string) Arr::get($wanted, 'shipment', '')))) : false;
        $now   = $this->quoteFingerprint((int) $request['order_id'], $request['address_from'], $request['address_to'], $request['parcels']);
        if (is_string($bound) && $bound !== $now) {
            return new \WP_Error('shippo_quote_stale', __('The order, its items or the store address changed after these rates were quoted. Refresh the rates and pick one again. No label was bought.', 'shipping-for-fluent-cart'));
        }

        if ($wanted && !$request['customs'] && $bound === $now) {
            if (!$this->holdPurchase($request, $rateId)) {
                return $this->pendingHoldError(true);
            }
            $txn = $this->purchase($client, $request, $rateId);
            if (is_wp_error($txn)) {
                if (!ShippoClient::isDefiniteRejection($txn)) {
                    return $this->confirmOrHold($client, $request, $wanted, $this->uncertainPurchaseError($txn));
                }
                if (!$this->isStaleRateError($txn->get_error_message())) {
                    return $this->friendlyLabelError($txn, $wanted, $request['order_id']);
                }
                $txn = null; // Nothing was bought; re-quote the same service.
            } elseif (strtoupper((string) Arr::get($txn, 'status', '')) === 'ERROR'
                && $this->isStaleRateError(ShippoClient::errorText($txn))) {
                $txn = null;
            } else {
                $rate = $wanted;
            }
        }

        if (!$txn) {
            $shipmentPayload = [
                'address_from' => $request['address_from'],
                'address_to'   => $request['address_to'],
                'parcels'      => $request['parcels'],
                'async'        => false,
                'metadata'     => $request['metadata'],
            ];

            if ($request['customs']) {
                $declaration = $this->declareCustoms($client, $request['customs']);
                if (is_wp_error($declaration)) {
                    return $declaration;
                }
                $shipmentPayload['customs_declaration'] = $declaration;
            }

            $shipment = $client->request('POST', '/shipments', $shipmentPayload, self::LABEL_TIMEOUT);
            if (is_wp_error($shipment)) {
                return $this->friendlyLabelError($shipment, $wanted, $request['order_id']);
            }

            $rate = $this->matchRate((array) Arr::get($shipment, 'rates', []), $wanted);
            if (!$rate) {
                return new \WP_Error(
                    'shippo_no_rates',
                    $wanted
                        ? __('The selected service is not offered for this shipment any more. Refresh the rates and pick one again.', 'shipping-for-fluent-cart')
                        : __('No rates returned by Shippo for this shipment. Check the shipping address.', 'shipping-for-fluent-cart')
                );
            }

            // The admin confirmed the picked rate's price; a fresh shipment may price the
            // service higher, or in another currency, so that needs a new confirmation.
            // Checked before the hold, so a refused label leaves no hold behind.
            if ($wanted && $this->costsMoreThan($rate, $wanted)) {
                return new \WP_Error('shippo_rate_changed', sprintf(
                    /* translators: %1$s: confirmed price, e.g. 7.35 USD, %2$s: new price */
                    __('The rate changed from %1$s to %2$s since you confirmed it. Refresh the rates and confirm the new price. No label was bought.', 'shipping-for-fluent-cart'),
                    $this->priceText($wanted),
                    $this->priceText($rate)
                ));
            }

            if (!$this->holdPurchase($request, (string) Arr::get($rate, 'object_id', ''))) {
                return $this->pendingHoldError(true);
            }
            $txn = $this->purchase($client, $request, (string) Arr::get($rate, 'object_id', ''));
            if (is_wp_error($txn)) {
                return ShippoClient::isDefiniteRejection($txn)
                    ? $this->friendlyLabelError($txn, $rate, $request['order_id'])
                    : $this->confirmOrHold($client, $request, $rate, $this->uncertainPurchaseError($txn));
            }
        }

        $status = strtoupper((string) Arr::get($txn, 'status', ''));
        if ($status === 'ERROR') {
            $detail = ShippoClient::errorText($txn);
            $refusal = new \WP_Error('shippo_label', $detail !== '' ? $detail : __('Shippo could not generate a label for this shipment.', 'shipping-for-fluent-cart'));

            return $this->friendlyLabelError($refusal, $rate, $request['order_id']);
        }

        if ($status !== 'SUCCESS') {
            // QUEUED / WAITING: Shippo may still finish it, so never buy again.
            return $this->confirmOrHold($client, $request, $rate, new \WP_Error(
                'shippo_label_pending',
                __('Shippo has not finished the label yet. Check your Shippo dashboard before trying again, so the label is not bought twice.', 'shipping-for-fluent-cart'),
                ['purchase_unconfirmed' => true]
            ));
        }

        return $this->boughtLabel($client, $request, $txn, $rate, $request['hold_key']);
    }

    /**
     * @param string|null $holdKey The hold this label settles; null leaves the holds alone.
     * @return array|\WP_Error
     */
    protected function boughtLabel(ShippoClient $client, array $request, array $txn, ?array $rate, ?string $holdKey)
    {
        // With core's attempt ids the hold stays until core has recorded the label (resolved action).
        if ($holdKey !== null && Arr::get($request, 'attempt', '') === '') {
            $this->forgetUnconfirmed($request['order'], $holdKey);
        }

        $parcels = isset($request['parcel_count']) ? $request['parcel_count'] : count($request['parcels']);

        return $this->labelResult($client, $txn, $rate, $parcels);
    }

    /**
     * After an unconfirmed purchase: use the label if Shippo has it, else keep the
     * hold so the next attempt looks it up instead of buying again.
     *
     * @return array|\WP_Error
     */
    protected function confirmOrHold(ShippoClient $client, array $request, ?array $rate, \WP_Error $error)
    {
        $boughtId = (string) Arr::get($rate, 'object_id', $request['rate_id']);
        $found    = $boughtId !== '' ? $this->parcelTransactions($client, $boughtId, 1) : [];

        // Not found: the hold written before the purchase stays.
        return $found && !is_wp_error($found) ? $this->boughtLabel($client, $request, $found[0], $rate, $request['hold_key']) : $error;
    }

    /**
     * Looks up the given holds. Null means none is pending. With $settle (a purchase on
     * core without attempt ids), a found hold is used and forgotten and an expired empty one released.
     *
     * @return array|\WP_Error|null
     */
    protected function resumeUnconfirmed(ShippoClient $client, array $request, array $held, bool $settle)
    {
        $pending = false;
        foreach ($held as $key => $entry) {
            $boughtId = (string) Arr::get($entry, 'rate', '');
            $found    = $boughtId !== '' ? $this->parcelTransactions($client, $boughtId, 1) : [];
            if ($found && !is_wp_error($found)) {
                $rate = $client->request('GET', '/rates/' . $boughtId, [], self::LABEL_TIMEOUT);
                $request['parcel_count'] = max(1, (int) Arr::get($entry, 'parcels', 1));

                return $this->boughtLabel($client, $request, $found[0], is_wp_error($rate) ? null : $rate, $settle ? (string) $key : null);
            }

            // Only a lookup that answered "no label" may release an old hold.
            if (!is_wp_error($found) && time() - (int) Arr::get($entry, 'at', 0) >= self::UNCONFIRMED_WINDOW) {
                if ($settle) {
                    $this->forgetUnconfirmed($request['order'], (string) $key);
                }
            } else {
                $pending = true;
            }
        }

        // Any rate: a fresh quote has new rate ids, so it would bypass a per-rate hold.
        return $pending ? $this->pendingHoldError($settle) : null;
    }

    /**
     * @param bool $refusedPurchase A purchase stopped before sending, so core can drop its attempt.
     */
    protected function pendingHoldError(bool $refusedPurchase): \WP_Error
    {
        return new \WP_Error(
            'shippo_purchase_unconfirmed',
            __('A Shippo label for this order is still unconfirmed. Check your Shippo dashboard, or try again after a few minutes: the label may already have been bought.', 'shipping-for-fluent-cart'),
            $refusedPurchase ? ['purchase_unconfirmed' => true, 'purchase_sent' => false] : ['purchase_unconfirmed' => true]
        );
    }

    protected function holds(Order $order): array
    {
        $held = $order->getMeta(self::UNCONFIRMED_META, []);

        return is_array($held) ? $held : [];
    }

    /**
     * The attempt's own hold. Holds saved before core sent attempt ids are keyed by
     * rate id, so an attempt without its own hold falls back to those.
     */
    protected function holdsFor(Order $order, string $attemptId): array
    {
        $held = $this->holds($order);

        return $attemptId !== '' && isset($held[$attemptId]) ? [$attemptId => $held[$attemptId]] : static::legacyHolds($held);
    }

    protected static function legacyHolds(array $held): array
    {
        return array_filter($held, function ($entry) {
            return empty($entry['attempt']);
        });
    }

    /**
     * Read-modify-write under core's order lock, so concurrent requests never drop each other's hold.
     */
    protected function changeHolds(Order $order, callable $change): void
    {
        $locks = method_exists(ShipmentService::class, 'lockOrderForShipping');
        $write = function () use ($order, $change, $locks) {
            if ($locks) {
                ShipmentService::lockOrderForShipping($order->id);
            }
            $held = $change($this->holds($order));
            $held ? $order->updateMeta(self::UNCONFIRMED_META, $held) : $order->deleteMeta(self::UNCONFIRMED_META);
        };

        $locks ? App::db()->transaction($write) : $write();
    }

    /**
     * A hold whose attempt core no longer lists has no note to resolve it, so it would block
     * Shippo labels for good. Rate-keyed holds predate attempt ids: kept while core has another Shippo entry.
     */
    protected function releaseOrphanHolds(Order $order, string $attemptId): void
    {
        if (!method_exists(ShipmentService::class, 'unconfirmedShipments')) {
            return;
        }

        $this->changeHolds($order, function (array $held) use ($order, $attemptId) {
            $pending = [];
            foreach (ShipmentService::unconfirmedShipments($order) as $entry) {
                if (Arr::get($entry, 'carrier') === self::SLUG && (string) Arr::get($entry, 'id', '') !== $attemptId) {
                    $pending[] = (string) Arr::get($entry, 'id', '');
                }
            }

            foreach ($held as $key => $entry) {
                if (empty($entry['attempt']) ? !$pending : !in_array((string) $key, $pending, true)) {
                    unset($held[$key]);
                }
            }

            return $held;
        });
    }

    protected function forgetUnconfirmed(Order $order, string $key): void
    {
        $this->changeHolds($order, function (array $held) use ($key) {
            unset($held[$key]);

            return $held;
        });
    }

    /**
     * Core saved the outcome of an unconfirmed attempt, so its hold is no longer needed.
     */
    public function dropResolvedHold($attemptId, $carrierSlug, $order): void
    {
        if ($carrierSlug !== self::SLUG || !$order instanceof Order) {
            return;
        }

        $this->changeHolds($order, function (array $held) use ($attemptId) {
            if (isset($held[(string) $attemptId])) {
                unset($held[(string) $attemptId]);

                return $held;
            }

            // An entry saved before attempt ids existed: its holds are the rate-keyed ones.
            return array_diff_key($held, static::legacyHolds($held));
        });
    }

    /**
     * Only an expired or unknown rate is worth a fresh shipment. Any other refusal
     * (address or field data) would fail again and leave another errored shipment.
     */
    protected function costsMoreThan(array $rate, array $confirmed): bool
    {
        if (strtoupper((string) Arr::get($rate, 'currency', '')) !== strtoupper((string) Arr::get($confirmed, 'currency', ''))) {
            return true;
        }

        return Helper::toCent(Arr::get($rate, 'amount', 0)) > Helper::toCent(Arr::get($confirmed, 'amount', 0));
    }

    protected function priceText(array $rate): string
    {
        return sanitize_text_field((string) Arr::get($rate, 'amount', '')) . ' ' . strtoupper(sanitize_text_field((string) Arr::get($rate, 'currency', '')));
    }

    protected function quoteBindingKey(string $shipmentId): string
    {
        return 'fct_shippo_quote_' . md5($shipmentId);
    }

    protected function quoteFingerprint(int $orderId, array $addressFrom, array $addressTo, array $parcels): string
    {
        return md5((string) wp_json_encode([$orderId, $this->isSandbox(), $addressFrom, $addressTo, $parcels]));
    }

    protected function isStaleRateError(string $message): bool
    {
        return !preg_match('/address_(from|to)\b/i', $message) && preg_match('/\brates?\b/i', $message);
    }

    /**
     * Holds the rate before sending, so a PHP process killed mid-call still leaves a record.
     * False when another purchase was held since the holds were checked: do not send.
     */
    protected function holdPurchase(array $request, string $rateObjectId): bool
    {
        $entry = ['rate' => $rateObjectId, 'parcels' => count($request['parcels']), 'at' => time()];
        if ($request['attempt'] !== '') {
            $entry['attempt'] = true;
        }

        $held = false;
        $this->changeHolds($request['order'], function (array $holds) use ($request, $entry, &$held) {
            $held = (bool) array_diff_key($holds, [$request['hold_key'] => true]);
            if (!$held) {
                $holds[$request['hold_key']] = $entry;
            }

            return $holds;
        });

        return !$held;
    }

    /**
     * @return array|\WP_Error Transaction object.
     */
    protected function purchase(ShippoClient $client, array $request, string $rateObjectId)
    {
        $txn = $client->request('POST', '/transactions', [
            'rate'            => $rateObjectId,
            'label_file_type' => 'PDF',
            'async'           => false,
            'metadata'        => $request['metadata'],
        ], self::LABEL_TIMEOUT, ShippoClient::personalValues([Arr::get($request, 'address_from', []), Arr::get($request, 'address_to', [])]));

        // Nothing was bought.
        $refused = is_wp_error($txn)
            ? ShippoClient::isDefiniteRejection($txn)
            : strtoupper((string) Arr::get($txn, 'status', '')) === 'ERROR';
        if ($refused && $request['attempt'] === '') {
            $this->forgetUnconfirmed($request['order'], $request['hold_key']);
        }

        return $txn;
    }

    /**
     * The admin's service when one was picked; otherwise preferred carrier, then cheapest.
     */
    protected function matchRate(array $rates, ?array $wanted): ?array
    {
        $rates = array_values(array_filter($rates, function ($rate) {
            return is_array($rate) && Arr::get($rate, 'object_id') && is_numeric(Arr::get($rate, 'amount'));
        }));

        usort($rates, function ($a, $b) {
            return (float) $a['amount'] <=> (float) $b['amount'];
        });

        if ($wanted) {
            $token    = (string) Arr::get($wanted, 'servicelevel.token', '');
            $provider = strtolower((string) Arr::get($wanted, 'provider', ''));
            foreach ($rates as $rate) {
                if ($token !== '' && (string) Arr::get($rate, 'servicelevel.token', '') === $token
                    && strtolower((string) Arr::get($rate, 'provider', '')) === $provider) {
                    return $rate;
                }
            }

            return null;
        }

        foreach ($rates as $rate) {
            if ($this->isPreferredCarrier((string) Arr::get($rate, 'provider', ''))) {
                return $rate;
            }
        }

        return $rates ? $rates[0] : null;
    }

    /**
     * Collects every parcel's transaction (Shippo buys one per parcel) and shapes
     * the dispatch result. transaction_id lists them all, master first.
     */
    protected function labelResult(ShippoClient $client, array $master, ?array $rate, int $parcelCount): array
    {
        $transactions = [$master];
        $rateObjectId = (string) Arr::get($master, 'rate', '');

        if ($parcelCount > 1 && $rateObjectId !== '') {
            $others       = $this->parcelTransactions($client, $rateObjectId, $parcelCount);
            $transactions = is_wp_error($others) ? $transactions : array_merge($transactions, $others);
        }

        $parcels = [];
        foreach ($transactions as $txn) {
            $id = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) Arr::get($txn, 'object_id', ''));
            if ($id === '' || isset($parcels[$id])) {
                continue;
            }
            $parcels[$id] = [
                'transaction_id'  => $id,
                'tracking_number' => sanitize_text_field((string) Arr::get($txn, 'tracking_number', '')),
                'tracking_url'    => esc_url_raw((string) Arr::get($txn, 'tracking_url_provider', ''), ['http', 'https']),
                'label_url'       => esc_url_raw((string) Arr::get($txn, 'label_url', ''), ['http', 'https']),
            ];
        }

        $missing = max(0, $parcelCount - count($parcels));
        if ($missing > 0) {
            // Keep what was bought: dropping it would orphan paid labels nobody can void from here.
            fluent_cart_warning_log(
                __('Shippo parcel labels not all recorded', 'shipping-for-fluent-cart'),
                sprintf(
                    /* translators: %1$d: labels recorded, %2$d: parcels shipped, %3$s: Shippo transaction ids */
                    __('Only %1$d of %2$d parcel labels were recorded (%3$s). Find and void the others in your Shippo dashboard if the shipment is deleted.', 'shipping-for-fluent-cart'),
                    count($parcels),
                    $parcelCount,
                    implode(', ', array_keys($parcels))
                ),
                ['module_name' => 'shipment', 'module_type' => self::SLUG]
            );
        }

        $transactionId = implode(',', array_keys($parcels));
        $isTest        = array_key_exists('test', $master) ? (bool) $master['test'] : $this->isSandbox();

        static::$pendingLabels[$transactionId] = [
            'test'     => $isTest,
            'parcels'  => array_values($parcels),
            'carrier'  => $rate ? $this->carrierToken((string) Arr::get($rate, 'provider', '')) : '',
            'missing'  => $missing,
            'rate'     => $rateObjectId,
            'expected' => $parcelCount,
        ];

        $first  = reset($parcels) ?: [];
        $result = [
            'tracking_number' => (string) Arr::get($first, 'tracking_number', ''),
            'tracking_url'    => (string) Arr::get($first, 'tracking_url', ''),
            'label_url'       => (string) Arr::get($first, 'label_url', ''),
            'service_name'    => $rate ? $this->serviceTitle($rate) : '',
            'transaction_id'  => $transactionId,
        ];

        if ($rate && is_numeric(Arr::get($rate, 'amount')) && Arr::get($rate, 'currency')) {
            $result['cost']     = Helper::toCent($rate['amount']);
            $result['currency'] = strtoupper((string) $rate['currency']);
        }

        return $result;
    }

    /**
     * The other parcels' transactions, across every page of the rate's list.
     * Pages by number, so a server-sent `next` URL is never fetched.
     *
     * @param bool $strict Fail on any failed page, for a caller that must not take part of
     *                     the list for all of it.
     * @return array|\WP_Error The error when a page failed before any transaction was found,
     *                        or, when strict, when any page failed.
     */
    protected function parcelTransactions(ShippoClient $client, string $rateObjectId, int $parcelCount, bool $strict = false)
    {
        $found = [];

        for ($page = 1; $page <= self::MAX_PARCEL_PAGES; $page++) {
            $list = $client->request('GET', '/transactions', [
                'rate'    => $rateObjectId,
                'results' => self::PARCEL_PAGE_SIZE,
                'page'    => $page,
            ], self::LABEL_TIMEOUT);

            if (is_wp_error($list)) {
                return $found && !$strict ? array_values($found) : $list;
            }

            foreach ((array) Arr::get($list, 'results', []) as $txn) {
                if (is_array($txn) && strtoupper((string) Arr::get($txn, 'status', '')) === 'SUCCESS'
                    && (string) Arr::get($txn, 'rate', '') === $rateObjectId) {
                    $found[(string) Arr::get($txn, 'object_id', '')] = $txn;
                }
            }

            // The master is on one of these pages too.
            if (empty($list['next']) || count($found) >= $parcelCount) {
                break;
            }
        }

        return array_values($found);
    }

    protected function uncertainPurchaseError(\WP_Error $error): \WP_Error
    {
        return new \WP_Error(
            'shippo_purchase_unconfirmed',
            sprintf(
                /* translators: %1$s: Shippo error message */
                __('Shippo did not confirm the label purchase (%1$s). Check your Shippo dashboard before trying again: the label may already have been bought.', 'shipping-for-fluent-cart'),
                $error->get_error_message()
            ),
            array_merge((array) $error->get_error_data(), ['purchase_unconfirmed' => true])
        );
    }

    /**
     * Stores the parcel labels and the label's test/live mode on the new row.
     */
    public function attachLabelDetails($payload): void
    {
        $shipment = is_array($payload) ? Arr::get($payload, 'shipment') : null;
        if (!$shipment instanceof Shipment || $shipment->carrier_slug !== self::SLUG) {
            return;
        }

        $meta          = is_array($shipment->meta) ? $shipment->meta : [];
        $transactionId = (string) Arr::get($meta, 'transaction_id', '');
        if ($transactionId === '' || !isset(static::$pendingLabels[$transactionId])) {
            return;
        }

        $pending = static::$pendingLabels[$transactionId];
        unset(static::$pendingLabels[$transactionId]);

        $meta['shippo_test'] = $pending['test'] ? 'yes' : 'no';
        if ($pending['carrier'] !== '') {
            $meta['shippo_carrier'] = $pending['carrier'];
        }
        if (count($pending['parcels']) > 1) {
            $meta['parcels'] = $pending['parcels'];
        }
        if (!empty($pending['missing'])) {
            // What a later refresh needs to find the parcels not listed yet (reconcileParcels()).
            $meta['shippo_parcels_missing']  = (int) $pending['missing'];
            $meta['shippo_rate']             = (string) $pending['rate'];
            $meta['shippo_parcels_expected'] = (int) $pending['expected'];
        }

        $shipment->meta = $meta;
        $shipment->save();
        $this->indexParcels($shipment);
    }

    /* ------------------------------------------------------------- cancel */

    public function cancelShipmentFromShipmentInstance(ShipmentInstance $instance)
    {
        $raw = (string) Arr::get($instance->data, 'transaction_id', '');
        if ($raw === '' && $instance->shipment) {
            $raw = (string) Arr::get(is_array($instance->shipment->meta) ? $instance->shipment->meta : [], 'transaction_id', '');
        }

        $ids = $this->transactionIds($raw);
        if (!$ids) {
            return null;
        }

        $client = $this->client($this->labelIsTest($instance->shipment, $raw));
        $failed = [];

        // A label set whose parcels were not all listed at purchase: find the rest before
        // voiding, from the shipment's meta, or from the purchase itself when core voids a
        // label whose shipment could not be recorded.
        $source   = $instance->shipment && is_array($instance->shipment->meta)
            ? ['missing' => Arr::get($instance->shipment->meta, 'shippo_parcels_missing', 0), 'rate' => Arr::get($instance->shipment->meta, 'shippo_rate', ''), 'expected' => Arr::get($instance->shipment->meta, 'shippo_parcels_expected', 0)]
            : (isset(static::$pendingLabels[$raw]) ? static::$pendingLabels[$raw] : []);
        $missing  = (int) Arr::get($source, 'missing', 0);
        $rate     = (string) Arr::get($source, 'rate', '');
        $expected = (int) Arr::get($source, 'expected', 0);
        if ($missing > 0 && $rate !== '' && $expected > 1) {
            // A failed listing finds nothing, so the parcels stay missing and the void says so.
            $listed = $this->parcelTransactions($client, $rate, $expected);
            foreach (is_wp_error($listed) ? [] : $listed as $txn) {
                $id = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) Arr::get($txn, 'object_id', ''));
                if ($id !== '' && !in_array($id, $ids, true)) {
                    $ids[] = $id;
                }
            }
            $missing = max(0, $expected - count($ids));
        }

        foreach ($ids as $id) {
            $refund = $client->request('POST', '/refunds', ['transaction' => $id, 'async' => false], self::LABEL_TIMEOUT);

            if (is_wp_error($refund)) {
                $failed[] = $id . ': ' . $refund->get_error_message();
                continue;
            }

            if (!in_array(strtoupper((string) Arr::get($refund, 'status', '')), ['QUEUED', 'PENDING', 'SUCCESS'], true)) {
                $detail   = ShippoClient::errorText($refund);
                $failed[] = $id . ': ' . ($detail !== '' ? $detail : __('refund not accepted', 'shipping-for-fluent-cart'));
            }
        }

        if ($missing > 0) {
            $failed[] = sprintf(
                /* translators: %1$d: labels not found, %2$s: Shippo rate id */
                _n(
                    '%1$d parcel label of this shipment was not found to void. Find the labels of rate %2$s in your Shippo dashboard and refund it there.',
                    '%1$d parcel labels of this shipment were not found to void. Find the labels of rate %2$s in your Shippo dashboard and refund them there.',
                    $missing,
                    'shipping-for-fluent-cart'
                ),
                $missing,
                $rate
            );
        }

        if ($failed) {
            return new \WP_Error('shippo_refund', implode('; ', $failed));
        }

        return true;
    }

    /**
     * @return string[] Shippo transaction ids, master first.
     */
    protected function transactionIds(string $raw): array
    {
        $ids = array_map(function ($id) {
            return preg_replace('/[^A-Za-z0-9_\-]/', '', $id);
        }, explode(',', $raw));

        return array_values(array_unique(array_filter($ids)));
    }

    /**
     * The mode the label was bought in, so a mode switch never sends a test
     * label's refund or tracking call with the live token, or vice versa.
     */
    protected function labelIsTest(?Shipment $shipment, string $transactionId = ''): bool
    {
        $meta = ($shipment && is_array($shipment->meta)) ? $shipment->meta : [];
        $flag = Arr::get($meta, 'shippo_test');

        if ($flag === 'yes' || $flag === 'no') {
            return $flag === 'yes';
        }

        if ($transactionId !== '' && isset(static::$pendingLabels[$transactionId])) {
            return (bool) static::$pendingLabels[$transactionId]['test'];
        }

        return $this->isSandbox();
    }

    /* ------------------------------------------------------------- labels */

    public function hasLabel(Shipment $shipment): bool
    {
        $meta = is_array($shipment->meta) ? $shipment->meta : [];

        return (bool) $this->transactionIds((string) Arr::get($meta, 'transaction_id', ''));
    }

    /**
     * Shippo signs label links for a few days, so each print asks for a fresh one.
     * A multi-parcel label prints the master's, as at purchase.
     */
    public function getLabelDownloadUrl(Shipment $shipment)
    {
        $meta = is_array($shipment->meta) ? $shipment->meta : [];
        $ids  = $this->transactionIds((string) Arr::get($meta, 'transaction_id', ''));
        if (!$ids) {
            return '';
        }

        $txn = $this->client($this->labelIsTest($shipment, $ids[0]))->request('GET', '/transactions/' . $ids[0], [], self::WEBHOOK_TIMEOUT);
        if (is_wp_error($txn)) {
            return $txn;
        }

        return esc_url_raw((string) Arr::get($txn, 'label_url', ''), ['https']);
    }

    /* ----------------------------------------------------------- tracking */

    public function supportsTrackingSync(): bool
    {
        return $this->isEnabled();
    }

    public function syncTrackingFromShipmentInstance(ShipmentInstance $instance)
    {
        if (!$instance->shipment) {
            return null;
        }

        return $this->pullTracking($instance->shipment);
    }

    public function canTrackWithoutLabel(Shipment $shipment): bool
    {
        return $this->trackableNumber($shipment) !== '' && $this->trackCarrier($shipment) !== '';
    }

    /**
     * Reads the shipment's tracking from Shippo and applies it: the carrier's
     * track first, as a label's own tracking_status can lag it, then the label.
     *
     * @param string     $carrierHint The webhook's carrier, used only when none is stored.
     * @param array|null $tracks      Tracks already read in this webhook, keyed by mode, carrier and number.
     * @return bool|\WP_Error
     */
    protected function pullTracking(Shipment $shipment, string $carrierHint = '', ?array &$tracks = null)
    {
        $meta    = is_array($shipment->meta) ? $shipment->meta : [];
        $ids     = $this->transactionIds((string) Arr::get($meta, 'transaction_id', ''));
        $isTest  = $this->labelIsTest($shipment);
        $client  = $this->client($isTest);
        $number  = $this->trackableNumber($shipment);
        $carrier = $number !== '' ? $this->trackCarrier($shipment, $carrierHint) : '';

        $missing = (int) Arr::get($meta, 'shippo_parcels_missing', 0);
        if ($missing > 0) {
            $reconciled = $this->reconcileParcels($shipment, $meta, $client);
            if (is_wp_error($reconciled)) {
                return $reconciled;
            }
            list($meta, $missing) = $reconciled;
            $ids = $this->transactionIds((string) Arr::get($meta, 'transaction_id', ''));
        }

        $parcels = $this->parcelsOf($meta);
        if (!$parcels && $missing > 0) {
            $parcels = [['transaction_id' => $ids ? $ids[0] : '', 'tracking_number' => $number]];
        }
        if (count($parcels) > 1 || $missing > 0) {
            return $this->pullParcelTracking($shipment, $parcels, $client, $isTest, $carrier, $tracks, $missing);
        }

        if ($carrier !== '') {
            $key = ($isTest ? 'test' : 'live') . ':' . $carrier . '/' . $number;
            if ($tracks !== null && array_key_exists($key, $tracks)) {
                $track = $tracks[$key];
            } else {
                $track = $client->request('GET', '/tracks/' . $carrier . '/' . $number, [], self::WEBHOOK_TIMEOUT);
                if ($tracks !== null) {
                    $tracks[$key] = $track;
                }
            }

            // Unknown outcome: report it so the webhook answers 502 and Shippo retries.
            if (is_wp_error($track) && !ShippoClient::isDefiniteRejection($track)) {
                return $track;
            }

            $applied = is_wp_error($track) ? null : $this->applyTrack($shipment, $track);
            if ($applied !== null) {
                return $applied;
            }

            if (!$ids) {
                return is_wp_error($track)
                    ? new \WP_Error('shippo_untracked', $track->get_error_message())
                    : false;
            }
        }

        if (!$ids) {
            return new \WP_Error('shippo_no_transaction', __('This shipment has no Shippo label to refresh tracking from.', 'shipping-for-fluent-cart'));
        }

        $txn = $client->request('GET', '/transactions/' . $ids[0], [], self::WEBHOOK_TIMEOUT);
        if (is_wp_error($txn)) {
            return $txn;
        }

        $status   = strtoupper(sanitize_text_field((string) Arr::get($txn, 'tracking_status', '')));
        $internal = $this->mapTrackingStatus($status);
        if (!$internal) {
            return false;
        }

        $result = ShipmentService::applyTrackingUpdate($shipment, $internal, ['tracking_status' => $status]);

        return is_wp_error($result) ? $result : (bool) $result;
    }

    /**
     * A multi-parcel label set: every parcel's track is read (its label's
     * transaction when the track has no status), and the shipment gets the
     * combined status, so one parcel delivered first cannot close the shipment.
     *
     * @return bool|\WP_Error
     */
    protected function pullParcelTracking(Shipment $shipment, array $parcels, ShippoClient $client, bool $isTest, string $carrier, ?array &$tracks = null, int $missing = 0)
    {
        $states = [];
        foreach ($parcels as $parcel) {
            $state = null;

            if ($carrier !== '' && $parcel['tracking_number'] !== '') {
                $key = ($isTest ? 'test' : 'live') . ':' . $carrier . '/' . $parcel['tracking_number'];
                if ($tracks !== null && array_key_exists($key, $tracks)) {
                    $track = $tracks[$key];
                } else {
                    $track = $client->request('GET', '/tracks/' . $carrier . '/' . $parcel['tracking_number'], [], self::WEBHOOK_TIMEOUT);
                    if ($tracks !== null) {
                        $tracks[$key] = $track;
                    }
                }

                if (is_wp_error($track) && !ShippoClient::isDefiniteRejection($track)) {
                    return $track;
                }
                $trackState = is_wp_error($track) ? null : Arr::get($track, 'tracking_status');
                if (is_array($trackState) && $this->mapTrackingStatus(strtoupper((string) Arr::get($trackState, 'status', '')))) {
                    $state = $trackState;
                }
            }

            if (!$state && $parcel['transaction_id'] !== '') {
                $txn = $client->request('GET', '/transactions/' . $parcel['transaction_id'], [], self::WEBHOOK_TIMEOUT);
                if (is_wp_error($txn)) {
                    return $txn;
                }
                $state = ['status' => (string) Arr::get($txn, 'tracking_status', '')];
            }

            $states[] = $state ?: ['status' => ''];
        }

        // A parcel bought but not listed yet has no status, so the set is never complete.
        for ($i = 0; $i < $missing; $i++) {
            $states[] = ['status' => ''];
        }

        $combined = $this->combineParcelStates($states);
        if (!$combined) {
            return false;
        }

        // Core applies a dated event only when it is newer than the stored one, and the
        // combined date is the newest parcel's. A parcel that reports late, with an older
        // date, still changes the combined status, so that change is dated just after.
        $stored     = is_array($shipment->meta) ? $shipment->meta : [];
        $storedDate = (string) Arr::get($stored, 'tracking_status_date', '');
        if ($storedDate !== '' && strtotime($storedDate)
            && $combined['status'] !== (string) Arr::get($stored, 'tracking_status', '')
            && (empty($combined['status_date']) || strtotime($combined['status_date']) <= strtotime($storedDate))) {
            $combined['status_date'] = gmdate('Y-m-d\TH:i:s\Z', strtotime($storedDate) + 1);
        }

        $applied = $this->applyTrack($shipment, ['tracking_status' => $combined]);

        return $applied === null ? false : $applied;
    }

    /**
     * Delivered or returned, both final, only once every parcel is final;
     * otherwise failed when a parcel failed, in transit once any parcel moved,
     * else pre-transit. Null when no parcel has a status yet.
     */
    protected function combineParcelStates(array $states): ?array
    {
        $codes = array_map(function ($state) {
            return strtoupper(sanitize_text_field((string) Arr::get($state, 'status', '')));
        }, $states);
        $count     = count($codes);
        $delivered = count(array_keys($codes, 'DELIVERED', true));
        $returned  = count(array_keys($codes, 'RETURNED', true));

        if ($delivered === $count) {
            $status = 'DELIVERED';
        } elseif ($delivered + $returned === $count) {
            $status = 'RETURNED';
        } elseif (in_array('FAILURE', $codes, true)) {
            $status = 'FAILURE';
        } elseif (array_intersect(['TRANSIT', 'DELIVERED', 'RETURNED'], $codes)) {
            $status = 'TRANSIT';
        } elseif (in_array('PRE_TRANSIT', $codes, true)) {
            $status = 'PRE_TRANSIT';
        } else {
            return null;
        }

        $details = '';
        if ($delivered > 0 && $delivered < $count) {
            /* translators: %1$d: parcels delivered, %2$d: parcels in the shipment */
            $details = sprintf(__('%1$d of %2$d parcels delivered.', 'shipping-for-fluent-cart'), $delivered, $count);
        } else {
            foreach ($states as $index => $state) {
                if ($codes[$index] === $status && Arr::get($state, 'status_details')) {
                    $details = (string) Arr::get($state, 'status_details');
                    break;
                }
            }
        }

        $date = '';
        foreach ($states as $state) {
            $candidate = (string) Arr::get($state, 'status_date', '');
            if ($candidate !== '' && strtotime($candidate) && (!$date || strtotime($candidate) > strtotime($date))) {
                $date = $candidate;
            }
        }

        return array_filter(['status' => $status, 'status_details' => $details, 'status_date' => $date]);
    }

    /**
     * Lists the purchase's transactions again for a label set whose parcels were not all
     * found at purchase. Parcels found are stored, so they are tracked and voided too.
     * A listing that fails is returned as the error, so a webhook answers 502 and Shippo
     * retries instead of the parcels staying unknown.
     *
     * @return array|\WP_Error [array $meta, int $missing]
     */
    protected function reconcileParcels(Shipment $shipment, array $meta, ShippoClient $client)
    {
        $missing  = (int) Arr::get($meta, 'shippo_parcels_missing', 0);
        $rate     = (string) Arr::get($meta, 'shippo_rate', '');
        $expected = (int) Arr::get($meta, 'shippo_parcels_expected', 0);
        if ($rate === '' || $expected < 2) {
            return [$meta, $missing];
        }

        $ids   = $this->transactionIds((string) Arr::get($meta, 'transaction_id', ''));
        $known = Arr::get($meta, 'parcels');
        if (!is_array($known) || !$known) {
            $known = [['transaction_id' => $ids ? $ids[0] : '', 'tracking_number' => (string) $shipment->tracking_number]];
        }

        $byId = [];
        foreach ($known as $parcel) {
            if (is_array($parcel) && (string) Arr::get($parcel, 'transaction_id', '') !== '') {
                $byId[(string) $parcel['transaction_id']] = $parcel;
            }
        }
        $before = count($byId);

        $listed = $this->parcelTransactions($client, $rate, $expected, true);
        if (is_wp_error($listed)) {
            return $listed;
        }

        foreach ($listed as $txn) {
            $id = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) Arr::get($txn, 'object_id', ''));
            if ($id === '' || isset($byId[$id])) {
                continue;
            }
            $byId[$id] = [
                'transaction_id'  => $id,
                'tracking_number' => sanitize_text_field((string) Arr::get($txn, 'tracking_number', '')),
                'tracking_url'    => esc_url_raw((string) Arr::get($txn, 'tracking_url_provider', ''), ['http', 'https']),
                'label_url'       => esc_url_raw((string) Arr::get($txn, 'label_url', ''), ['http', 'https']),
            ];
        }

        if (count($byId) === $before) {
            return [$meta, $missing];
        }

        $missing                = max(0, $expected - count($byId));
        $meta['parcels']        = array_values($byId);
        $meta['transaction_id'] = implode(',', array_keys($byId));
        if ($missing > 0) {
            $meta['shippo_parcels_missing'] = $missing;
        } else {
            unset($meta['shippo_parcels_missing']);
        }

        $shipment->meta = $meta;
        $shipment->save();
        $this->indexParcels($shipment);

        return [$meta, $missing];
    }

    /**
     * The parcels of a multi-parcel label set, from meta.parcels.
     */
    protected function parcelsOf(array $meta): array
    {
        $parcels = [];
        foreach ((array) Arr::get($meta, 'parcels', []) as $parcel) {
            if (!is_array($parcel)) {
                continue;
            }
            $number = (string) Arr::get($parcel, 'tracking_number', '');
            $parcels[] = [
                'transaction_id'  => preg_replace('/[^A-Za-z0-9_\-]/', '', (string) Arr::get($parcel, 'transaction_id', '')),
                'tracking_number' => preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $number) ? $number : '',
            ];
        }

        return $parcels;
    }

    /**
     * Applies a Track object from GET /tracks. Null when it has no usable status.
     *
     * @return bool|\WP_Error|null
     */
    protected function applyTrack(Shipment $shipment, array $track)
    {
        $state    = Arr::get($track, 'tracking_status');
        $status   = is_array($state) ? strtoupper(sanitize_text_field((string) Arr::get($state, 'status', ''))) : '';
        $internal = $this->mapTrackingStatus($status);
        if (!$internal) {
            return null;
        }

        $meta    = ['tracking_status' => $status];
        $details = sanitize_text_field((string) Arr::get($state, 'status_details', ''));
        if ($details !== '') {
            $meta['tracking_status_details'] = function_exists('mb_substr') ? mb_substr($details, 0, 255) : substr($details, 0, 255);
        }
        $date = sanitize_text_field((string) Arr::get($state, 'status_date', ''));
        if ($date !== '' && strtotime($date)) {
            $meta['tracking_status_date'] = $date;
        }

        // Always set, so an update without them clears an old expected date or substatus.
        $eta = sanitize_text_field((string) Arr::get($track, 'eta', ''));
        $meta['tracking_eta'] = ($eta !== '' && strtotime($eta)) ? $eta : '';
        $meta['tracking_substatus'] = is_array($state) ? sanitize_key((string) Arr::get($state, 'substatus.code', '')) : '';

        $result = ShipmentService::applyTrackingUpdate($shipment, $internal, $meta);

        return is_wp_error($result) ? $result : (bool) $result;
    }

    /**
     * The tracking number when it is safe as one /tracks path segment, else ''.
     */
    protected function trackableNumber(Shipment $shipment): string
    {
        $number = (string) $shipment->tracking_number;

        return preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $number) ? $number : '';
    }

    /**
     * Shippo's carrier token for GET /tracks, '' when unknown. Test mode tracks
     * only carrier `shippo`. The hint only picks which lookup to make with our token.
     */
    protected function trackCarrier(Shipment $shipment, string $hint = ''): string
    {
        if ($this->labelIsTest($shipment)) {
            return self::SLUG;
        }

        $meta   = is_array($shipment->meta) ? $shipment->meta : [];
        $stored = $this->carrierToken((string) Arr::get($meta, 'shippo_carrier', ''));

        return $stored !== '' ? $stored : $this->carrierToken($hint);
    }

    /**
     * A rate's provider ("DHL Express") or a token as Shippo's carrier token (dhl_express).
     */
    protected function carrierToken(string $value): string
    {
        $token = trim((string) preg_replace('/[^a-z0-9]+/', '_', strtolower($value)), '_');

        return strlen($token) <= 40 ? $token : '';
    }

    /**
     * Ignores underscores: older saves stored "DHL Express" as dhlexpress.
     */
    protected function isPreferredCarrier(string $provider): bool
    {
        $preferred = str_replace('_', '', $this->carrierToken((string) $this->settings->get('default_carrier')));

        return $preferred !== '' && str_replace('_', '', $this->carrierToken($provider)) === $preferred;
    }

    /**
     * Shippo tracking status → shipment status; '' for UNKNOWN or anything new.
     */
    protected function mapTrackingStatus(string $status): string
    {
        $map = [
            'PRE_TRANSIT' => Shipment::STATUS_DISPATCHED,
            'TRANSIT'     => Shipment::STATUS_IN_TRANSIT,
            'DELIVERED'   => Shipment::STATUS_DELIVERED,
            'RETURNED'    => Shipment::STATUS_RETURNED,
            'FAILURE'     => Shipment::STATUS_FAILED,
        ];

        return isset($map[$status]) ? $map[$status] : '';
    }

    public function getTrackingUrl(string $trackingNumber): string
    {
        return 'https://track.goshippo.com/' . rawurlencode($trackingNumber);
    }

    /* ------------------------------------------------------------ webhook */

    public function getWebhookUrl(): string
    {
        $secret = (string) $this->settings->get('webhook_secret');
        if ($secret === '') {
            return '';
        }

        return add_query_arg([
            'fluent-cart' => 'fct_shipping_listener_webhook',
            'carrier'     => self::SLUG,
            'fcs_token'   => $secret,
        ], home_url('/'));
    }

    public function handleWebhook(): void
    {
        $token   = (string) App::request()->getSafe('fcs_token', 'sanitize_text_field');
        $raw     = (string) file_get_contents('php://input');
        $payload = $raw !== '' ? json_decode($raw, true) : null;

        list($status, $body) = $this->processWebhook($token, is_array($payload) ? $payload : []);

        wp_send_json($body, $status);
    }

    /**
     * Authenticates a Shippo track_updated event and re-reads the tracking from
     * Shippo rather than trusting the body: the body only names the tracking number.
     * Every Shippo shipment in the event's mode with that number gets it (one parcel
     * can cover several orders), from one Shippo read.
     *
     * @return array [int $httpStatus, array $body] See WebhookOutcomes.
     */
    public function processWebhook(string $token, array $payload): array
    {
        $secret = (string) $this->settings->get('webhook_secret');
        if ($secret === '' || !hash_equals($secret, $token)) {
            return $this->webhookRejected(401, 'invalid_token', __('Invalid webhook token.', 'shipping-for-fluent-cart'));
        }

        $data = Arr::get($payload, 'data');
        if (Arr::get($payload, 'event') !== 'track_updated' || !is_array($data)) {
            return $this->webhookIgnored('event');
        }

        // Shippo has no delivery log to read, so the settings page shows when one last arrived.
        $this->settings->save(['last_event_at' => DateTime::gmtNow()->format('Y-m-d H:i:s')]);

        $trackingNumber = sanitize_text_field((string) Arr::get($data, 'tracking_number', ''));
        $shipments      = $trackingNumber !== '' ? $this->shipmentsTracking($trackingNumber) : [];

        if (!$shipments) {
            return $this->webhookIgnored('unknown_shipment', null, $this->webhookEventDetails($payload, $trackingNumber));
        }

        // Shippo flags test events at the top level of the payload.
        $eventIsTest = filter_var(Arr::get($payload, 'test', false), FILTER_VALIDATE_BOOLEAN);
        $matching    = array_values(array_filter($shipments, function ($shipment) use ($eventIsTest) {
            return $eventIsTest === $this->labelIsTest($shipment);
        }));

        if (!$matching) {
            return $this->webhookIgnored('mode_mismatch', $shipments[0]);
        }

        $hint      = (string) Arr::get($data, 'carrier', '');
        $tracks    = [];
        $failed    = null;
        $changed   = null;
        $unchanged = null;
        $ignored   = null;

        foreach ($matching as $shipment) {
            $applied = $this->pullTracking($shipment, $hint, $tracks);

            if (is_wp_error($applied)) {
                $code = $applied->get_error_code();
                if ($code === 'shippo_no_transaction' || $code === 'shippo_untracked') {
                    $ignored = $ignored ?: [$code === 'shippo_untracked' ? 'untracked' : 'no_label', $shipment];
                } else {
                    $failed = $failed ?: $shipment;
                }
            } elseif ($applied) {
                $changed = $changed ?: $shipment;
            } else {
                $unchanged = $unchanged ?: $shipment;
            }
        }

        // A failed read wins so Shippo retries; the retry is a no-op for shipments already updated.
        if ($failed) {
            return $this->webhookFailed(502, 'refetch_failed', __('Could not read the label from Shippo.', 'shipping-for-fluent-cart'), $failed);
        }
        if ($changed || $unchanged) {
            return $this->webhookApplied($changed ?: $unchanged, (bool) $changed);
        }

        return $this->webhookIgnored($ignored[0], $ignored[1]);
    }

    /**
     * Every Shippo shipment with this tracking number, newest first, capped.
     *
     * @return Shipment[]
     */
    protected function shipmentsTracking(string $trackingNumber): array
    {
        // A child parcel's number is not on the shipment row; the parcel index maps it to its shipment.
        $parcelOf = $this->shipmentIdsOfParcel($trackingNumber);

        $shipments = Shipment::query()
            ->where('carrier_slug', self::SLUG)
            ->where(function ($query) use ($trackingNumber, $parcelOf) {
                $query->where('tracking_number', $trackingNumber);
                if ($parcelOf) {
                    $query->orWhereIn('id', $parcelOf);
                }
            })
            ->orderBy('id', 'DESC')
            ->limit(self::WEBHOOK_MAX_SHIPMENTS + 1)
            ->get()
            ->all();

        if (count($shipments) > self::WEBHOOK_MAX_SHIPMENTS) {
            array_pop($shipments);
            if (function_exists('fluent_cart_error_log')) {
                fluent_cart_error_log(
                    'Shippo webhook capped',
                    sprintf('Tracking number %s matches more than %d shipments; only the newest %d were updated.', substr($trackingNumber, 0, 64), self::WEBHOOK_MAX_SHIPMENTS, self::WEBHOOK_MAX_SHIPMENTS),
                    ['log_type' => 'api', 'module_name' => 'shipment', 'module_type' => 'shippo']
                );
            }
        }

        return $shipments;
    }

    /**
     * The shipments whose meta.parcels lists this tracking number, newest first.
     *
     * @return int[]
     */
    protected function shipmentIdsOfParcel(string $trackingNumber): array
    {
        global $wpdb;

        if (!preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $trackingNumber)) {
            return [];
        }

        return array_map('intval', $wpdb->get_col($wpdb->prepare(
            "SELECT `object_id` FROM `{$wpdb->prefix}fct_meta` WHERE `object_type` = %s AND `meta_key` = %s ORDER BY `object_id` DESC LIMIT %d",
            self::PARCEL_INDEX,
            $trackingNumber,
            self::WEBHOOK_MAX_SHIPMENTS + 1
        )));
    }

    /**
     * Adds the shipment's parcel tracking numbers to the parcel index, so a parcel's
     * own webhook finds the shipment. Call it whenever meta.parcels is saved.
     */
    protected function indexParcels(Shipment $shipment): void
    {
        global $wpdb;

        $meta    = is_array($shipment->meta) ? $shipment->meta : [];
        $numbers = array_unique(array_filter(array_map(function ($parcel) {
            return is_array($parcel) ? (string) Arr::get($parcel, 'tracking_number', '') : '';
        }, (array) Arr::get($meta, 'parcels', [])), function ($number) {
            return (bool) preg_match('/^[A-Za-z0-9_\-]{1,64}$/', $number);
        }));

        foreach ($numbers as $number) {
            $known = $wpdb->get_var($wpdb->prepare(
                "SELECT `id` FROM `{$wpdb->prefix}fct_meta` WHERE `object_type` = %s AND `meta_key` = %s AND `object_id` = %d LIMIT 1",
                self::PARCEL_INDEX,
                $number,
                (int) $shipment->id
            ));
            if (!$known) {
                $wpdb->insert($wpdb->prefix . 'fct_meta', [
                    'object_type' => self::PARCEL_INDEX,
                    'object_id'   => (int) $shipment->id,
                    'meta_key'    => $number,
                    'meta_value'  => '',
                    'created_at'  => current_time('mysql', true),
                    'updated_at'  => current_time('mysql', true),
                ]);
            }
        }
    }

    /**
     * What the event says about itself, so an ignored one can be traced in Shippo.
     */
    protected function webhookEventDetails(array $payload, string $trackingNumber): array
    {
        $details = [];
        if ($trackingNumber !== '') {
            $details['tracking_number'] = substr($trackingNumber, 0, 64);
        }

        $carrier = $this->carrierToken(sanitize_text_field((string) Arr::get($payload, 'data.carrier', '')));
        if ($carrier !== '') {
            $details['carrier'] = $carrier;
        }

        if (array_key_exists('test', $payload)) {
            $details['mode'] = filter_var($payload['test'], FILTER_VALIDATE_BOOLEAN) ? 'test' : 'live';
        }

        return $details;
    }

    /* ----------------------------------------------------------- settings */

    /**
     * @return array|\WP_Error
     */
    public function validateSettings(array $settings)
    {
        if (array_key_exists('unit_of_measurement', $settings)) {
            $settings['unit_of_measurement'] = in_array($settings['unit_of_measurement'], ['metric', 'imperial'], true) ? $settings['unit_of_measurement'] : '';
        }

        if (array_key_exists('seller_phone', $settings)) {
            $settings['seller_phone'] = trim((string) $settings['seller_phone']);
            if (!static::isValidPhone($settings['seller_phone'])) {
                return new \WP_Error('shippo_seller_phone', static::sellerPhoneMessage());
            }
        }

        if (array_key_exists('seller_email', $settings)) {
            $email = trim((string) $settings['seller_email']);
            if ($email !== '' && !is_email($email)) {
                return new \WP_Error('shippo_seller_email', __('The Seller Email in Shippo settings must be a valid email address.', 'shipping-for-fluent-cart'));
            }
            $settings['seller_email'] = sanitize_email($email);
        }

        $sandbox  = Arr::get($settings, 'sandbox_mode', $this->settings->get('sandbox_mode')) === 'yes';
        $tokenKey = $sandbox ? 'test_token' : 'live_token';

        foreach (['test_token' => true, 'live_token' => false] as $key => $isTest) {
            if (!isset($settings[$key]) || trim((string) $settings[$key]) === '') {
                continue;
            }

            $token = trim((string) $settings[$key]);
            if ($isTest ? ShippoClient::isLiveToken($token) : ShippoClient::isTestToken($token)) {
                return new \WP_Error(
                    'shippo_token_mode',
                    $isTest
                        ? __('That is a live token. Paste it into Live Token.', 'shipping-for-fluent-cart')
                        : __('That is a test token. Paste it into Test Token.', 'shipping-for-fluent-cart')
                );
            }

            // Proves the token authenticates; the active one is proven by the carrier fetch below.
            $check = $key === $tokenKey ? [] : (new ShippoClient($token))->request('GET', '/carrier_accounts', ['results' => 1], self::SETTINGS_TIMEOUT);
            if (is_wp_error($check)) {
                return $check;
            }

            $settings[$key] = $token;
        }

        $token = isset($settings[$tokenKey]) ? (string) $settings[$tokenKey] : (string) $this->settings->get($tokenKey);

        if (Arr::get($settings, 'is_active', $this->settings->get('is_active')) === 'yes' && trim($token) === '') {
            return new \WP_Error(
                'shippo_token_required',
                $sandbox
                    ? __('Enter your Shippo test token to enable Shippo in Test mode.', 'shipping-for-fluent-cart')
                    : __('Enter your Shippo live token to enable Shippo.', 'shipping-for-fluent-cart')
            );
        }

        $newAccount = trim($token) !== $this->tokenFor($this->isSandbox());
        $carriers   = trim($token) === '' ? [] : $this->fetchCarriers(trim($token));
        if (is_wp_error($carriers)) {
            // A new token is never stored unverified; with the same token an outage must not block saving.
            if ($newAccount) {
                return $carriers;
            }
            $carriers = (array) $this->settings->get('connected_carriers');
        } else {
            $settings = $this->carrierSync($carriers) + $settings;
            $carriers = $settings['connected_carriers'];
        }

        $storedPick = (string) $this->settings->get('default_carrier');
        $pick       = (string) Arr::get($settings, 'default_carrier', $storedPick);
        if ($pick !== '' && !in_array($pick, array_column($carriers, 'carrier'), true)) {
            // The form resends the old account's pick after a token or mode change.
            if (!$newAccount || $pick !== $storedPick) {
                return new \WP_Error('shippo_unknown_carrier', __('The Preferred Carrier is not connected to this Shippo account.', 'shipping-for-fluent-cart'));
            }
            $settings['default_carrier'] = '';
        }

        if (Arr::get($settings, 'rotate_webhook_secret') === 'yes' || (string) $this->settings->get('webhook_secret') === '') {
            $settings['webhook_secret'] = wp_generate_password(40, false);
        }
        $settings['rotate_webhook_secret'] = 'no';

        return $settings;
    }

    /**
     * @return array|\WP_Error Active carriers of the account, one per carrier token.
     */
    protected function fetchCarriers(string $token)
    {
        $client   = new ShippoClient($token);
        $carriers = [];
        $page     = 1;

        do {
            $response = $client->request('GET', '/carrier_accounts', ['results' => 100, 'page' => $page, 'service_levels' => 'true'], self::SETTINGS_TIMEOUT);
            if (is_wp_error($response)) {
                return $response;
            }

            foreach ((array) Arr::get($response, 'results', []) as $account) {
                $carrier = is_array($account) && !empty($account['active']) ? $this->carrierToken((string) Arr::get($account, 'carrier', '')) : '';
                // The store's own account and Shippo's for one carrier are listed apart.
                $own = is_array($account) && Arr::get($account, 'is_shippo_account') === false;
                $key = ($own ? 'own:' : '') . $carrier;
                if ($carrier !== '' && !isset($carriers[$key])) {
                    $name = sanitize_text_field((string) Arr::get($account, 'carrier_name', ''));
                    $carriers[$key] = array_filter([
                        'carrier'        => $carrier,
                        'name'           => $name !== '' ? $name : $carrier,
                        'own'            => $own,
                        'account_ending' => $own ? strtoupper(substr(sanitize_text_field((string) Arr::get($account, 'account_id', '')), -4)) : '',
                        'services'       => count((array) Arr::get($account, 'service_levels', [])),
                        'owner'          => sanitize_email((string) Arr::get($account, 'object_owner', '')),
                    ]);
                }
            }

            $page++;
        } while (!empty($response['next']) && $page <= self::MAX_CARRIER_PAGES);

        return array_values($carriers);
    }

    /**
     * Built from the stored list only — fields() runs on every settings read.
     */
    protected function carrierOptions(): array
    {
        $options = [['value' => '', 'label' => __('Cheapest of all carriers', 'shipping-for-fluent-cart')]];
        foreach ((array) $this->settings->get('connected_carriers') as $carrier) {
            $options[] = ['value' => (string) $carrier['carrier'], 'label' => (string) $carrier['name']];
        }

        $pick = (string) $this->settings->get('default_carrier');
        if ($pick !== '' && !in_array($pick, array_column($options, 'value'), true)) {
            /* translators: %s: Shippo carrier token, such as usps */
            $options[] = ['value' => $pick, 'label' => sprintf(__('%s (not connected)', 'shipping-for-fluent-cart'), $pick)];
        }

        return $options;
    }

    /* ------------------------------------------------------------ helpers */

    protected function storeName(): string
    {
        return (string) (new StoreSettings())->get('store_name') ?: (string) get_bloginfo('name');
    }

    protected function addressFrom(): array
    {
        $origin = $this->buildOrigin();

        return [
            'name'    => $this->storeName(),
            'company' => (string) (new StoreSettings())->get('company_name') ?: $this->storeName(),
            'street1' => $origin['address1'],
            'street2' => $origin['address2'],
            'city'    => $origin['city'],
            'state'   => $origin['state'],
            'zip'     => $origin['postcode'],
            'country' => strtoupper($origin['country']),
            'phone'   => (string) $this->settings->get('seller_phone'),
            'email'   => (string) $this->settings->get('seller_email'),
        ];
    }

    /**
     * @return array|\WP_Error
     */
    protected function orderAddressTo(Order $order)
    {
        $address = $order->shipping_address ?: $order->billing_address;
        if (!$address) {
            return new \WP_Error('shippo_no_address', __('No shipping address found for this order.', 'shipping-for-fluent-cart'));
        }

        $origin  = $this->buildOrigin();
        $missing = [];
        foreach ([
            'address1' => __('store street address', 'shipping-for-fluent-cart'),
            'postcode' => __('store postal code', 'shipping-for-fluent-cart'),
            'country'  => __('store country', 'shipping-for-fluent-cart'),
        ] as $key => $label) {
            if (!$origin[$key]) {
                $missing[] = $label;
            }
        }
        foreach ([
            'address_1' => __('customer street address', 'shipping-for-fluent-cart'),
            'postcode'  => __('customer postal code', 'shipping-for-fluent-cart'),
            'country'   => __('customer country', 'shipping-for-fluent-cart'),
        ] as $key => $label) {
            if (!$address->{$key}) {
                $missing[] = $label;
            }
        }

        if ($missing) {
            return new \WP_Error('shippo_incomplete_address', sprintf(
                /* translators: %1$s: comma-separated list of missing address fields */
                __('A Shippo label needs a complete address. Missing: %1$s.', 'shipping-for-fluent-cart'),
                implode(', ', $missing)
            ));
        }

        return [
            'name'    => (string) $address->name,
            'company' => (string) $address->company_name,
            'street1' => (string) $address->address_1,
            'street2' => (string) $address->address_2,
            'city'    => (string) $address->city,
            'state'   => (string) $address->state,
            'zip'     => (string) $address->postcode,
            'country' => strtoupper((string) $address->country),
            'phone'   => (string) $address->phone,
            'email'   => (string) $address->email,
        ];
    }

    /**
     * Shippo's rule for address phones: empty, or 8 to 15 digits.
     * The value is printed on labels, so only phone punctuation is allowed.
     */
    protected static function isValidPhone(string $phone): bool
    {
        if (trim($phone) === '') {
            return true;
        }

        if (!preg_match('/^[0-9 +().\-]{8,32}$/', $phone)) {
            return false;
        }

        $digits = strlen((string) preg_replace('/\D/', '', $phone));

        return $digits >= 8 && $digits <= 15;
    }

    protected static function sellerPhoneMessage(): string
    {
        return __('The Seller Phone in Shippo settings must contain 8 to 15 digits.', 'shipping-for-fluent-cart');
    }

    /**
     * Turns a definite label refusal into a message that says what failed and
     * what to fix, and logs Shippo's own words. Token, network, rate-limit and
     * server errors already carry their own wording and pass through.
     */
    protected function friendlyLabelError(\WP_Error $error, ?array $rate = null, int $orderId = 0): \WP_Error
    {
        $code      = $error->get_error_code();
        $byCarrier = $code === 'shippo_label';
        if (!$byCarrier && !($code === 'shippo_api' && ShippoClient::isDefiniteRejection($error))) {
            return $error;
        }

        // Rendered as HTML by some admin notifiers.
        $detail = trim(str_replace(['<', '>'], '', wp_strip_all_tags($error->get_error_message())));
        $this->logLabelRefusal($detail, $rate, $orderId);

        $message = $this->addressFieldMessage($detail);
        if ($message !== '') {
            return new \WP_Error($code, $message, $error->get_error_data());
        }

        if (preg_match('/\b(log ?in|username|password|credentials?|authenticat\w*|unauthori[sz]ed)\b/i', $detail)) {
            $message = sprintf(
                /* translators: %1$s: carrier name e.g. DPD DE, %2$s: the carrier's error message */
                __('Shippo couldn\'t buy this label because the %1$s account connected in your Shippo dashboard couldn\'t log in. Nothing was charged. Check that carrier\'s login details under Carriers in your Shippo dashboard, or pick a different service. Shippo said: “%2$s”', 'shipping-for-fluent-cart'),
                $this->rateCarrier($rate, __('carrier', 'shipping-for-fluent-cart')),
                $detail
            );
        } elseif ($this->isStaleRateError($detail)) {
            $message = __('Shippo couldn\'t buy this label because the rate expired. Click Refresh Rates, pick the service again and retry.', 'shipping-for-fluent-cart');
        } elseif ($byCarrier) {
            $message = sprintf(
                /* translators: %1$s: carrier name e.g. DPD DE, %2$s: the carrier's error message */
                __('Shippo couldn\'t buy this label because %1$s refused it: “%2$s”. No label was bought and nothing was charged. Fix the issue and try again, or pick a different service.', 'shipping-for-fluent-cart'),
                $this->rateCarrier($rate, __('the carrier', 'shipping-for-fluent-cart')),
                $detail
            );
        } elseif (preg_match('/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*: /', $detail)) {
            // Shippo's field errors already name the field ("parcels.0.weight: ...").
            return $error;
        } else {
            $message = sprintf(
                /* translators: %s: Shippo's error message */
                __('Shippo couldn\'t buy this label: “%s”. No label was bought and nothing was charged. Fix the issue and try again, or pick a different service.', 'shipping-for-fluent-cart'),
                $detail
            );
        }

        return new \WP_Error($code, $message, $error->get_error_data());
    }

    /**
     * Shippo's address_from.* / address_to.* field errors as the setting or
     * order field to fix; empty for anything else.
     */
    protected function addressFieldMessage(string $detail): string
    {
        if (!preg_match('/address_(from|to)\.([a-z0-9_]+)/i', $detail, $match)) {
            return '';
        }

        $field = strtolower($match[2]);
        if (strtolower($match[1]) === 'from') {
            if ($field === 'phone') {
                return static::sellerPhoneMessage();
            }
            if ($field === 'email') {
                return __('Shippo rejected the Seller Email in Shippo settings. Enter a valid email address.', 'shipping-for-fluent-cart');
            }

            return __('Shippo rejected the store address. Check the address in Store Settings.', 'shipping-for-fluent-cart');
        }

        if ($field === 'phone') {
            return __('Shippo rejected the customer\'s shipping phone. Edit the order\'s shipping address so the phone has 8 to 15 digits.', 'shipping-for-fluent-cart');
        }
        if ($field === 'email') {
            return __('Shippo rejected the customer\'s email address. Edit the order\'s shipping address.', 'shipping-for-fluent-cart');
        }

        return __('Shippo rejected the customer\'s shipping address. Edit the order\'s shipping address and try again.', 'shipping-for-fluent-cart');
    }

    protected function rateCarrier(?array $rate, string $fallback): string
    {
        $provider = $rate ? sanitize_text_field((string) Arr::get($rate, 'provider', '')) : '';

        return $provider !== '' ? $provider : $fallback;
    }

    /**
     * Keeps Shippo's own words findable once the admin sees the reworded message.
     */
    protected function logLabelRefusal(string $detail, ?array $rate, int $orderId): void
    {
        $unknown = __('unknown', 'shipping-for-fluent-cart');

        // Shippo's text may echo the addresses it refused; they never reach the log.
        $order  = $orderId ? Order::find($orderId) : null;
        $to     = $order ? $this->orderAddressTo($order) : [];
        $detail = ShippoClient::redact($detail, array_merge(
            ShippoClient::personalValues(['address_from' => $this->addressFrom(), 'address_to' => is_array($to) ? $to : []]),
            [$this->tokenFor(true), $this->tokenFor(false)]
        ));

        fluent_cart_warning_log(
            __('Shippo label refused', 'shipping-for-fluent-cart'),
            sprintf(
                /* translators: %1$s: carrier, %2$s: service, %3$d: order id, %4$s: test or live, %5$s: Shippo's error message */
                __('Carrier: %1$s. Service: %2$s. Order #%3$d. Mode: %4$s. Shippo said: %5$s', 'shipping-for-fluent-cart'),
                $this->rateCarrier($rate, $unknown),
                $rate ? ($this->serviceTitle($rate) ?: $unknown) : $unknown,
                $orderId,
                $this->isSandbox() ? 'test' : 'live',
                $detail
            ),
            ['module_name' => 'shipment', 'module_type' => self::SLUG]
        );
    }

    protected function labelMetadata(Order $order): string
    {
        return 'Order #' . (int) $order->id;
    }
}
