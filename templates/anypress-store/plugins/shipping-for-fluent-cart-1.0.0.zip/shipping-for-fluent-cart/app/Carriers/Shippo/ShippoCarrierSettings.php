<?php

namespace ShippingForFluentCart\App\Carriers\Shippo;

use FluentCart\App\Modules\Shipping\Carriers\Core\BaseCarrierSettings;

class ShippoCarrierSettings extends BaseCarrierSettings
{
    protected string $metaKey = 'fluent_cart_carrier_settings_shippo';

    public function getDefaults(): array
    {
        return [
            'is_active'             => 'no',
            'sandbox_mode'          => 'yes',
            'test_token'            => '',
            'live_token'            => '',
            'enable_rates'          => 'no',
            'enable_labels'         => 'no',
            'default_carrier'       => '',
            // '' = Store Settings units; a stored metric/imperial is kept from the old field (decision 04).
            'unit_of_measurement'   => '',
            'seller_phone'          => '',
            'seller_email'          => (string) get_option('admin_email'),
            'rotate_webhook_secret' => 'no',
            // Synced on save (validateSettings); the Preferred Carrier options.
            'connected_carriers'    => [],
            'carriers_synced_at'    => '',
            // Not a declared field, so the settings API never returns or accepts it.
            // Set on save (validateSettings), never on read.
            'webhook_secret'        => '',
            // Set by the settings-page actions, never by the form.
            'connection_ok'         => '',
            'connection_owner'      => '',
            'connection_checked_at' => '',
            'test_webhook_id'       => '',
            'live_webhook_id'       => '',
            'test_webhook_state'    => '',
            'live_webhook_state'    => '',
            'webhook_error'         => '',
            'webhook_checked_at'    => '',
            'last_event_at'         => '',
        ];
    }
}
