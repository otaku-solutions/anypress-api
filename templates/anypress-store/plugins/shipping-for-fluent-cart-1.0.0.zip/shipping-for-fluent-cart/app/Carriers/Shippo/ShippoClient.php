<?php

namespace ShippingForFluentCart\App\Carriers\Shippo;

/**
 * Thin Shippo REST client. Errors carry ['http_code' => int] (0 = no response),
 * so callers can tell a definite rejection from an unknown outcome.
 */
class ShippoClient
{
    const BASE_URL = 'https://api.goshippo.com';

    const BACKOFF_PREFIX = 'fct_shippo_backoff_';

    const MAX_BACKOFF_SECONDS = 3600;

    const MAX_ERROR_LENGTH = 300;

    protected string $token;

    public function __construct(string $token)
    {
        $this->token = trim($token);
    }

    public static function isTestToken(string $token): bool
    {
        return strpos(trim($token), 'shippo_test_') === 0;
    }

    public static function isLiveToken(string $token): bool
    {
        return strpos(trim($token), 'shippo_live_') === 0;
    }

    /**
     * @param string $path    e.g. '/shipments'; each segment is URL-encoded.
     * @param array  $body    JSON body, or the query string for GET.
     * @param array  $private More values to keep out of the log, never sent: the addresses
     *                        behind a rate, which a POST /transactions body does not hold.
     * @return array|\WP_Error Decoded response body.
     */
    public function request(string $method, string $path, array $body = [], int $timeout = 30, array $private = [])
    {
        $method = strtoupper($method);

        if ($this->token === '') {
            return new \WP_Error('shippo_auth', __('Shippo API token is missing.', 'shipping-for-fluent-cart'), ['http_code' => 0]);
        }

        if ($this->backoffRemaining() > 0) {
            return $this->rateLimitError(['http_code' => 429]);
        }

        $url = self::BASE_URL . $this->encodePath($path);

        $args = [
            'method'  => $method,
            'timeout' => $timeout,
            'headers' => [
                'Authorization' => 'ShippoToken ' . $this->token,
                'Accept'        => 'application/json',
            ],
        ];

        if ($method === 'GET') {
            if ($body) {
                $url .= '?' . http_build_query($body, '', '&', PHP_QUERY_RFC3986);
            }
        } else {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = $body ? wp_json_encode($body) : '{}';
        }

        $response = wp_remote_request($url, $args);

        $private = array_merge(static::personalValues($body), $private, [$this->token]);

        if (is_wp_error($response)) {
            $this->log($method, $path, 0, static::redact($response->get_error_message(), $private));
            return new \WP_Error(
                'shippo_network',
                __('Could not reach Shippo. Please try again.', 'shipping-for-fluent-cart'),
                ['http_code' => 0]
            );
        }

        $code    = (int) wp_remote_retrieve_response_code($response);
        $decoded = json_decode((string) wp_remote_retrieve_body($response), true);
        $data    = ['http_code' => $code];

        if ($code >= 200 && $code < 300) {
            // DELETE /webhooks/{id} answers 204 with no body.
            if ($code === 204) {
                return [];
            }

            if (!is_array($decoded)) {
                // Proxy pages and truncated bodies: the outcome is unknown, not empty.
                $this->log($method, $path, $code, 'Non-JSON response body.');
                return new \WP_Error('shippo_bad_response', __('Shippo returned an unreadable response. Please try again.', 'shipping-for-fluent-cart'), ['http_code' => 0]);
            }

            return $decoded;
        }

        $decoded = is_array($decoded) ? $decoded : [];
        $full    = static::errorText($decoded, false);
        $detail  = static::cap($full);
        $this->log($method, $path, $code, static::cap(static::redact($full, $private)));

        if ($code === 401) {
            return new \WP_Error('shippo_auth', __('Shippo rejected the API token. Check your test or live token.', 'shipping-for-fluent-cart'), $data);
        }

        if ($code === 429) {
            $this->startBackoff((int) wp_remote_retrieve_header($response, 'retry-after'));
            return $this->rateLimitError($data);
        }

        if ($code >= 500) {
            return new \WP_Error('shippo_server', __('Shippo is having trouble right now. Please try again shortly.', 'shipping-for-fluent-cart'), $data);
        }

        if ($detail === '') {
            /* translators: %d: HTTP status code */
            $detail = sprintf(__('Shippo returned an error (HTTP %d).', 'shipping-for-fluent-cart'), $code);
        }

        return new \WP_Error('shippo_api', $detail, $data);
    }

    /**
     * A 4xx Shippo answered, so the call did nothing. Timeouts, 5xx, 408 and 429
     * leave the outcome unknown.
     */
    public static function isDefiniteRejection(\WP_Error $error): bool
    {
        $data = $error->get_error_data();
        $code = is_array($data) && isset($data['http_code']) ? (int) $data['http_code'] : 0;

        return $code >= 400 && $code < 500 && !in_array($code, [408, 429], true);
    }

    /**
     * Masks what a log must never hold, as Shippo or the carrier behind it may echo
     * what it rejected: the given values (address details sent, the token), and any
     * email, phone-like number or Shippo token. Text at errorText()'s cap may end in the
     * start of a value, so there a cut-off value at the end is masked too.
     */
    public static function redact(string $text, array $values = []): string
    {
        $cut    = (function_exists('mb_strlen') ? mb_strlen($text) : strlen($text)) >= self::MAX_ERROR_LENGTH;
        // Each value as given, and as errorText() normalizes text: tags stripped, whitespace collapsed.
        $forms = [];
        foreach ($values as $value) {
            $forms[] = trim((string) $value);
            $forms[] = static::normalize((string) $value);
        }
        $values = array_values(array_unique(array_filter($forms, function ($value) {
            return strlen($value) >= 3;
        })));
        usort($values, function ($a, $b) {
            return strlen($b) - strlen($a);
        });
        foreach ($values as $value) {
            $text = str_ireplace($value, '[redacted]', $text);
        }
        foreach ($cut ? $values : [] as $value) {
            for ($length = min(strlen($value) - 1, strlen($text)); $length >= 3; $length--) {
                if (substr_compare($text, substr($value, 0, $length), -$length, $length, true) === 0) {
                    $text = substr($text, 0, -$length) . '[redacted]';
                    break 2;
                }
            }
        }

        $text = preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', '[email]', $text);
        $text = preg_replace('/\bshippo_(?:test|live)_[A-Za-z0-9]+/', '[token]', $text);

        return preg_replace('/\+?\(?\d[\d\s().\-]{6,}\d/', '[number]', $text);
    }

    /**
     * The address details in a request body or address list: names, companies, streets,
     * cities, postcodes, phones and emails, at any depth.
     */
    public static function personalValues(array $data): array
    {
        $keys   = ['name', 'company', 'street1', 'street2', 'street3', 'city', 'zip', 'phone', 'email'];
        $values = [];

        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $values = array_merge($values, static::personalValues($value));
            } elseif (is_scalar($value) && in_array($key, $keys, true)) {
                $values[] = (string) $value;
            }
        }

        return $values;
    }

    /**
     * First readable error text from a Shippo body, stripped and capped: it is
     * shown to admins through an HTML-rendering notifier. Uncapped, for a log that
     * redacts the whole text before capping it.
     */
    public static function errorText(array $decoded, bool $capped = true): string
    {
        $parts = [];

        foreach ((array) (isset($decoded['messages']) ? $decoded['messages'] : []) as $message) {
            if (is_array($message) && isset($message['text']) && is_scalar($message['text'])) {
                $parts[] = (string) $message['text'];
            }
        }

        foreach (['non_field_errors', 'detail'] as $key) {
            if (!empty($decoded[$key])) {
                $parts[] = implode(' ', array_filter((array) $decoded[$key], 'is_scalar'));
            }
        }

        if (!$parts) {
            foreach ($decoded as $field => $messages) {
                if (!is_string($field) || in_array($field, ['messages', 'non_field_errors', 'detail'], true)) {
                    continue;
                }
                static::collectFieldErrors($field, $messages, $parts);
            }
        }

        $text = static::normalize(implode('; ', $parts));

        return $capped ? static::cap($text) : $text;
    }

    protected static function normalize(string $text): string
    {
        return trim(preg_replace('/\s+/', ' ', wp_strip_all_tags($text)));
    }

    protected static function cap(string $text): string
    {
        return function_exists('mb_substr') ? mb_substr($text, 0, self::MAX_ERROR_LENGTH) : substr($text, 0, self::MAX_ERROR_LENGTH);
    }

    /**
     * Nested field errors as dotted paths ("address_to.phone: ..."), so callers
     * can tell which address and field Shippo refused.
     */
    protected static function collectFieldErrors(string $path, $messages, array &$parts, int $depth = 0): void
    {
        if (is_scalar($messages)) {
            $parts[] = $path . ': ' . $messages;
            return;
        }

        if (!is_array($messages) || $depth >= 4) {
            return;
        }

        $flat   = [];
        $nested = [];
        foreach ($messages as $key => $value) {
            if (is_int($key) && is_scalar($value)) {
                $flat[] = $value;
            } else {
                $nested[$key] = $value;
            }
        }

        if ($flat) {
            $parts[] = $path . ': ' . implode(' ', $flat);
        }

        foreach ($nested as $key => $value) {
            static::collectFieldErrors($path . '.' . $key, $value, $parts, $depth + 1);
        }
    }

    public function backoffRemaining(): int
    {
        $until = (int) get_transient($this->backoffKey());

        return max(0, $until - time());
    }

    protected function startBackoff(int $seconds): void
    {
        if ($seconds <= 0) {
            $seconds = 60;
        }
        $seconds = min($seconds, self::MAX_BACKOFF_SECONDS);

        set_transient($this->backoffKey(), time() + $seconds, $seconds);
    }

    protected function backoffKey(): string
    {
        // Per token: Shippo limits per account, and the token never lands in options.
        return self::BACKOFF_PREFIX . substr(md5($this->token), 0, 12);
    }

    protected function rateLimitError(array $data): \WP_Error
    {
        return new \WP_Error(
            'shippo_ratelimit',
            __('Shippo rate limit reached. Please try again in a minute.', 'shipping-for-fluent-cart'),
            $data
        );
    }

    protected function encodePath(string $path): string
    {
        $segments = array_filter(explode('/', $path), function ($segment) {
            return $segment !== '' && $segment !== '.' && $segment !== '..';
        });

        return '/' . implode('/', array_map('rawurlencode', $segments));
    }

    protected function log(string $method, string $path, int $code, string $detail): void
    {
        if (!function_exists('fluent_cart_error_log')) {
            return;
        }

        fluent_cart_error_log(
            'Shippo API error',
            sprintf('%s %s -> HTTP %d. %s', $method, $path, $code, $detail),
            ['log_type' => 'api', 'module_name' => 'shipment', 'module_type' => 'shippo']
        );
    }
}
