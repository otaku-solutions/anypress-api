<?php

namespace ShippingForFluentCart\App\Carriers\Shippo;

use FluentCart\App\Helpers\Helper;
use FluentCart\App\Models\Order;
use FluentCart\App\Models\OrderItem;
use FluentCart\App\Services\Shipments\BoxPacker;
use FluentCart\Framework\Support\Arr;

/**
 * Parcels and customs lines for Shippo. A parcel weighs its products plus the
 * box (tare), on both the checkout and the dispatch path.
 */
class ShippoPackaging
{
    /**
     * Cap on parcels one checkout quote may send: cart quantity is visitor-controlled.
     */
    const MAX_CHECKOUT_PARCELS = 100;

    /**
     * EU customs union: shipments between these need no customs declaration.
     */
    const EU_CUSTOMS_UNION = [
        'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE',
        'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE', 'MC',
    ];

    /**
     * Shippo's minimum per-item customs weight, used when a product has none.
     */
    const NOMINAL_ITEM_WEIGHT_KG = 0.1;

    protected string $fallbackMass;

    protected string $fallbackDistance;

    protected string $storeWeightUnit;

    public function __construct(bool $imperial)
    {
        $this->fallbackMass     = $imperial ? 'lb' : 'kg';
        $this->fallbackDistance = $imperial ? 'in' : 'cm';
        $this->storeWeightUnit  = (string) Helper::shopConfig('weight_unit') ?: 'kg';
    }

    public static function needsCustoms(string $fromCountry, string $toCountry): bool
    {
        $fromCountry = strtoupper($fromCountry);
        $toCountry   = strtoupper($toCountry);

        if (!$fromCountry || !$toCountry || $fromCountry === $toCountry) {
            return false;
        }

        return !(in_array($fromCountry, self::EU_CUSTOMS_UNION, true) && in_array($toCountry, self::EU_CUSTOMS_UNION, true));
    }

    /**
     * @param array $items Cart line items.
     * @return array[] Shippo parcels, never empty.
     */
    public function checkoutParcels(array $items): array
    {
        $lines = [];
        foreach ($items as $item) {
            if (Arr::get($item, 'fulfillment_type') !== 'physical') {
                continue;
            }

            $info    = (array) Arr::get($item, 'other_info', []);
            $package = Helper::getPackageBySlug((string) Arr::get($info, 'package_slug', ''));
            $box     = $this->boxFromPackage(is_array($package) ? $package : [], (string) Arr::get($info, 'package_slug', ''));

            $lines[] = [
                'content_weight' => $this->toStoreUnit(Arr::get($info, 'weight', 0), Arr::get($info, 'weight_unit', '')),
                'qty'            => max(1, (int) Arr::get($item, 'quantity', 1)),
                'box'            => $box,
            ];
        }

        return $this->toShippoParcels($this->pack($lines, self::MAX_CHECKOUT_PARCELS));
    }

    /**
     * Fingerprint of the shipping-relevant cart fields, for the rate cache key.
     */
    public function checkoutCacheKey(array $items): string
    {
        $parts = [];
        foreach ($items as $item) {
            if (Arr::get($item, 'fulfillment_type') !== 'physical') {
                continue;
            }
            $info    = (array) Arr::get($item, 'other_info', []);
            $parts[] = implode(':', [
                (string) Arr::get($item, 'object_id', Arr::get($item, 'post_id', '')),
                (string) (int) Arr::get($item, 'quantity', 1),
                (string) Arr::get($info, 'weight', ''),
                (string) Arr::get($info, 'weight_unit', ''),
                (string) Arr::get($info, 'package_slug', ''),
            ]);
        }
        sort($parts);

        // The fallback units weigh and size items that have none of their own.
        return $parts ? md5($this->fallbackMass . $this->fallbackDistance . '|' . implode('|', $parts)) : '';
    }

    /**
     * The dispatched order items, read scoped to the order (ids come from the client).
     *
     * @param array $dispatched List of ['order_item_id' => int, 'qty' => int].
     * @return array[] [['item' => OrderItem, 'qty' => int], ...]
     */
    public function dispatchedLines(Order $order, array $dispatched): array
    {
        $ids = array_filter(array_map('intval', array_column($dispatched, 'order_item_id')));
        if (!$ids) {
            return [];
        }

        $orderItems = OrderItem::query()
            ->whereIn('id', $ids)
            ->where('order_id', $order->id)
            ->get()
            ->keyBy('id');

        $lines = [];
        foreach ($dispatched as $entry) {
            $itemId = (int) Arr::get($entry, 'order_item_id', 0);
            $qty    = (int) Arr::get($entry, 'qty', 0);
            if ($qty < 1 || !isset($orderItems[$itemId])) {
                continue;
            }
            $lines[] = ['item' => $orderItems[$itemId], 'qty' => $qty];
        }

        return $lines;
    }

    /**
     * @param array[] $lines From dispatchedLines().
     * @return array[] Shippo parcels, never empty.
     */
    public function dispatchParcels(array $lines): array
    {
        $packLines = [];
        foreach ($lines as $line) {
            $info = $this->itemInfo($line['item']);

            if (Arr::get($info, 'package_length', '') !== '' || Arr::get($info, 'package_weight', '') !== '') {
                // The box as it was when the order was placed.
                $package = [
                    'length'         => Arr::get($info, 'package_length', 10),
                    'width'          => Arr::get($info, 'package_width', 10),
                    'height'         => Arr::get($info, 'package_height', 10),
                    'dimension_unit' => Arr::get($info, 'package_dimension_unit', ''),
                    'weight'         => Arr::get($info, 'package_weight', 0),
                    'weight_unit'    => Arr::get($info, 'package_weight_unit', ''),
                    'max_weight'     => Arr::get($info, 'package_max_weight', 0),
                ];
            } else {
                $package = Helper::getPackageBySlug((string) Arr::get($info, 'package_slug', ''));
            }

            $packLines[] = [
                'content_weight' => $this->toStoreUnit(Arr::get($info, 'weight', 0), Arr::get($info, 'weight_unit', '')),
                'qty'            => $line['qty'],
                'box'            => $this->boxFromPackage(is_array($package) ? $package : [], (string) Arr::get($info, 'package_slug', '')),
            ];
        }

        // Admin dispatch is not visitor-driven: no parcel cap.
        return $this->toShippoParcels($this->pack($packLines, 0));
    }

    /**
     * Customs lines: Shippo wants net_weight and value_amount as line totals.
     *
     * @param array[] $lines From dispatchedLines().
     */
    public function customsItems(array $lines, string $originCountry, string $currency): array
    {
        $massUnit = $this->massUnit($this->storeWeightUnit);
        $nominal  = Helper::convertWeight(self::NOMINAL_ITEM_WEIGHT_KG, 'kg', $this->storeWeightUnit);

        $customs = [];
        foreach ($lines as $line) {
            $item = $line['item'];
            $qty  = (int) $line['qty'];
            $info = $this->itemInfo($item);

            $unitWeight = $this->toStoreUnit(Arr::get($info, 'weight', 0), Arr::get($info, 'weight_unit', ''));
            if ($unitWeight <= 0) {
                $unitWeight = $nominal;
            }

            $title = trim(wp_strip_all_tags((string) ($item->title ?: $item->post_title)));

            $customs[] = [
                'description'    => $title !== '' ? mb_substr($title, 0, 100) : 'Merchandise',
                'quantity'       => $qty,
                'net_weight'     => $this->formatWeight($unitWeight * $qty),
                'mass_unit'      => $massUnit,
                'value_amount'   => number_format((Helper::roundCent($item->unit_price) * $qty) / 100, 2, '.', ''),
                'value_currency' => strtoupper($currency),
                'origin_country' => strtoupper($originCountry),
            ];
        }

        return $customs;
    }

    public function formatWeight($weight): string
    {
        return number_format((float) $weight, 4, '.', '');
    }

    protected function pack(array $lines, int $maxParcels): array
    {
        if (class_exists(BoxPacker::class)) {
            return BoxPacker::pack($lines, $maxParcels);
        }

        // Older core without BoxPacker: one parcel, every unit and one tare per box key.
        $weight = 0.0;
        $tares  = [];
        $box    = null;
        foreach ($lines as $line) {
            $weight += (float) $line['content_weight'] * (int) $line['qty'];
            $tares[$line['box']['key']] = (float) $line['box']['tare'];
            $box = $box ?: $line['box'];
        }

        if ($weight <= 0 || !$box) {
            return [];
        }

        return [[
            'length'         => $box['length'],
            'width'          => $box['width'],
            'height'         => $box['height'],
            'dimension_unit' => $box['dimension_unit'],
            'weight'         => $weight + array_sum($tares),
        ]];
    }

    protected function boxFromPackage(array $package, string $slug): array
    {
        $unit = (string) Arr::get($package, 'weight_unit', '');

        $box = [
            'length'         => (float) Arr::get($package, 'length', 10) ?: 10.0,
            'width'          => (float) Arr::get($package, 'width', 10) ?: 10.0,
            'height'         => (float) Arr::get($package, 'height', 10) ?: 10.0,
            'dimension_unit' => $this->distanceUnit(Arr::get($package, 'dimension_unit', '')),
            'tare'           => $this->toStoreUnit(Arr::get($package, 'weight', 0), $unit),
            'max_weight'     => $this->toStoreUnit(Arr::get($package, 'max_weight', 0), $unit),
        ];

        // Same box only when it is the same preset with the same size and capacity.
        $box['key'] = $slug . '|' . $box['length'] . 'x' . $box['width'] . 'x' . $box['height'] . $box['dimension_unit'] . '|' . $box['max_weight'];

        return $box;
    }

    /**
     * @param array[] $parcels BoxPacker parcels, weights in the store unit.
     */
    protected function toShippoParcels(array $parcels): array
    {
        if (!$parcels) {
            return [[
                'length'        => '10.00',
                'width'         => '10.00',
                'height'        => '10.00',
                'distance_unit' => $this->fallbackDistance,
                'weight'        => $this->formatWeight(1),
                'mass_unit'     => $this->fallbackMass,
            ]];
        }

        $massUnit = $this->massUnit($this->storeWeightUnit);

        return array_map(function ($parcel) use ($massUnit) {
            return [
                'length'        => number_format((float) $parcel['length'], 2, '.', ''),
                'width'         => number_format((float) $parcel['width'], 2, '.', ''),
                'height'        => number_format((float) $parcel['height'], 2, '.', ''),
                'distance_unit' => $this->distanceUnit($parcel['dimension_unit']),
                'weight'        => $this->formatWeight($parcel['weight']),
                'mass_unit'     => $massUnit,
            ];
        }, $parcels);
    }

    /**
     * A weight without its own unit is in the Shippo fallback unit, not the store unit.
     */
    protected function toStoreUnit($weight, $unit): float
    {
        $weight = (float) $weight;
        if ($weight <= 0) {
            return 0.0;
        }

        $unit = strtolower(trim((string) $unit)) ?: $this->fallbackMass;
        if ($unit === 'lb') {
            $unit = 'lbs';
        }

        return (float) Helper::convertWeight($weight, $unit, $this->storeWeightUnit);
    }

    /**
     * FluentCart offers kg/g/lbs/oz; Shippo spells pounds `lb`.
     */
    protected function massUnit($unit): string
    {
        $map  = ['kg' => 'kg', 'g' => 'g', 'lbs' => 'lb', 'lb' => 'lb', 'oz' => 'oz'];
        $unit = strtolower(trim((string) $unit));

        return isset($map[$unit]) ? $map[$unit] : $this->fallbackMass;
    }

    protected function distanceUnit($unit): string
    {
        $unit = strtolower(trim((string) $unit));

        return in_array($unit, ['cm', 'mm', 'in', 'm', 'ft', 'yd'], true) ? $unit : $this->fallbackDistance;
    }

    protected function itemInfo(OrderItem $item): array
    {
        return is_array($item->other_info) ? $item->other_info : [];
    }
}
