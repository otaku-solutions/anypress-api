<?php

namespace ShippingForFluentCart\App\Carriers\Shippo;

use FluentCart\App\Helpers\AddressHelper;
use FluentCart\App\Helpers\Helper;
use FluentCart\App\Models\ProductVariation;
use FluentCart\App\Services\DateTime\DateTime;
use FluentCart\Framework\Support\Arr;

/**
 * The Shippo settings page as FluentCart draws it with section cards, status
 * strips and actions, and the actions its buttons run at once.
 */
trait ShippoSettingsPage
{
    protected function designedFields(): array
    {
        $on       = ['key' => 'is_active', 'value' => 'yes'];
        $labelsOn = ['key' => 'enable_labels', 'value' => 'yes'];
        $test     = $this->isSandbox();

        $fields = [
            $this->section('section_connection', __('Connection', 'shipping-for-fluent-cart')) + ['badge' => $this->connectionBadge()],
            [
                'key'   => 'is_active',
                'type'  => 'toggle',
                'label' => __('Enable Shippo', 'shipping-for-fluent-cart'),
                'hint'  => __('Turns Shippo rates, labels and tracking updates on for the store.', 'shipping-for-fluent-cart'),
            ],
            [
                'key'     => 'off_notice',
                'type'    => 'notice',
                'tone'    => 'mute',
                'text'    => __('Shippo is off. Checkout rates, labels and tracking updates stop until you turn it back on.', 'shipping-for-fluent-cart'),
                'show_if' => ['key' => 'is_active', 'value' => 'no'],
            ],
            $this->connectionStatus() + ['show_if' => $on],
            [
                'key'     => 'sandbox_mode',
                'type'    => 'mode',
                'layout'  => 'row',
                'label'   => __('Connection mode', 'shipping-for-fluent-cart'),
                'options' => [
                    $this->modeOption(false),
                    $this->modeOption(true),
                ],
            ],

            $this->section('section_checkout', __('Checkout rates', 'shipping-for-fluent-cart')) + ['active_if' => $on],
            [
                'key'   => 'enable_rates',
                'type'  => 'toggle',
                'label' => __('Show Shippo rates at checkout', 'shipping-for-fluent-cart'),
                'hint'  => __('Live rates appear next to your zone shipping methods. Every carrier that returns a rate is shown.', 'shipping-for-fluent-cart'),
            ],

            $this->section('section_labels', __('Labels', 'shipping-for-fluent-cart')) + ['active_if' => $on],
            [
                'key'   => 'enable_labels',
                'type'  => 'toggle',
                'label' => __('Buy labels from the order page', 'shipping-for-fluent-cart'),
                'hint'  => __('Quote and buy labels in the Create shipment form.', 'shipping-for-fluent-cart'),
            ],
            $this->preferredCarrierField() + ['show_if' => $labelsOn],
            $this->unitsField() + ['show_if' => $labelsOn],
        ];

        if ($legacy = $this->legacyUnitNotice()) {
            $fields[] = $legacy + ['show_if' => $labelsOn];
        }
        if ($unitless = $this->unitlessNotice()) {
            $fields[] = $unitless + ['show_if' => $labelsOn];
        }

        $fields = array_merge($fields, [
            $this->section('section_sender', __('Sender', 'shipping-for-fluent-cart')) + [
                'aside'     => __('Printed on every label', 'shipping-for-fluent-cart'),
                'active_if' => $on,
            ],
            [
                'key'     => 'sender_off',
                'type'    => 'notice',
                'tone'    => 'mute',
                'text'    => __('Sender details are used only on labels. Turn on labels to edit them.', 'shipping-for-fluent-cart'),
                'show_if' => ['key' => 'enable_labels', 'value' => 'no'],
            ],
        ]);

        if (trim((string) $this->settings->get('seller_phone')) === '') {
            $fields[] = [
                'key'     => 'phone_notice',
                'type'    => 'notice',
                'tone'    => 'warn',
                'text'    => __('USPS labels need a sender phone. Add one below so labels don\'t fail at Buy.', 'shipping-for-fluent-cart'),
                'show_if' => $labelsOn,
            ];
        }

        return array_merge($fields, [
            [
                'key'     => 'ships_from',
                'type'    => 'readonly',
                'label'   => __('Ships from', 'shipping-for-fluent-cart'),
                'value'   => $this->shipsFromText(),
                'link'    => ['label' => __('Edit in Store Settings', 'shipping-for-fluent-cart'), 'route' => '/settings/store-settings'],
                'show_if' => $labelsOn,
            ],
            [
                'key'         => 'seller_phone',
                'type'        => 'text',
                'label'       => __('Phone', 'shipping-for-fluent-cart'),
                'label_note'  => __('required for USPS', 'shipping-for-fluent-cart'),
                'hint'        => __('Carriers call this number if a parcel has a problem. Include the country code, like +1 for the US.', 'shipping-for-fluent-cart'),
                'empty_hint'  => ['tone' => 'warn', 'text' => __('Empty. USPS refuses labels without a sender phone.', 'shipping-for-fluent-cart')],
                'placeholder' => '+1 555 123 4567',
                'width'       => 'half',
                'show_if'     => $labelsOn,
            ],
            [
                'key'         => 'seller_email',
                'type'        => 'text',
                'label'       => __('Email', 'shipping-for-fluent-cart'),
                'hint'        => __('Filled from the store\'s admin email. Change it if labels need another address.', 'shipping-for-fluent-cart'),
                'placeholder' => 'shipping@example.com',
                'width'       => 'half',
                'show_if'     => $labelsOn,
            ],

            $this->section('section_tracking', __('Tracking updates', 'shipping-for-fluent-cart')) + [
                'badge'     => $this->webhookBadge(),
                'active_if' => $on,
            ],
            $this->webhookStatus(),
            [
                'key'        => 'webhook_setup',
                'type'       => 'webhook_setup',
                'label'      => __('Set it up in Shippo yourself', 'shipping-for-fluent-cart'),
                'mask_param' => 'fcs_token',
                'open'       => $this->webhookState() === 'failed',
                'steps'      => [
                    __('In Shippo, open Settings › API › Webhooks.', 'shipping-for-fluent-cart'),
                    __('Add this URL for the **track_updated** event.', 'shipping-for-fluent-cart'),
                    $test
                        ? __('Mark it **Test** to match this store\'s mode.', 'shipping-for-fluent-cart')
                        : __('Mark it **Live** to match this store\'s mode.', 'shipping-for-fluent-cart'),
                ],
            ],
        ]);
    }

    /* ---------------------------------------------------------- connection */

    protected function connectionBadge(): array
    {
        if ($this->settings->get('is_active') !== 'yes') {
            return ['tone' => 'mute', 'text' => __('Off', 'shipping-for-fluent-cart')];
        }
        if ($this->tokenFor($this->isSandbox()) === '') {
            return ['tone' => 'warn', 'text' => __('Not connected', 'shipping-for-fluent-cart')];
        }
        if ($this->settings->get('connection_ok') === 'no') {
            return ['tone' => 'err', 'dot' => true, 'text' => __('Token rejected', 'shipping-for-fluent-cart')];
        }

        return [
            'tone' => 'ok',
            'dot'  => true,
            'text' => $this->isSandbox() ? __('Connected · Test mode', 'shipping-for-fluent-cart') : __('Connected · Live mode', 'shipping-for-fluent-cart'),
        ];
    }

    protected function connectionStatus(): array
    {
        $test   = $this->isSandbox();
        $action = [
            'action'  => 'test_connection',
            'label'   => __('Test connection', 'shipping-for-fluent-cart'),
            'working' => [
                'title'  => $test ? __('Checking the test token with Shippo', 'shipping-for-fluent-cart') : __('Checking the live token with Shippo', 'shipping-for-fluent-cart'),
                'text'   => __('Usually takes under a second.', 'shipping-for-fluent-cart'),
                'badge'  => __('Checking', 'shipping-for-fluent-cart'),
                'button' => __('Testing', 'shipping-for-fluent-cart'),
            ],
        ];
        $status = ['key' => 'connection_status', 'type' => 'status'];

        if ($this->tokenFor($test) === '') {
            return $status + [
                'title' => __('Not connected to Shippo', 'shipping-for-fluent-cart'),
                'text'  => $test ? __('Add your test token below, then save.', 'shipping-for-fluent-cart') : __('Add your live token below, then save.', 'shipping-for-fluent-cart'),
            ];
        }

        if ($this->settings->get('connection_ok') === 'no') {
            return $status + [
                'tone'    => 'err',
                'title'   => $test ? __('Shippo didn\'t accept the test token', 'shipping-for-fluent-cart') : __('Shippo didn\'t accept the live token', 'shipping-for-fluent-cart'),
                'text'    => $test
                    ? __('Check it starts with shippo_test_ and wasn\'t revoked in Shippo › Settings › API.', 'shipping-for-fluent-cart')
                    : __('Check it starts with shippo_live_ and wasn\'t revoked in Shippo › Settings › API.', 'shipping-for-fluent-cart'),
                'actions' => [$action],
            ];
        }

        $items = [];
        if ($owner = (string) $this->settings->get('connection_owner')) {
            $items[] = ['label' => __('Account', 'shipping-for-fluent-cart'), 'value' => $owner];
        }
        $items[] = ['label' => __('Carriers', 'shipping-for-fluent-cart'), 'value' => (string) count((array) $this->settings->get('connected_carriers'))];
        if ($checked = (string) ($this->settings->get('connection_checked_at') ?: $this->settings->get('carriers_synced_at'))) {
            $items[] = ['label' => __('Checked', 'shipping-for-fluent-cart'), 'value' => $this->ago($checked)];
        }

        return $status + [
            'title'   => __('Connected to Shippo', 'shipping-for-fluent-cart'),
            'items'   => $items,
            'actions' => [$action],
        ];
    }

    protected function modeOption(bool $test): array
    {
        $key   = $test ? 'test_token' : 'live_token';
        $token = $this->tokenFor($test);
        $end   = substr($token, -4);
        $hint  = $test
            ? __('Starts with shippo_test_. Find it in Shippo › Settings › API.', 'shipping-for-fluent-cart')
            : __('Starts with shippo_live_. Find it in Shippo › Settings › API.', 'shipping-for-fluent-cart');

        if ($token === '') {
            $tag = ['tone' => 'mute', 'text' => $test ? __('No test token saved', 'shipping-for-fluent-cart') : __('No live token saved', 'shipping-for-fluent-cart')];
        } elseif ($test === $this->isSandbox() && $this->settings->get('connection_ok') === 'no') {
            /* translators: %1$s: last four characters of the token */
            $tag = ['tone' => 'err', 'text' => sprintf(__('Token ending %1$s · rejected', 'shipping-for-fluent-cart'), $end)];
        } elseif ($test === $this->isSandbox()) {
            /* translators: %1$s: last four characters of the token */
            $tag = ['tone' => 'ok', 'text' => sprintf(__('Token ending %1$s · verified', 'shipping-for-fluent-cart'), $end)];
        } else {
            /* translators: %1$s: last four characters of the token */
            $tag = ['tone' => 'ok', 'text' => sprintf(__('Token ending %1$s saved', 'shipping-for-fluent-cart'), $end)];
        }

        return [
            'value'        => $test ? 'yes' : 'no',
            'label'        => $test ? __('Test', 'shipping-for-fluent-cart') : __('Live', 'shipping-for-fluent-cart'),
            'hint'         => $test ? __('Free labels that never ship.', 'shipping-for-fluent-cart') : __('Real labels, billed by Shippo.', 'shipping-for-fluent-cart'),
            'tag'          => $tag,
            'requires'     => $key,
            'missing_note' => $test
                ? __('Add a test token before you save.', 'shipping-for-fluent-cart')
                : __('Add a live token before you save. Until then the store stays on Test.', 'shipping-for-fluent-cart'),
            'fields'       => [
                [
                    'key'         => $key,
                    'type'        => 'password',
                    'label'       => $test ? __('Test token', 'shipping-for-fluent-cart') : __('Live token', 'shipping-for-fluent-cart'),
                    'placeholder' => $test ? 'shippo_test_…' : 'shippo_live_…',
                    'hint'        => $hint,
                    // Same text once saved: the card's tag already says so, and this keeps core from adding its own note.
                    'saved_hint'  => $hint,
                    'typed_hint'  => __('Shippo checks the new token when you save.', 'shipping-for-fluent-cart'),
                ],
            ],
        ];
    }

    /* -------------------------------------------------------------- labels */

    protected function preferredCarrierField(): array
    {
        $own    = [];
        $shippo = [];
        foreach ((array) $this->settings->get('connected_carriers') as $carrier) {
            $option = ['value' => (string) $carrier['carrier'], 'label' => (string) $carrier['name']];
            if (Arr::get($carrier, 'own')) {
                $ending = (string) Arr::get($carrier, 'account_ending', '');
                /* translators: %1$s: last characters of the carrier account id */
                $option['sub'] = $ending !== '' ? sprintf(__('account ending %1$s', 'shipping-for-fluent-cart'), $ending) : '';
                $own[] = $option;
            } else {
                $services = (int) Arr::get($carrier, 'services', 0);
                /* translators: %1$d: number of shipping services */
                $option['sub'] = $services ? sprintf(_n('%1$d service', '%1$d services', $services, 'shipping-for-fluent-cart'), $services) : '';
                $shippo[] = $option;
            }
        }

        $pick = (string) $this->settings->get('default_carrier');
        if ($pick !== '' && !in_array($pick, array_column(array_merge($own, $shippo), 'value'), true)) {
            /* translators: %1$s: Shippo carrier token, such as usps */
            $shippo[] = ['value' => $pick, 'label' => sprintf(__('%1$s (not connected)', 'shipping-for-fluent-cart'), $pick)];
        }

        $count   = count($own) + count($shippo);
        $updated = $this->ago((string) $this->settings->get('carriers_synced_at'));
        $footer  = $this->isSandbox()
            /* translators: %1$d: number of carriers, %2$s: time since the list was loaded, e.g. 3 mins ago */
            ? sprintf(_n('%1$d carrier from your test account · updated %2$s', '%1$d carriers from your test account · updated %2$s', $count, 'shipping-for-fluent-cart'), $count, $updated)
            /* translators: %1$d: number of carriers, %2$s: time since the list was loaded, e.g. 3 mins ago */
            : sprintf(_n('%1$d carrier from your live account · updated %2$s', '%1$d carriers from your live account · updated %2$s', $count, 'shipping-for-fluent-cart'), $count, $updated);

        return [
            'key'                => 'default_carrier',
            'type'               => 'select',
            'label'              => __('Preferred carrier', 'shipping-for-fluent-cart'),
            'hint'               => __('The Create shipment form ticks the customer\'s paid service first. If there is none, it ticks this carrier\'s cheapest rate. If this carrier has no rate for the parcel, the cheapest rate overall is used.', 'shipping-for-fluent-cart'),
            'options'            => [['value' => '', 'label' => __('Cheapest of all carriers', 'shipping-for-fluent-cart'), 'sub' => __('Default', 'shipping-for-fluent-cart')]],
            'groups'             => [
                [
                    'label'   => __('Your own accounts', 'shipping-for-fluent-cart'),
                    'empty'   => __('None connected. Carrier accounts you connect in Shippo, such as your own UPS or FedEx, show up here.', 'shipping-for-fluent-cart'),
                    'options' => $own,
                ],
                [
                    'label'   => __('Shippo accounts', 'shipping-for-fluent-cart'),
                    'options' => $shippo,
                ],
            ],
            'search_placeholder' => __('Search carriers', 'shipping-for-fluent-cart'),
            'footer'             => $footer,
            'refresh'            => [
                'action'  => 'refresh_carriers',
                'label'   => __('Refresh list', 'shipping-for-fluent-cart'),
                'working' => __('Loading carriers from Shippo', 'shipping-for-fluent-cart'),
            ],
        ];
    }

    /**
     * The unit system that weighs products and boxes without units: a value kept
     * from the old Shippo setting, else Store Settings.
     */
    protected function usesImperialUnits(): bool
    {
        $saved = (string) $this->settings->get('unit_of_measurement');

        return $saved !== '' ? $saved === 'imperial' : $this->storeIsImperial();
    }

    protected function storeIsImperial(): bool
    {
        return in_array((string) Helper::shopConfig('weight_unit'), ['lbs', 'oz'], true);
    }

    protected function keepsOldUnits(): bool
    {
        return (string) $this->settings->get('unit_of_measurement') !== '' && $this->usesImperialUnits() !== $this->storeIsImperial();
    }

    protected function unitsText(bool $imperial): string
    {
        return $imperial ? __('lb and in', 'shipping-for-fluent-cart') : __('kg and cm', 'shipping-for-fluent-cart');
    }

    protected function storeUnitsText(): string
    {
        $weight    = (string) Helper::shopConfig('weight_unit') ?: 'kg';
        $dimension = (string) Helper::shopConfig('dimension_unit') ?: 'cm';

        /* translators: %1$s: weight unit, %2$s: size unit */
        return sprintf(__('%1$s and %2$s', 'shipping-for-fluent-cart'), $weight, $dimension);
    }

    protected function unitsField(): array
    {
        $kept = $this->keepsOldUnits();

        return [
            'key'   => 'units',
            'type'  => 'readonly',
            'label' => __('Units', 'shipping-for-fluent-cart'),
            'value' => $kept ? $this->unitsText($this->usesImperialUnits()) : $this->storeUnitsText(),
            'hint'  => $kept
                ? __('Kept from your earlier Shippo setting. Used for products and boxes that have no units of their own.', 'shipping-for-fluent-cart')
                : __('From Store Settings. Used for products and boxes that have no units of their own.', 'shipping-for-fluent-cart'),
            'link'  => ['label' => __('Change', 'shipping-for-fluent-cart'), 'route' => '/settings/store-settings'],
        ];
    }

    /**
     * Shown while an earlier Shippo unit choice differs from Store Settings, so rates do not change overnight.
     */
    protected function legacyUnitNotice(): ?array
    {
        if (!$this->keepsOldUnits()) {
            return null;
        }

        return [
            'key'  => 'legacy_units',
            'type' => 'notice',
            'tone' => 'warn',
            'text' => sprintf(
                /* translators: %1$s: units kept from the old Shippo setting, %2$s: Store Settings units */
                __('Shippo still uses %1$s, its earlier setting, for products without units. Store Settings uses %2$s. Set units on those products to use the store units.', 'shipping-for-fluent-cart'),
                $this->unitsText($this->usesImperialUnits()),
                $this->storeUnitsText()
            ),
        ];
    }

    protected function unitlessNotice(): ?array
    {
        $count = $this->unitlessProductCount();
        if (!$count) {
            return null;
        }

        return [
            'key'  => 'unitless_products',
            'type' => 'notice',
            'tone' => 'warn',
            'text' => sprintf(
                /* translators: %1$d: number of products, %2$s: weight unit used for them, e.g. kg */
                _n('%1$d product has a weight but no unit. It is treated as %2$s, the store unit.', '%1$d products have a weight but no unit. They are treated as %2$s, the store unit.', $count, 'shipping-for-fluent-cart'),
                $count,
                $this->usesImperialUnits() ? 'lb' : 'kg'
            ),
            'link' => ['label' => __('Review them', 'shipping-for-fluent-cart'), 'route' => '/products'],
        ];
    }

    /**
     * Products with a physical variation weighed without a unit. Cached for an hour: the settings page reads it on every load.
     */
    protected function unitlessProductCount(): int
    {
        $cached = get_transient('fcs_shippo_unitless_products');
        if ($cached !== false) {
            return (int) $cached;
        }

        $products = [];
        ProductVariation::query()
            ->select(['id', 'post_id', 'other_info'])
            ->where('fulfillment_type', 'physical')
            ->chunk(500, function ($variations) use (&$products) {
                foreach ($variations as $variation) {
                    $info = (array) $variation->other_info;
                    if ((float) Arr::get($info, 'weight', 0) > 0 && trim((string) Arr::get($info, 'weight_unit', '')) === '') {
                        $products[$variation->post_id] = true;
                    }
                }
            });

        set_transient('fcs_shippo_unitless_products', count($products), HOUR_IN_SECONDS);

        return count($products);
    }

    protected function shipsFromText(): string
    {
        $from  = $this->addressFrom();
        $place = trim(implode(', ', array_filter([$from['city'], trim($from['state'] . ' ' . $from['zip'])])));

        return implode("\n", array_filter([
            $from['name'],
            trim(implode(', ', array_filter([$from['street1'], $from['street2'], $place])), ', '),
            $from['country'] ? AddressHelper::getCountryNameByCode($from['country']) : '',
        ]));
    }

    /* ------------------------------------------------------------ tracking */

    protected function webhookState(): string
    {
        $mode  = $this->isSandbox() ? 'test' : 'live';
        $state = (string) $this->settings->get($mode . '_webhook_state');

        return in_array($state, ['registered', 'missing', 'failed'], true) ? $state : 'none';
    }

    protected function webhookBadge(): array
    {
        switch ($this->webhookState()) {
            case 'registered':
                return ['tone' => 'ok', 'dot' => true, 'text' => __('Webhook registered', 'shipping-for-fluent-cart')];
            case 'missing':
                return ['tone' => 'err', 'dot' => true, 'text' => __('Missing in Shippo', 'shipping-for-fluent-cart')];
            case 'failed':
                return ['tone' => 'err', 'dot' => true, 'text' => __('Not registered', 'shipping-for-fluent-cart')];
            default:
                return ['tone' => 'mute', 'text' => __('Not registered', 'shipping-for-fluent-cart')];
        }
    }

    protected function registerAction(string $label, string $variant = ''): array
    {
        return array_filter([
            'action'  => 'register_webhook',
            'label'   => $label,
            'variant' => $variant,
            'working' => ['title' => __('Registering the webhook in Shippo', 'shipping-for-fluent-cart')],
        ]);
    }

    protected function webhookStatus(): array
    {
        $mode   = $this->isSandbox() ? __('Test', 'shipping-for-fluent-cart') : __('Live', 'shipping-for-fluent-cart');
        $status = [
            'key'  => 'webhook_status',
            'type' => 'status',
            'note' => __('Webhook actions take effect right away. They don\'t need Save.', 'shipping-for-fluent-cart'),
        ];

        switch ($this->webhookState()) {
            case 'registered':
                $last  = (string) $this->settings->get('last_event_at');
                $items = [
                    ['label' => __('Event', 'shipping-for-fluent-cart'), 'value' => 'track_updated'],
                    ['label' => __('Mode', 'shipping-for-fluent-cart'), 'value' => $mode],
                    ['label' => __('Last update', 'shipping-for-fluent-cart'), 'value' => $last !== '' ? $this->localTime($last) : __('None yet', 'shipping-for-fluent-cart')],
                ];
                if ($checked = (string) $this->settings->get('webhook_checked_at')) {
                    /* translators: %1$s: time since the check, e.g. just now */
                    $items[] = ['label' => '', 'value' => sprintf(__('Checked %1$s', 'shipping-for-fluent-cart'), $this->ago($checked))];
                }

                return $status + [
                    'title'   => __('Shippo sends tracking updates to this store', 'shipping-for-fluent-cart'),
                    'items'   => $items,
                    'actions' => [
                        ['action' => 'check_webhook', 'label' => __('Check status', 'shipping-for-fluent-cart'), 'working' => ['title' => __('Checking the webhook in Shippo', 'shipping-for-fluent-cart')]],
                        $this->registerAction(__('Re-register', 'shipping-for-fluent-cart')),
                        [
                            'action'  => 'rotate_secret',
                            'label'   => __('Rotate secret', 'shipping-for-fluent-cart'),
                            'variant' => 'danger',
                            'confirm' => [
                                'title'  => __('Rotate the webhook secret?', 'shipping-for-fluent-cart'),
                                'text'   => __('The current URL stops working right away. We register the new URL in Shippo for you, so tracking keeps working.', 'shipping-for-fluent-cart'),
                                'button' => __('Rotate', 'shipping-for-fluent-cart'),
                            ],
                            'working' => ['title' => __('Rotating the secret and updating Shippo', 'shipping-for-fluent-cart')],
                        ],
                    ],
                ];
            case 'missing':
                return $status + [
                    'tone'    => 'err',
                    'title'   => __('The webhook was removed from your Shippo account', 'shipping-for-fluent-cart'),
                    'text'    => __('Tracking updates have stopped. Register it again to resume them.', 'shipping-for-fluent-cart'),
                    'actions' => [$this->registerAction(__('Register again', 'shipping-for-fluent-cart'), 'primary')],
                ];
            case 'failed':
                $reason = (string) $this->settings->get('webhook_error');

                return $status + [
                    'tone'    => 'err',
                    'title'   => __('Shippo didn\'t accept the webhook', 'shipping-for-fluent-cart'),
                    'text'    => $reason !== ''
                        /* translators: %1$s: Shippo's reason */
                        ? sprintf(__('Shippo said: %1$s. Try again, or use the manual steps below.', 'shipping-for-fluent-cart'), rtrim($reason, '.'))
                        : __('Try again, or use the manual steps below.', 'shipping-for-fluent-cart'),
                    'actions' => [$this->registerAction(__('Try again', 'shipping-for-fluent-cart'))],
                ];
            default:
                return $status + [
                    'title'   => __('Shippo is not sending tracking updates yet', 'shipping-for-fluent-cart'),
                    /* translators: %1$s: Test or Live */
                    'text'    => sprintf(__('We add a track_updated webhook to your Shippo account for %1$s mode.', 'shipping-for-fluent-cart'), $mode),
                    'actions' => [$this->registerAction(__('Register webhook in Shippo', 'shipping-for-fluent-cart'), 'primary')],
                ];
        }
    }

    /* ------------------------------------------------------------- actions */

    /**
     * @return array|\WP_Error ['message' => string, 'ok' => bool]
     */
    public function runAction(string $action, array $data)
    {
        $handlers = [
            'test_connection'  => 'actionTestConnection',
            'refresh_carriers' => 'actionRefreshCarriers',
            'register_webhook' => 'actionRegisterWebhook',
            'check_webhook'    => 'actionCheckWebhook',
            'rotate_secret'    => 'actionRotateSecret',
        ];

        if (!isset($handlers[$action])) {
            return parent::runAction($action, $data);
        }

        if ($this->tokenFor($this->isSandbox()) === '') {
            return ['ok' => false, 'message' => $this->isSandbox()
                ? __('Save a test token first.', 'shipping-for-fluent-cart')
                : __('Save a live token first.', 'shipping-for-fluent-cart')];
        }

        return $this->{$handlers[$action]}();
    }

    protected function actionTestConnection(): array
    {
        $carriers = $this->fetchCarriers($this->tokenFor($this->isSandbox()));
        $now      = DateTime::gmtNow()->format('Y-m-d H:i:s');

        if (is_wp_error($carriers)) {
            // Only a refused token marks it rejected; an outage says nothing about the token.
            if ($carriers->get_error_code() === 'shippo_auth') {
                $this->settings->save(['connection_ok' => 'no', 'connection_checked_at' => $now]);

                return ['ok' => false, 'message' => __('Shippo didn\'t accept the token', 'shipping-for-fluent-cart')];
            }

            return ['ok' => false, 'message' => $carriers->get_error_message()];
        }

        $this->settings->save($this->carrierSync($carriers) + ['connection_checked_at' => $now]);

        return ['ok' => true, 'message' => __('Shippo accepted the token', 'shipping-for-fluent-cart')];
    }

    protected function actionRefreshCarriers(): array
    {
        $carriers = $this->fetchCarriers($this->tokenFor($this->isSandbox()));
        if (is_wp_error($carriers)) {
            return ['ok' => false, 'message' => $carriers->get_error_message()];
        }

        $this->settings->save($this->carrierSync($carriers));

        return ['ok' => true, 'message' => __('Carrier list updated from Shippo', 'shipping-for-fluent-cart')];
    }

    protected function actionRegisterWebhook(): array
    {
        if ((string) $this->settings->get('webhook_secret') === '') {
            $this->settings->save(['webhook_secret' => wp_generate_password(40, false)]);
        }

        if (!$this->registerWebhook($this->isSandbox())) {
            return ['ok' => false, 'message' => __('Shippo didn\'t accept the webhook', 'shipping-for-fluent-cart')];
        }

        return ['ok' => true, 'message' => __('Webhook registered in Shippo', 'shipping-for-fluent-cart')];
    }

    protected function actionCheckWebhook(): array
    {
        $mode = $this->isSandbox() ? 'test' : 'live';
        $id   = (string) $this->settings->get($mode . '_webhook_id');
        $hook = $id !== '' ? $this->client()->request('GET', '/webhooks/' . rawurlencode($id), [], ShippoWebhookRegistrar::TIMEOUT) : null;

        // Shippo answers 404 for a hook deleted in its dashboard.
        if (is_wp_error($hook) && (int) Arr::get((array) $hook->get_error_data(), 'http_code') !== 404) {
            return ['ok' => false, 'message' => $hook->get_error_message()];
        }

        $now = DateTime::gmtNow()->format('Y-m-d H:i:s');
        if (!is_array($hook) || Arr::get($hook, 'active') === false || (string) Arr::get($hook, 'url', '') !== $this->getWebhookUrl()) {
            $this->settings->save([$mode . '_webhook_state' => 'missing', 'webhook_checked_at' => $now]);

            return ['ok' => false, 'message' => __('Webhook not found in Shippo', 'shipping-for-fluent-cart')];
        }

        $this->settings->save([$mode . '_webhook_state' => 'registered', 'webhook_checked_at' => $now]);

        return ['ok' => true, 'message' => __('Webhook is active in Shippo', 'shipping-for-fluent-cart')];
    }

    protected function actionRotateSecret(): array
    {
        $this->settings->save(['webhook_secret' => wp_generate_password(40, false), 'webhook_checked_at' => '']);

        // The registrar finds our hook by its URL without the token, so the old one is updated, not duplicated.
        $current = $this->registerWebhook($this->isSandbox());

        // Both modes share the secret: a hook left on the old one gets 401 on every delivery.
        // Its hook may exist while its state is not 'registered' (added by hand, or stale), so look it up; never create one.
        $other      = !$this->isSandbox();
        $otherMoved = ($this->tokenFor($other) === '' && $this->settings->get(($other ? 'test' : 'live') . '_webhook_state') !== 'registered')
            || $this->registerWebhook($other, false);

        if (!$current) {
            return ['ok' => false, 'message' => __('The secret changed, but Shippo didn\'t accept the new URL. Register it again.', 'shipping-for-fluent-cart')];
        }

        if (!$otherMoved) {
            $mode = $other ? __('Test', 'shipping-for-fluent-cart') : __('Live', 'shipping-for-fluent-cart');

            /* translators: %1$s: the other mode, Test or Live */
            return ['ok' => false, 'message' => sprintf(__('The secret changed, but Shippo didn\'t accept the new URL for %1$s. Register it again in %1$s mode.', 'shipping-for-fluent-cart'), $mode)];
        }

        return ['ok' => true, 'message' => __('Secret rotated. Shippo has the new URL.', 'shipping-for-fluent-cart')];
    }

    protected function registerWebhook(bool $test, bool $create = true): bool
    {
        $mode = $test ? 'test' : 'live';
        $id   = (new ShippoWebhookRegistrar())->ensure($this->client($test), $this->getWebhookUrl(), $test, $create);

        if (is_wp_error($id)) {
            $this->settings->save([
                $mode . '_webhook_state' => 'failed',
                'webhook_error'          => sanitize_text_field($id->get_error_message()),
            ]);

            return false;
        }

        if ($id === '') {
            if ($this->settings->get($mode . '_webhook_state') === 'registered') {
                $this->settings->save([$mode . '_webhook_state' => 'missing']);
            }

            return true;
        }

        $this->settings->save([
            $mode . '_webhook_id'    => $id,
            $mode . '_webhook_state' => 'registered',
            'webhook_error'          => '',
            'webhook_checked_at'     => '',
        ]);

        return true;
    }

    /**
     * Settings a successful carrier-list read proves: the token works, and the account's carriers.
     */
    protected function carrierSync(array $carriers): array
    {
        $owner = '';
        foreach ($carriers as $index => $carrier) {
            $owner = $owner ?: (string) Arr::get($carrier, 'owner', '');
            unset($carriers[$index]['owner']);
        }

        $sync = [
            'connected_carriers' => array_values($carriers),
            'carriers_synced_at' => DateTime::gmtNow()->format('Y-m-d H:i:s'),
            'connection_ok'      => 'yes',
        ];
        if ($owner !== '') {
            $sync['connection_owner'] = $owner;
        }

        return $sync;
    }

    /* ------------------------------------------------------------- helpers */

    protected function ago(string $gmt): string
    {
        $time = $gmt !== '' ? strtotime($gmt . ' UTC') : false;
        if (!$time) {
            return __('never', 'shipping-for-fluent-cart');
        }
        if (time() - $time < 45) {
            return __('just now', 'shipping-for-fluent-cart');
        }

        /* translators: %1$s: a time span, e.g. 3 mins */
        return sprintf(__('%1$s ago', 'shipping-for-fluent-cart'), human_time_diff($time));
    }

    protected function localTime(string $gmt): string
    {
        $time = strtotime($gmt . ' UTC');

        return $time ? wp_date('M j, g:i a', $time) : $gmt;
    }
}
