<?php

namespace ShippingForFluentCart\App\Carriers\Shippo;

use FluentCart\Framework\Support\Arr;

/**
 * Keeps one track_updated webhook per mode registered for this store. A hook is
 * ours when its URL matches ours apart from fcs_token; any other hook is left alone.
 */
class ShippoWebhookRegistrar
{
    const EVENT = 'track_updated';

    const MAX_URL_LENGTH = 200;

    const MAX_PAGES = 20;

    const TIMEOUT = 15;

    /**
     * @param bool $create False only updates an existing hook; '' when there is none.
     * @return string|\WP_Error The webhook's object_id.
     */
    public function ensure(ShippoClient $client, string $url, bool $isTest, bool $create = true)
    {
        if (strlen($url) >= self::MAX_URL_LENGTH) {
            return new \WP_Error('shippo_webhook', __('the URL is 200 characters or longer', 'shipping-for-fluent-cart'));
        }

        $ours = $this->findOurs($client, $url, $isTest);
        if (is_wp_error($ours)) {
            return $ours;
        }

        // Prefer a hook that already matches, so a plain save writes nothing.
        usort($ours, function ($a, $b) use ($url) {
            return (int) $this->isCurrent($b, $url) - (int) $this->isCurrent($a, $url);
        });
        $keep = array_shift($ours);

        if (!$keep && !$create) {
            return '';
        }

        if (!$keep) {
            $saved = $client->request('POST', '/webhooks', ['url' => $url, 'event' => self::EVENT, 'is_test' => $isTest], self::TIMEOUT);
        } elseif (!$this->isCurrent($keep, $url)) {
            $saved = $client->request('PUT', '/webhooks/' . $keep['object_id'], [
                'event'   => self::EVENT,
                'url'     => $url,
                'active'  => true,
                'is_test' => $isTest,
            ], self::TIMEOUT);
        } else {
            $saved = $keep;
        }

        if (is_wp_error($saved)) {
            return $saved;
        }

        // Duplicates would deliver every event twice; best effort, the next save retries.
        foreach ($ours as $extra) {
            $client->request('DELETE', '/webhooks/' . $extra['object_id'], [], self::TIMEOUT);
        }

        $id = $keep ? (string) $keep['object_id'] : sanitize_text_field((string) Arr::get($saved, 'object_id', ''));

        return $id !== ''
            ? $id
            : new \WP_Error('shippo_webhook', __('Shippo did not return a webhook id', 'shipping-for-fluent-cart'));
    }

    /**
     * @return array[]|\WP_Error Every hook of ours in this mode, across all pages.
     */
    protected function findOurs(ShippoClient $client, string $url, bool $isTest)
    {
        $ours  = [];
        $query = [];
        $base  = $this->withoutToken($url);

        for ($page = 0; $page < self::MAX_PAGES; $page++) {
            $response = $client->request('GET', '/webhooks', $query, self::TIMEOUT);
            if (is_wp_error($response)) {
                return $response;
            }

            foreach ((array) Arr::get($response, 'results', []) as $hook) {
                if (is_array($hook)
                    && Arr::get($hook, 'event') === self::EVENT
                    && (bool) Arr::get($hook, 'is_test', false) === $isTest
                    && (string) Arr::get($hook, 'object_id', '') !== ''
                    && $this->withoutToken((string) Arr::get($hook, 'url', '')) === $base) {
                    $ours[] = $hook;
                }
            }

            $next = (string) Arr::get($response, 'next', '');
            if ($next === '') {
                break;
            }
            parse_str((string) wp_parse_url($next, PHP_URL_QUERY), $query);
        }

        return $ours;
    }

    protected function isCurrent(array $hook, string $url): bool
    {
        return (string) Arr::get($hook, 'url', '') === $url && Arr::get($hook, 'active', true) !== false;
    }

    /**
     * The URL as host, path and sorted query args without fcs_token, so arg order
     * and the token do not matter.
     */
    protected function withoutToken(string $url): array
    {
        $parts = wp_parse_url($url);
        if (!is_array($parts)) {
            return [];
        }

        parse_str(isset($parts['query']) ? $parts['query'] : '', $query);
        unset($query['fcs_token']);
        ksort($query);

        return [
            strtolower(Arr::get($parts, 'host', '')),
            Arr::get($parts, 'port'),
            untrailingslashit(Arr::get($parts, 'path', '')),
            $query,
        ];
    }
}
