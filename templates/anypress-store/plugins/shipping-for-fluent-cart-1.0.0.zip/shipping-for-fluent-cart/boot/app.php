<?php defined('ABSPATH') or die;

return function ($file) {
    // Class checks too: a pre-2.3.0 develop build of FluentCart can report the
    // version without the shared Concerns Shippo uses.
    $hasCarrierFramework = function () {
        if (!defined('FLUENTCART_VERSION') || version_compare(FLUENTCART_VERSION, SHIPPING_FOR_FLUENT_CART_MIN_CORE_VERSION, '<')) {
            return false;
        }

        if (!interface_exists('\FluentCart\App\Modules\Shipping\Carriers\Contracts\CarrierContract')
            || !class_exists('\FluentCart\App\Modules\Shipping\Carriers\Core\AbstractShippingCarrier')
            || !class_exists('\FluentCart\App\Modules\Shipping\Carriers\Core\BaseCarrierSettings')) {
            return false;
        }

        foreach (['ProvidesLiveRates', 'ProvidesSetupNotices', 'WebhookOutcomes'] as $concern) {
            if (!trait_exists('\FluentCart\App\Modules\Shipping\Carriers\Concerns\\' . $concern)) {
                return false;
            }
        }

        return true;
    };

    // Priority 9: before FluentCart fires fluentcart_loaded (plugins_loaded:10),
    // where it applies the carrier_providers filter.
    add_action('plugins_loaded', function () use ($file, $hasCarrierFramework) {
        // Unconditional, so updates keep arriving even while FluentCart is inactive.
        new \ShippingForFluentCart\App\Services\PluginManager\Updater(
            'https://fluentcart.com/',
            $file,
            [
                'version'           => SHIPPING_FOR_FLUENT_CART_VERSION,
                'addon_slug'        => 'shipping-for-fluent-cart',
                'parent_product_id' => 21480,
                'plugin_title'      => 'Shipping For FluentCart',
                'is_free'           => true,
            ]
        );

        add_filter('plugin_row_meta', function ($links, $pluginFilePath) use ($file) {
            if (plugin_basename($file) !== $pluginFilePath) {
                return $links;
            }

            $checkUpdateUrl = esc_url(admin_url('plugins.php?shipping-for-fluent-cart-check-update=' . time()));

            $links['check_update'] = '<a style="color: #583fad;font-weight: 600;" href="' . $checkUpdateUrl . '" aria-label="' . esc_attr__('Check Update', 'shipping-for-fluent-cart') . '">' . esc_html__('Check Update', 'shipping-for-fluent-cart') . '</a>';

            return $links;
        }, 10, 2);

        add_action('init', function () use ($file) {
            load_plugin_textdomain('shipping-for-fluent-cart', false, dirname(plugin_basename($file)) . '/language');
        });

        if (!$hasCarrierFramework()) {
            add_action('admin_notices', function () {
                if (!current_user_can('activate_plugins')) {
                    return;
                }

                printf(
                    '<div class="notice notice-error"><p>%1$s</p></div>',
                    esc_html(sprintf(
                        /* translators: %1$s: minimum FluentCart version, e.g. 2.3.0 */
                        __('Shipping For FluentCart needs FluentCart %1$s or later with the shipping carrier framework. Install, activate or update FluentCart to use Shippo.', 'shipping-for-fluent-cart'),
                        SHIPPING_FOR_FLUENT_CART_MIN_CORE_VERSION
                    ))
                );
            });

            return;
        }

        // Applied on fluentcart_loaded, so this must be added before it fires.
        add_filter('fluent_cart/shipping/carrier_providers', function ($carriers) {
            // Older FluentCart without carrier dispatch: register nothing.
            if (!class_exists('\FluentCart\App\Services\Shipments\ShipmentInstance')) {
                return $carriers;
            }

            $carriers = is_array($carriers) ? $carriers : [];
            $carriers['shippo'] = new \ShippingForFluentCart\App\Carriers\Shippo\ShippoCarrier(
                new \ShippingForFluentCart\App\Carriers\Shippo\ShippoCarrierSettings()
            );

            return $carriers;
        });
    }, 9);
};
