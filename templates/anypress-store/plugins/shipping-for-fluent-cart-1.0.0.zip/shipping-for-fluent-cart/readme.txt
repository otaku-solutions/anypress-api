=== Shipping For FluentCart ===
Contributors: wpmanageninja
Tags: fluentcart, shipping, shippo, shipping labels, live rates
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Connect FluentCart to Shippo for live shipping rates at checkout, label purchase and tracking updates.

== Description ==
Shipping For FluentCart adds the Shippo carrier to FluentCart's shipping carriers.

* Live Shippo rates at checkout, shown in the checkout currency.
* Buy and void Shippo labels from the order screen.
* Refresh tracking, and receive Shippo tracking webhooks.

The carrier framework stays in FluentCart, so other plugins can add their own carriers through the `fluent_cart/shipping/carrier_providers` filter.

== Requirements ==
* FluentCart 2.3.0 or later, with the shipping carrier framework.
* A Shippo account and API token.

== External services ==
This plugin connects to the Shippo API (https://api.goshippo.com) to quote shipping rates, buy and void labels, and read tracking. Nothing is sent until you enable Shippo and save an API token.

* At checkout: your store address, the customer's city, state, postal code and country, and the cart's parcel weights and dimensions, to show live rates.
* When you buy a label: the store address, Seller Phone and Seller Email, the customer's name, company, shipping address, phone and email, the parcels, and for international shipments the item names, quantities, weights and values for customs. The label PDF is then downloaded from the link Shippo returns.
* When tracking is refreshed or a Shippo webhook arrives: the label's transaction id, or the tracking number and carrier.

Shippo is provided by Shippo (Popout, Inc.): [Terms of Use](https://goshippo.com/terms), [Privacy Notice](https://goshippo.com/privacy).

== Installation ==
1. Install from FluentCart → Addons, or upload the plugin zip and activate it.
2. Go to FluentCart → Settings → Shipping → Carriers → Shippo, enter your Shippo token and enable the carrier.

== Changelog ==
= 1.0.0 =
* Initial release: the Shippo carrier.
