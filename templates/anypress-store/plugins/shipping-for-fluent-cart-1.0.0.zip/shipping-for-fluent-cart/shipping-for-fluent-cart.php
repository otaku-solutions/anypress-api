<?php defined('ABSPATH') or die;

/*
Plugin Name: Shipping For FluentCart
Description: Shippo live rates, labels and tracking for FluentCart.
Version: 1.0.0
Author: FluentCart Team
Author URI: https://fluentcart.com/about-us
Plugin URI: https://fluentcart.com
License: GPLv2 or later
Text Domain: shipping-for-fluent-cart
Domain Path: /language
Requires Plugins: fluent-cart
*/

if (!defined('SHIPPING_FOR_FLUENT_CART_VERSION')) {
    define('SHIPPING_FOR_FLUENT_CART_VERSION', '1.0.0');
    define('SHIPPING_FOR_FLUENT_CART_MIN_CORE_VERSION', '2.3.0');
}

require __DIR__ . '/vendor/autoload.php';

call_user_func(function ($bootstrap) {
    $bootstrap(__FILE__);
}, require(__DIR__ . '/boot/app.php'));
